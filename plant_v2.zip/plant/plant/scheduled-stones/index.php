<?php
session_start();
require_once '../../../office/admin/includes/db.php';
require_once '../../../office/admin/includes/auth.php';
include_once "../includes/functions.php";

// Clearance 2 & 3 can view scheduled-stones (read-only)
// Clearance 1 → redirect to upcoming (their equivalent scheduling page with CRUD)
if (empty($_SESSION['app_session']) || $_SESSION['app_session'] !== 'active') {
    header('Location: ../../loggin-in/');
    exit;
}
$_plant_clearance = (int)($_SESSION['security_clearance'] ?? 0);
if ($_plant_clearance === 1) {
    header('Location: ../upcoming/');
    exit;
}
if (!in_array($_plant_clearance, [2, 3], true)) {
    header('Location: ../../404/');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stone Code Entry Form | Installation Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6B35;
            --secondary-color: #004E89;
            --accent-color: #FFD6BA;
            --light-orange: #fff3ed;
        }
        body {
            background: #fef9f5;
        }
        .header-bar {
            background: var(--primary-color);
            color: white;
            padding: 1.5rem 0;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header-bar h1 {
            font-size: 1.8rem;
            margin: 0;
            font-weight: 600;
        }
        .filter-card {
            background: white;
            border-radius: 16px;
            padding: 1.2rem 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border-left: 5px solid var(--primary-color);
        }
        .btn-orange {
            background-color: var(--primary-color);
            border: none;
            color: white;
            font-weight: 500;
            transition: 0.2s;
        }
        .btn-orange:hover {
            background-color: #e55a2b;
            color: white;
        }
        .contract-card {
            background: white;
            border-radius: 20px;
            padding: 1.2rem 1rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
            transition: 0.2s;
            border: 1px solid #ffe0d0;
        }
        .contract-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255,107,53,0.12);
            border-color: var(--primary-color);
        }
        .contract-title {
            font-weight: 700;
            color: var(--secondary-color);
        }
        .badge-date {
            background: var(--accent-color);
            color: #a13e0f;
            padding: 0.3rem 0.8rem;
            border-radius: 30px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        .info-label {
            font-size: 0.75rem;
            text-transform: uppercase;
            color: #b35a2e;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        .info-value {
            font-weight: 500;
            color: #1e2a3e;
        }
        .action-link {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            margin-right: 1rem;
            margin:10px;
            text-align: center;
            cursor: pointer;
        }
        .action-link:hover {
            text-decoration: underline;
            color: #c73f0c;
        }
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 24px;
            color: #8b5a3e;
        }
        .loading-spinner {
            text-align: center;
            padding: 3rem;
        }
        #home {
            background-color: #ffffff !important;
            color: black;
            width: 103px;
            border-radius: 5px;
            transition: all 0.6s ease;
        }
        #home:hover {
            background-color:black !important;
            color: #ffffff !important;
        }
		#logout {
            background-color: black !important;
            color: white;
            width: 103px;
            border-radius: 5px;
            transition: all 0.6s ease;
        }
        #logout:hover {
            background-color:#a94e2d !important;
            color: white !important;
        }
        footer {
            margin-top: 3rem;
            text-align: center;
            padding: 1.5rem;
            color: #c76e3a;
            font-size: 0.85rem;
        }
        #modal-schedule {
            position: fixed;
            z-index: 3000;
            width: 100%;
            height: 100vh;
            background-color: rgba(0,0,0,0.7);
            top: 0;
            left: 0;
            padding: 10px;
            margin: 0;
            display: none;
            align-items: center;
            justify-content: center;
        }
        #modal-schedule.open-modal {
            display: flex !important;
        }
        #schedule-form {
            width: 450px;
            height: 171px;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            box-shadow: 2px 5px 6px 4px #00000099;
            padding: 8px;
            background: white;
            border-radius: 14px;
        }
        #schedule-form label {
            height: 100%;
            display: flex;
            margin: auto 0px;
            align-items: center;
            font-weight: 700;
            text-transform: none;
        }
        #schedule-form input {
            height: 41px;
        }
        #schedule-form button {
            height: 41px;
        }
        /* response modal styles */
        #delete-resp {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 4000;
        }
        #delete-resp section {
            background: white;
            border-radius: 20px;
            width: 350px;
            padding: 1rem;
            text-align: center;
        }
        .mod-head {
            display: flex;
            justify-content: flex-end;
        }
        .mod-head h5 {
            cursor: pointer;
            font-size: 20px;
            margin: 0;
        }
        .green { color: #2e7d32; font-weight: bold; }
        .red { color: #c62828; font-weight: bold; }
        @media (max-width: 768px) {
            .contract-card .row > div {
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>
<body>

<div class="header-bar">
    <div class="container">
        <figure>
            <h1>📦 Stone Installation Schedule</h1>
        </figure>
        <button id="home" onclick="goHome()" class="btn btn-orange">HOME</button>
        <button id="logout" onclick="logOut()" class="btn btn-orange">Log out</button>
    </div>
</div>

<main class="container">
<!-- Modal for scheduling (date picker) -->
<figure id="modal-schedule">
    <form method="POST" action="" id="schedule-form">
        <div style="display:flex;justify-content:space-between;">
            <label>Set the date</label>
            <p onclick="closeMod('modal-schedule')" style="width:50px; text-align:center;padding-right:10px;font-size:26px;cursor:pointer">X</p>
        </div>
        <input type="date" name="installation_date" required />
        <input type="text" name="id" id="form-id" value="" hidden />
        <button name="schedule">Schedule</button>
    </form>
</figure>

<!-- Filter section -->
<div class="filter-card">
    <div class="row align-items-end g-3">
        <div class="col-md-5">
            <label class="info-label mb-1">📍 Filter by Location (GY)</label>
            <select id="locationFilter" class="form-select">
                <option value="all">All locations</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="info-label mb-1">📅 Sort order</label>
            <select id="sortOrder" class="form-select">
                <option value="asc">Soonest first (⬆️ earliest)</option>
                <option value="desc">Later dates first (⬇️ newest)</option>
            </select>
        </div>
        <div class="col-md-3">
            <button id="resetFilters" class="btn btn-orange w-100">⟳ Reset filters</button>
        </div>
    </div>
</div>

<!-- Data container -->
<div id="dataContainer">
    <div class="loading-spinner">
        <div class="spinner-border text-orange" style="color:#FF6B35;" role="status"></div>
        <p class="mt-2">Loading contracts...</p>
    </div>
</div>
</main>

<footer>Wim Tombstones</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Helper: format date as "25 Tuesday 2026"
function formatInstallationDate(dateString) {
    if (!dateString || dateString === "0000-00-00") return "No date";
    const parts = dateString.split("-");
    if (parts.length !== 3) return dateString;
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const day = parseInt(parts[2], 10);
    const dateObj = new Date(year, month, day);
    if (isNaN(dateObj.getTime())) return dateString;
    const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const weekdayName = weekdays[dateObj.getDay()];
    return `${day} ${weekdayName} ${year}`;
}

let allContracts = [];
const dataContainer = document.getElementById("dataContainer");
const locationFilter = document.getElementById("locationFilter");
const sortOrderSelect = document.getElementById("sortOrder");
const resetBtn = document.getElementById("resetFilters");

function fetchContracts() {
    dataContainer.innerHTML = `<div class="loading-spinner"><div class="spinner-border text-orange" style="color:#FF6B35;" role="status"></div><p class="mt-2">Loading contracts...</p></div>`;
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "../../global/data/all_contracts.php", true);
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 400) {
            try {
                const contracts = JSON.parse(xhr.responseText);
                if (contracts && contracts.length > 0) {
                   const validContracts = contracts.filter(contract => 
                        contract.installation_date && 
                        contract.installation_date !== "0000-00-00" &&
                        contract.confirm_installation == 0
                    );

                    if (validContracts.length === 0) {
                        showEmptyState("No contracts with valid installation date found.");
                        allContracts = [];
                        return;
                    }
                    allContracts = validContracts;
                    populateLocationFilter(allContracts);
                    renderContracts();
                } else {
                    showEmptyState("No data received from server.");
                }
            } catch (e) {
                console.error("JSON parse error", e);
                showEmptyState("Error parsing data. Please refresh.");
            }
        } else {
            showEmptyState(`Failed to load data (HTTP ${xhr.status}). Try again later.`);
        }
    };
    xhr.onerror = function() {
        showEmptyState("Network error. Please check your connection.");
    };
    xhr.send();
}

function showEmptyState(message) {
    dataContainer.innerHTML = `<div class="empty-state"><h5>📭 ${message}</h5><button class="btn btn-orange mt-3" onclick="fetchContracts()">↻ Retry</button></div>`;
}

function populateLocationFilter(contracts) {
    const locations = new Set();
    contracts.forEach(contract => {
        if (contract.gy && contract.gy.trim() !== "") locations.add(contract.gy.trim());
    });
    let options = '<option value="all">All locations</option>';
    [...locations].sort().forEach(loc => {
        options += `<option value="${escapeHtml(loc)}">${escapeHtml(loc)}</option>`;
    });
    locationFilter.innerHTML = options;
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function renderContracts() {
    if (!allContracts.length) {
        showEmptyState("No installation data available.");
        return;
    }
    const selectedLocation = locationFilter.value;
    let filtered = [...allContracts];
    if (selectedLocation !== "all") {
        filtered = filtered.filter(contract => contract.gy && contract.gy.trim() === selectedLocation);
    }
    const sortOrder = sortOrderSelect.value;
    filtered.sort((a, b) => {
        const dateA = new Date(a.installation_date);
        const dateB = new Date(b.installation_date);
        if (isNaN(dateA)) return 1;
        if (isNaN(dateB)) return -1;
        return sortOrder === "asc" ? dateA - dateB : dateB - dateA;
    });
    if (filtered.length === 0) {
        dataContainer.innerHTML = `<div class="empty-state">📍 No contracts match the selected location "${escapeHtml(selectedLocation)}".</div>`;
        return;
    }
    let html = '';
    filtered.forEach(contract => {
        const formattedDate = formatInstallationDate(contract.installation_date);
        const extrasDisplay = (contract.extras && contract.extras !== "") ? contract.extras : "TF";
        const gyDisplay = contract.gy && contract.gy.trim() !== "" ? contract.gy : "—";
        html += `
            <div class="contract-card">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-12 mb-2 mb-lg-0">
                        <div class="contract-title">📄 Contract #${escapeHtml(contract.id)}</div>
                        <div class="info-value">👤 ${escapeHtml(contract.contact_name)}</div>
                        <div "deceased-name">✝ ${escapeHtml(contract.deseased_name)}</div>
                        <div class="mt-1">
                            <a href="../details/index.php?contract-id=${contract.id}" class="action-link">View</a>
        
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="info-label">Stone code</div>
                        <div class="info-value">${escapeHtml(contract.stone_name)}</div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="info-label">Extras</div>
                        <div class="info-value">${escapeHtml(extrasDisplay)}</div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="info-label">Location GY</div>
                        <div class="info-value">${escapeHtml(gyDisplay)}</div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6">
                        <div class="info-label">Installation date</div>
                        <div class="badge-date">📅 ${formattedDate}</div>
                       
                    </div>
                </div>
            </div>
        `;
    });
    dataContainer.innerHTML = html;
}

locationFilter.addEventListener("change", () => renderContracts());
sortOrderSelect.addEventListener("change", () => renderContracts());
resetBtn.addEventListener("click", () => {
    locationFilter.value = "all";
    sortOrderSelect.value = "asc";
    renderContracts();
});

fetchContracts();

function closeMod(id) {
    if(id === null || id === "delete-resp") {
        let elem = document.querySelector("#delete-resp");
        if(elem) elem.remove();
    } else {
        document.querySelector(`#${id}`).classList.remove("open-modal");
    }
}

function scheduleContract(contrID) {
    document.querySelector("#modal-schedule").classList.add("open-modal");
    document.querySelector("#form-id").value = contrID;
}

// UNSCHEDULE: confirmation + direct POST (no modal)
function confirmUnschedule(contrID) {
    if(confirm("⚠️ Are you sure you want to UNSCHEDULE this contract?\nThe installation date will be removed.")) {
        // Create a temporary form and submit via POST
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '';
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'UnScheduleContract';
        input.value = '1';
        const idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'id';
        idInput.value = contrID;
        form.appendChild(input);
        form.appendChild(idInput);
        document.body.appendChild(form);
        form.submit();
    }
}

function goHome() {
    window.location.href = "../";
}
function logOut() {
    window.location.href = "../log-out/";
}
</script>

<!-- Response modal display (if any) -->
<?php if (!empty($del_resp)) echo $del_resp; ?>
<script>
// Auto-close response modal after 4 seconds and remove the element
if(document.querySelector("#delete-resp")) {
    setTimeout(() => {
        let modal = document.querySelector("#delete-resp");
        if(modal) modal.remove();
    }, 4000);
}
</script>
</body>
</html>