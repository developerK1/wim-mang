<?php
session_start();
require_once '../../../office/admin/includes/db.php';
require_once '../../../office/admin/includes/auth.php';
include_once "../includes/functions.php";

// Clearance 1 & 2 only — 3 → scheduled-stones, 0 → 404
if (empty($_SESSION['app_session']) || $_SESSION['app_session'] !== 'active') {
    header('Location: ../../loggin-in/');
    exit;
}
$_plant_clearance = (int)($_SESSION['security_clearance'] ?? 0);
if (!in_array($_plant_clearance, [1, 2], true)) {
    header($_plant_clearance === 3 ? 'Location: ../scheduled-stones/' : 'Location: ../../404/');
    exit;
}

$del_resp = "";

// Delete
if (isset($_POST['delete'])) {
    $contractID = trim($_POST['contractid']);
    deleteContract($contractID);
}

// Schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule'])) {
    $id        = trim($_POST['id']);
    $inst_date = trim($_POST['installation_date']);
    if (!empty($id) && !empty($inst_date)) {
        global $con;
        $stmt = $con->prepare("UPDATE `tombstones_installations` SET `installation_date` = ? WHERE `id` = ?");
        $stmt->bind_param("ss", $inst_date, $id);
        $ok = $stmt->execute();
        $stmt->close();
        header("Location: index.php?schedule_Status=" . ($ok ? 1 : 0) . "&id=$id");
    } else {
        header("Location: index.php?schedule_Status=0&id=" . urlencode($_POST['id'] ?? ''));
    }
    exit;
}

// Schedule response modal
if (isset($_GET['schedule_Status'])) {
    $contract   = trim($_GET['id']);
    $del_status = trim($_GET['schedule_Status']);
    if ($del_status == 1) {
        $del_resp = '<div class="container-fluid" id="delete-resp"><section class="success"><div class="mod-head"><h5 onclick="closeMod()">X</h5></div><h2 class="response">Contract: ' . $contract . '</h2><p class="green">✅ Successfully scheduled</p></section></div>';
    } else {
        $del_resp = '<div class="container-fluid" id="delete-resp"><section class="error"><div class="mod-head"><h5 onclick="closeMod()">X</h5></div><h2 class="response">Contract: ' . $contract . '</h2><p class="red">❌ Scheduling failed</p></section></div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plant Home | Approved Contracts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6B35;
            --secondary-color: #004E89;
            --accent-color: #FFD6BA;
            --light-orange: #fff3ed;
        }
        body {
            background: #fef9f5;
        }
        .header-bar {
            background: var(--primary-color);
            color: white;
            padding: 1.5rem 0;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header-bar h1 {
            font-size: 1.8rem;
            margin: 0;
            font-weight: 600;
        }
        .filter-card {
            background: white;
            border-radius: 16px;
            padding: 1.2rem 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border-left: 5px solid var(--primary-color);
        }
        .btn-orange {
            background-color: var(--primary-color);
            border: none;
            color: white;
            font-weight: 500;
            transition: 0.2s;
        }
        .btn-orange:hover {
            background-color: #e55a2b;
            color: white;
        }
        .contract-card {
            background: white;
            border-radius: 20px;
            padding: 1.2rem 1rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
            transition: 0.2s;
            border: 1px solid #ffe0d0;
        }
        .contract-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255,107,53,0.12);
            border-color: var(--primary-color);
        }
        .contract-card.due {
            border-color: #ffaaaa;
            background: #fff5f5;
        }
        .contract-title {
            font-weight: 700;
            color: var(--secondary-color);
        }
        .badge-date {
            background: var(--accent-color);
            color: #a13e0f;
            padding: 0.3rem 0.8rem;
            border-radius: 30px;
            font-size: 0.85rem;
            font-weight: 500;
            display: inline-block;
        }
        .badge-week {
            background: #e8f4fd;
            color: #004E89;
            padding: 0.3rem 0.8rem;
            border-radius: 30px;
            font-size: 0.85rem;
            font-weight: 500;
            display: inline-block;
        }
        .badge-week.overdue {
            background: #ffe0e0;
            color: #c62828;
        }
        .info-label {
            font-size: 0.75rem;
            text-transform: uppercase;
            color: #b35a2e;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        .info-value {
            font-weight: 500;
            color: #1e2a3e;
        }
        .deceased-name {
            font-size: 0.85rem;
            color: #666;
            font-style: italic;
        }
        .action-link {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            margin: 4px 6px 0 0;
            display: inline-block;
            cursor: pointer;
        }
        .action-link:hover {
            text-decoration: underline;
            color: #c73f0c;
        }
        .action-link.danger {
            color: #c62828;
        }
        .action-link.danger:hover {
            color: #8b0000;
        }
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 24px;
            color: #8b5a3e;
        }
        .loading-spinner {
            text-align: center;
            padding: 3rem;
        }
        #nav-btn {
            background-color: #ffffff !important;
            color: black;
            border-radius: 5px;
            transition: all 0.6s ease;
            border: none;
            padding: 6px 14px;
            font-weight: 500;
            margin-right: 6px;
        }
        #nav-btn:hover {
            background-color: black !important;
            color: #ffffff !important;
        }
        #logout {
            background-color: black !important;
            color: white;
            border-radius: 5px;
            transition: all 0.6s ease;
            border: none;
            padding: 6px 14px;
            font-weight: 500;
        }
        #logout:hover {
            background-color: #a94e2d !important;
        }
        footer {
            margin-top: 3rem;
            text-align: center;
            padding: 1.5rem;
            color: #c76e3a;
            font-size: 0.85rem;
        }
        /* Schedule modal */
        #modal-schedule {
            position: fixed;
            z-index: 3000;
            width: 100%;
            height: 100vh;
            background-color: rgba(0,0,0,0.7);
            top: 0; left: 0;
            padding: 10px;
            display: none;
            align-items: center;
            justify-content: center;
        }
        #modal-schedule.open-modal { display: flex !important; }
        #schedule-form {
            width: 450px;
            height: 171px;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            box-shadow: 2px 5px 6px 4px #00000099;
            padding: 8px;
            background: white;
            border-radius: 14px;
        }
        #schedule-form label { height: 100%; display: flex; margin: auto 0; align-items: center; font-weight: 700; }
        #schedule-form input, #schedule-form button { height: 41px; }
        #schedule-form button { background: var(--primary-color); border: none; color: white; border-radius: 6px; }
        /* Response modal */
        #delete-resp {
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex; align-items: center; justify-content: center;
            z-index: 4000;
        }
        #delete-resp section {
            background: white; border-radius: 20px;
            width: 350px; padding: 1rem; text-align: center;
        }
        .mod-head { display: flex; justify-content: flex-end; }
        .mod-head h5 { cursor: pointer; font-size: 20px; margin: 0; }
        .green { color: #2e7d32; font-weight: bold; }
        .red   { color: #c62828; font-weight: bold; }
        section.success { border-top: 4px solid #2e7d32; }
        section.success .mod-head { background: #2e7d32; color: white; }
        section.error   { border-top: 4px solid #c62828; }
        section.error .mod-head   { background: #c62828; color: white; }
        @media (max-width: 768px) {
            .contract-card .row > div { margin-bottom: 0.5rem; }
        }
    </style>
</head>
<body>

<div class="header-bar">
    <div class="container d-flex align-items-center justify-content-between flex-wrap gap-2">
        <h1>🏠 Approved Contracts</h1>
        <div>
			<button id="logout" onclick="window.location.href='https://wimcorporation.co.za/office/'">Admin</button>
            <a href="../add/"><button id="nav-btn">➕ Add New</button></a>
            <a href="../scheduled-stones/"><button id="nav-btn">🪨 Scheduled Stones</button></a>
            <button id="logout" onclick="window.location.href='../log-out/'">Log out</button>
        </div>
    </div>
</div>

<main class="container">

<!-- Schedule date modal -->
<figure id="modal-schedule">
    <form method="POST" action="" id="schedule-form">
        <div style="display:flex;justify-content:space-between;">
            <label>Set the date</label>
            <p onclick="closeMod('modal-schedule')" style="width:50px;text-align:center;padding-right:10px;font-size:26px;cursor:pointer">X</p>
        </div>
        <input type="date" name="installation_date" required />
        <input type="text" name="id" id="form-id" value="" hidden />
        <button name="schedule">Schedule</button>
    </form>
</figure>

<!-- Filters -->
<div class="filter-card">
    <div class="row align-items-end g-3">
        <div class="col-md-4">
            <label class="info-label mb-1">📍 Filter by Location (GY)</label>
            <select id="locationFilter" class="form-select">
                <option value="all">All locations</option>
            </select>
        </div>
        <div class="col-md-3">
            <label class="info-label mb-1">📆 Filter by Week Approved</label>
            <select id="weekFilter" class="form-select">
                <option value="all">All weeks</option>
            </select>
        </div>
        <div class="col-md-3">
            <label class="info-label mb-1">🕊️ Filter by Unveiling Date</label>
            <select id="unveilingFilter" class="form-select">
                <option value="all">All unveiling dates</option>
                <option value="tf">TF (no date set)</option>
                <option value="set">Date set</option>
            </select>
        </div>
        <div class="col-md-2">
            <button id="resetFilters" class="btn btn-orange w-100">⟳ Reset</button>
        </div>
    </div>
</div>

<!-- Results count -->
<p id="resultsCount" class="text-muted mb-2" style="font-size:0.9rem;"></p>

<!-- Cards -->
<div id="dataContainer">
    <div class="loading-spinner">
        <div class="spinner-border" style="color:#FF6B35;" role="status"></div>
        <p class="mt-2">Loading contracts...</p>
    </div>
</div>

</main>

<footer>Wim Tombstones</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const canSchedule = <?= $_plant_clearance === 1 ? 'true' : 'false' ?>;

let allContracts = [];
const dataContainer   = document.getElementById("dataContainer");
const locationFilter  = document.getElementById("locationFilter");
const weekFilter      = document.getElementById("weekFilter");
const unveilingFilter = document.getElementById("unveilingFilter");
const resetBtn        = document.getElementById("resetFilters");
const resultsCount    = document.getElementById("resultsCount");

// ── Helpers ──────────────────────────────────────────────────────────────────

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function getWeeksSince(dateStr) {
    if (!dateStr || dateStr === "0000-00-00") return null;
    const target = new Date(dateStr);
    const today  = new Date();
    const ms = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate())
             - Date.UTC(target.getFullYear(), target.getMonth(), target.getDate());
    return Math.floor(ms / (1000 * 60 * 60 * 24 * 7));
}

function formatWeekLabel(dateStr) {
    if (!dateStr || dateStr === "0000-00-00") return "Unknown";
    const d = new Date(dateStr);
    if (isNaN(d)) return dateStr;
    // ISO week number
    const tmp = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    tmp.setUTCDate(tmp.getUTCDate() + 4 - (tmp.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 1));
    const week = Math.ceil((((tmp - yearStart) / 86400000) + 1) / 7);
    return `Week ${week}, ${tmp.getUTCFullYear()}`;
}

// ── Fetch ─────────────────────────────────────────────────────────────────────

function fetchContracts() {
    dataContainer.innerHTML = `<div class="loading-spinner"><div class="spinner-border" style="color:#FF6B35;" role="status"></div><p class="mt-2">Loading contracts...</p></div>`;
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "../../global/data/all_contracts.php", true);
    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 400) {
            try {
                const contracts = JSON.parse(xhr.responseText);
                // Home shows UN-scheduled contracts (no installation date yet)
                const pending = contracts.filter(c => !c.installation_date || c.installation_date === "0000-00-00");
                if (pending.length === 0) {
                    showEmptyState("No approved contracts pending scheduling.");
                    allContracts = [];
                    return;
                }
                allContracts = pending;
                populateFilters(allContracts);
                renderContracts();
            } catch (e) {
                showEmptyState("Error parsing data. Please refresh.");
            }
        } else {
            showEmptyState(`Failed to load data (HTTP ${xhr.status}).`);
        }
    };
    xhr.onerror = () => showEmptyState("Network error. Please check your connection.");
    xhr.send();
}

function showEmptyState(msg) {
    resultsCount.textContent = '';
    dataContainer.innerHTML = `<div class="empty-state"><h5>📭 ${msg}</h5><button class="btn btn-orange mt-3" onclick="fetchContracts()">↻ Retry</button></div>`;
}

// ── Populate filter dropdowns ─────────────────────────────────────────────────

function populateFilters(contracts) {
    // Location
    const locs = new Set();
    contracts.forEach(c => { if (c.gy && c.gy.trim()) locs.add(c.gy.trim()); });
    let locOpts = '<option value="all">All locations</option>';
    [...locs].sort().forEach(l => { locOpts += `<option value="${escapeHtml(l)}">${escapeHtml(l)}</option>`; });
    locationFilter.innerHTML = locOpts;

    // Week approved (from unveiling)
    const weeks = new Map(); // label → date string for sorting
    contracts.forEach(c => {
        if (c.unveiling && c.unveiling !== "0000-00-00") {
            const label = formatWeekLabel(c.unveiling);
            if (!weeks.has(label)) weeks.set(label, c.unveiling);
        }
    });
    const sortedWeeks = [...weeks.entries()].sort((a, b) => new Date(b[1]) - new Date(a[1]));
    let weekOpts = '<option value="all">All weeks</option>';
    sortedWeeks.forEach(([label, date]) => {
        weekOpts += `<option value="${escapeHtml(label)}">${escapeHtml(label)}</option>`;
    });
    weekFilter.innerHTML = weekOpts;
}

// ── Render ────────────────────────────────────────────────────────────────────

function renderContracts() {
    if (!allContracts.length) { showEmptyState("No contracts available."); return; }

    const selLoc      = locationFilter.value;
    const selWeek     = weekFilter.value;
    const selUnveil   = unveilingFilter.value;

    let filtered = [...allContracts];

    if (selLoc !== "all") {
        filtered = filtered.filter(c => c.gy && c.gy.trim() === selLoc);
    }
    if (selWeek !== "all") {
        filtered = filtered.filter(c => formatWeekLabel(c.unveiling) === selWeek);
    }
    if (selUnveil === "tf") {
        filtered = filtered.filter(c => !c.unveiling || c.unveiling === "0000-00-00" || c.unveiling.toUpperCase() === "TF");
    } else if (selUnveil === "set") {
        filtered = filtered.filter(c => c.unveiling && c.unveiling !== "0000-00-00" && c.unveiling.toUpperCase() !== "TF");
    }

    resultsCount.textContent = `Showing ${filtered.length} of ${allContracts.length} contracts`;

    if (filtered.length === 0) {
        dataContainer.innerHTML = `<div class="empty-state">📭 No contracts match the selected filters.</div>`;
        return;
    }

    let html = '';
    filtered.forEach(c => {
        const weeks        = getWeeksSince(c.unveiling);
        const isOverdue    = weeks !== null && weeks >= 3;
        const weekLabel    = weeks === null ? "Unknown" : (weeks === 0 ? "This week" : `${weeks} week${weeks !== 1 ? 's' : ''} ago`);
        const gyDisplay    = c.gy && c.gy.trim() ? c.gy : "—";
        const extrasDisplay = c.extras && c.extras.trim() ? c.extras : "TF";
        const unveiling    = c.unveiling;
        const decName      = [c.dec_name, c.dSurname].filter(Boolean).join(" ").trim() || "—";

        html += `
        <div class="contract-card${isOverdue ? ' due' : ''}">
            <div class="row align-items-center">

                <!-- Col 1: Contract info -->
                <div class="col-lg-3 col-md-12 mb-2 mb-lg-0">
                    <div class="contract-title">📄 Contract #${escapeHtml(c.id)}</div>
                    <div class="info-value">👤 ${escapeHtml(c.contact_name)}</div>
                    <div class="deceased-name">✝ ${escapeHtml(c.deseased_name)}</div>
                    <div class="mt-2">
                        <a href="../details/index.php?contract-id=${c.id}" class="action-link">View</a>
                        <a href="../update/index.php?id=${c.id}" class="action-link">Update</a>
                        <span onclick="confirmDelete('${escapeHtml(c.id)}')" class="action-link danger">Delete</span>
                    </div>
                </div>

                <!-- Col 2: Stone info -->
                <div class="col-lg-2 col-md-4 col-6">
                    <div class="info-label">Stone Code</div>
                    <div class="info-value">${escapeHtml(c.stone_name)}</div>
                    <div class="info-label mt-2">Extras</div>
                    <div class="info-value">${escapeHtml(extrasDisplay)}</div>
                </div>

                <!-- Col 3: Location -->
                <div class="col-lg-2 col-md-4 col-6">
                    <div class="info-label">Location GY</div>
                    <div class="info-value">${escapeHtml(gyDisplay)}</div>
                </div>

                <!-- Col 4: Week approved -->
                <div class="col-lg-3 col-md-4 col-6">
                    <div class="info-label">Week Approved</div>
                    <span class="badge-week${isOverdue ? ' overdue' : ''}">${escapeHtml(weekLabel)}${isOverdue ? ' ⚠️' : ''}</span>
                </div>

                <!-- Col 5: Schedule action -->
                ${canSchedule ? `
                <div class="col-lg-2 col-md-4 col-6">
                    <div class="info-label">Schedule</div>
                    <p onclick="openSchedule('${c.id}')" class="action-link mt-1">📅 Set Date</p>
                </div>` : ''}

            </div>
        </div>`;
    });

    dataContainer.innerHTML = html;
}

// ── Filter listeners ──────────────────────────────────────────────────────────

locationFilter.addEventListener("change",  renderContracts);
weekFilter.addEventListener("change",      renderContracts);
unveilingFilter.addEventListener("change", renderContracts);
resetBtn.addEventListener("click", () => {
    locationFilter.value  = "all";
    weekFilter.value      = "all";
    unveilingFilter.value = "all";
    renderContracts();
});

// ── Actions ───────────────────────────────────────────────────────────────────

function openSchedule(id) {
    document.getElementById("modal-schedule").classList.add("open-modal");
    document.getElementById("form-id").value = id;
}

function confirmDelete(id) {
    if (confirm("⚠️ Are you sure you want to DELETE contract #" + id + "?\nThis cannot be undone.")) {
        const form    = document.createElement('form');
        form.method   = 'POST';
        form.action   = '';
        const cid     = document.createElement('input');
        cid.type      = 'hidden';
        cid.name      = 'contractid';
        cid.value     = id;
        const btn     = document.createElement('input');
        btn.type      = 'hidden';
        btn.name      = 'delete';
        btn.value     = '1';
        form.appendChild(cid);
        form.appendChild(btn);
        document.body.appendChild(form);
        form.submit();
    }
}

function closeMod(id) {
    if (!id || id === "delete-resp") {
        const el = document.querySelector("#delete-resp");
        if (el) el.remove();
    } else {
        document.querySelector(`#${id}`).classList.remove("open-modal");
    }
}

fetchContracts();
</script>

<?php if (!empty($del_resp)) echo $del_resp; ?>
<script>
if (document.querySelector("#delete-resp")) {
    setTimeout(() => {
        const m = document.querySelector("#delete-resp");
        if (m) m.remove();
    }, 4000);
}
</script>
</body>
</html>
