<?php
session_start();
require_once '../../../office/admin/includes/db.php';
require_once '../../../office/admin/includes/auth.php';

// Clearance 1 or 2 can update stones
if (empty($_SESSION['app_session']) || $_SESSION['app_session'] !== 'active') {
    header('Location: ../../loggin-in/'); exit;
}
$_plant_clearance = (int)($_SESSION['security_clearance'] ?? 0);
if (!in_array($_plant_clearance, [1, 2], true)) {
    header($_plant_clearance === 3 ? 'Location: ../scheduled-stones/' : 'Location: ../../404/'); exit;
}

include_once "../../global/constr.php";

$content = "";
$response = "";
$del_resp= "";

if(isset($_GET['id'])){
    $id = trim($_GET['id']);

    $foundStatus = searchById($id);

    if($foundStatus != null){
        $content = '
            <form id="contractForm" method="POST" action="#">
            <div class="row g-3">
                <!-- Left Column -->
                <div class="col-md-6">
                    <!-- Contract No -->
                    <div class="mb-3">
                        <label for="contractNo" class="form-label">Contract No</label>
                        <input type="text" class="form-control" id="contractNo" 
                                value="'.$foundStatus[0]["id"].'" readonly name="contract_id">
                    </div>
                    
                    <!-- Stone Name -->
                    <div class="mb-3">
                        <label for="stoneName" class="form-label">Stone Name</label>
                        <input type="text" class="form-control" id="stoneName" 
                                value="'.$foundStatus[0]["stone_name"].'" name="stone_name">
                    </div>
                    
                    <!-- Deceased Name -->
                    <div class="mb-3">
                        <label for="deceasedName" class="form-label">Deceased Name</label>
                        <input type="text" class="form-control" id="deceasedName" 
                                value="'.$foundStatus[0]["deseased_name"].'" name="deseased_name">
                    </div>
                    
                    <!-- Extras -->
                    <div class="mb-3">
                        <label for="extras" class="form-label">Extras</label>
                        <textarea class="form-control" id="extras" rows="3" name="extras">'.$foundStatus[0]["extras"].'</textarea>
                    </div>
                    
                    <!-- Status -->
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status"  name="status">
                            <option value="manufacturing">Manufacturing</option>
                            <option value="pending">Pending</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div class="col-md-6">
                    <!-- Contact Name -->
                    <div class="mb-3">
                        <label for="contactName" class="form-label">Contact Name</label>
                        <input type="text" class="form-control" id="contactName" 
                                value="'.$foundStatus[0]["contact_name"].'"  name="contact_name">
                    </div>
                    
                    <!-- Contact Numbers -->
                    <div class="mb-3">
                        <label class="form-label">Contact Numbers</label>
                        <input type="tel" class="form-control mb-2" id="contactNo1" 
                                value="'.$foundStatus[0]["contact_no1"].'" placeholder="Primary number" name="contact_no1">
                        <input type="tel" class="form-control" id="contact_no2" 
                                value="'.$foundStatus[0]["contact_no2"].'" placeholder="Secondary number" name="contact_no2">
                    </div>
                    
                    <!-- Services -->
                    <div class="mb-3">
                        <label class="form-label">Services</label>
                        <div class="form-check">
                            <select id="funeral" name="funeral" name="funeral">
                                <option>No</option>
                                <option>Yes</option>
                            </select>
                            <label class="form-check-label" for="funeral">Funeral</label>
                        </div>
                        <div class="form-check">
                            <label class="form-check-label" for="unveiling">Unveiling</label>
                            <input class="form-control mb-2" type="date" value="'.$foundStatus[0]["unveiling"].'" id="unveiling" name="unveiling">
                        </div>
                    </div>
                    
                    <!-- Shop -->
                    <div class="mb-3">
                        <label for="shop" class="form-label">Shop</label>
                         <select class="form-select" id="shop" name="shop">h
                            <option selected>Wim</option>
                            <option >Zion</option>
                            <option>RBT</option>
                        </select>
                    </div>
                    
                    <!-- Location -->
                    <div class="mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" 
                                value="'.$foundStatus[0]["gy"].'" name="gy">
                    </div>
                </div>
            </div>
            
            <!-- Form Actions -->
            <div class="row mt-4">
                <div class="col-12 d-flex justify-content-end gap-2">
                    <button type="reset" class="btn btn-secondary px-4">Reset</button>
                    <button type="submit" class="btn btn-primary px-4" name="update-btn-contract">Update Changes</button>
                </div>
            </di
        ';
    }else{
        $del_resp  = '
            <div class="container-fluid wrong" id="delete-resp">
                <section class="success">
                    <div class="mod-head">
                    <a href="../add/"><h5>Add New</h5></a>
                    </div>
                    <h2 class="response">Contract: '.$id.'</h2>
                    <p class="red err">Contract no found</p>
                    <a href="../"><p class="back err">Back Home</p></a>
                </section>
            </div>
        ';
    }



    function setShop(){
        $shop = $foundStatus[0]["shop"];

        if($shop == "Wim"){
            return '
                <select class="form-select" id="shop" name="shop">
                    <option selected>Wim</option>
                    <option >Zion</option>
                    <option>RBT</option>
                </select>
            ';
        }elseif ($shop == "Zion") {
            return '
                <select class="form-select" id="shop" name="shop">
                    <option>Wim</option>
                    <option selected>Zion</option>
                    <option>RBT</option>
                </select>
            ';
        }else {
            return '
                <select class="form-select" id="shop" name="shop">
                    <option>Wim</option>
                    <option selected>Zion</option>
                    <option>RBT</option>
                </select>
            ';
        }
    }
}


if(isset($_POST['update-btn-contract'])){
    $id = trim($_POST['contract_id']);
    $stone_code = trim($_POST['stone_name']);
    $extras = trim($_POST['extras']);
    $status = trim($_POST['status']);
    $contact_name = trim($_POST['contact_name']);
    $contact_no2 = trim($_POST['contact_no2']);
    $contact_no1 = trim($_POST['contact_no1']);
    $shop = trim($_POST['shop']);
    $funeral = trim($_POST['funeral']);
    $unveiling = trim($_POST['unveiling']);
    $gy = trim($_POST['gy']);
    $deseased_name = trim($_POST['deseased_name']);
   
    $created_at = date('d-m-y');
    $response = updateContract($id , $stone_code,$extras, $status, $contact_name,$contact_no2 ,$contact_no1 , $shop , $funeral , $unveiling , $created_at, $gy, $deseased_name);
}



//UIPDATE STATUS RESPONDE
if(isset($_GET['update_Status'])){
    $contract = trim($_GET['id']);
    $del_status = trim($_GET['update_Status']);
   
    if($del_status == 1){
        $del_resp  = '
            <div class="container-fluid" id="delete-resp">
                <section class="success">
                    <div class="mod-head">
                    <h5 onclick="closeMod()">X</h5>
                    </div>
                    <h2 class="response">Contract: '.$contract.'</h2>
                    <p class="green">Has been successfully Updated</p>
                </section>
            </div>
        ';
    }else{
        $del_resp  = '
            <div class="container-fluid" id="delete-resp">
                <section class="error">
                    <div class="mod-head">
                    <h5 onclick="closeMod()">X</h5>
                    </div>
                    <h2 class="response">Contract: '.$contract.'</h2>
                    <p class="red">Something Has Gone Wrong</p>
                </section>
            </div>
        ';
    }

    
}

//SERACH BY ID
function searchById($id){
    $sql = "SELECT * FROM `tombstones_installations` WHERE id='$id'";
    $results = mysqli_query($GLOBALS['con'],$sql);
    $rowCount = mysqli_num_rows($results);

    if( $rowCount != 0){

        if( $rowCount == 1){
            //IF ONE USED FOR SEARCHING CONTRACT ID
            $contract = mysqli_fetch_all($results, MYSQLI_ASSOC);
            return  $contract;
        }

    }else{
        return null;
    }
}

function updateContract($id , $tone_code,$extras, $status, $contact_name,$contact_no2 ,$contact_no1 , $shop , $funeral , $unveiling , $created_at, $gy ,  $deseased_name){
    // $sql = "INSERT INTO `tombstones_installations`(`id`, `Stone_name`, `extras`, `contact_name`, `contact_no1`, `contact_no2`, `funeral`, `shop`, `status`, `unveiling`, `created_at`, `gy`, `deseased_name`) VALUES ('$id', '$tone_code', '$extras', '$status', '$contact_no1 ', '$contact_no2', '$funeral', '$shop ', '$status', '$unveiling', '$created_at','$gy', '$deseased_name')";
    $sql = "UPDATE `tombstones_installations` SET `stone_name`='$tone_code',`extras`='$extras',`contact_name`='$contact_name',`contact_no1`='$contact_no1 ',`contact_no2`='$contact_no2',`funeral`='$funeral',`shop`='$shop',`status`='$status',`unveiling`='$unveiling',`gy`='$gy',`deseased_name`='$deseased_name' WHERE `id`='$id'";
    $msg = "";

   

    if($id != "" || $tone_code != "" || $extras != "" || $contact_name != "" || $contact_no1 != "" || $unveiling != ""){

        $serer_resp =  mysqli_query($GLOBALS['con'],$sql);

         if($serer_resp != 1 ){
            header("Location:index.php?update_Status=0&responde=$serverStatus&id=$id");
        }else{
            header("Location:index.php?update_Status=1&responde=$serverStatus&id=$id");
        }
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contract Details Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-orange: #FF6B00;
            --complementary-blue: #005A9C;
            --light-orange: #FFF4E6;
        }
        :root {
            --primary-color: #FF6B00;  /* Orange */
            --secondary-color: #005A9C; /* Complementary blue */
        }
        #backtbn {
            margin: 10px;
            width: 120px;
            height: 44px;
            margin-bottom: 0px;
            border-radius: 12px;
            border: none;
            background: black;
            color: orange;
            font-size: 23px;
            font-weight: 700;
            font-style: italic;
            transition: all 0.6s ease;
        }
        #backtbn:hover {
            background : #ff6b00;
            color : white;
            letter-spacing : 1.1px;
            border : 2px solid black;
        }
        .custom-header {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
            border-radius: 0.5rem;
            margin-bottom: 2rem;
        }
        body {
            background-color: #FFF4E6;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        .card {
            border: 2px solid var(--primary-color);
            border-radius: 15px;
        }
        #delete-resp {
            width: 100%;
            background: radial-gradient(circle at 20% 50%, #ffa630cc 0%, #ff6b35 30%, #cc5500e8 70%, #ffd335e8 100%);
            height: 100vh;
            position: fixed;
            z-index: 1000;
            top: 0;
            left: 0;
            text-align :center;
        }section {
            width: 100%;
            max-width: 500px;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            position: absolute;
            animation: fadeIn 0.3s ease-out;
            z-index: 3500;
            top: 43%;
            left: 50%;
            transform: translate(-50%,-50%);
        }
        .mod-head {
            background-color: var(--primary-orange);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: flex-end;
            align-items: flex-end;
        }
        .mod-head h5 {
            cursor: pointer;
            transition: opacity 0.2s;
            font-size: 39px;
            padding: 0px;
            margin: 0px;
            color: #ff6000;
            font-weight: 700;
        }

        .mod-head h5:hover {
            opacity: 0.8;
        }
        .response {
            color: #ff6000;
            font-size: 1.5rem;
            font-weight: 600;
            padding: 25px 20px 10px;
            border-bottom: 1px solid var(--light-gray);
        }
        section p {
            line-height: 1.5;
            
            font-size: 26px;
            text-decoration: underline;
            text-decoration-thickness: 4px;
            font-style: italic;
            color: #ff6000;
            font-weight: 700;
        }
        section .err {
            padding: 5px;
        }
        .back {
            background: orange;
            transition: all 0.6s ease;
            color: white;
            border-radius: 8px;
            width: 187px;
            margin: 0px auto 19px auto;
            cursor: pointer;
        }
        .red {
            color : #ff0000 !important;
        }
        .green {
            color :rgb(88, 214, 15) !important;
        }
         section.success {
            border-top: 4px solid var(--success-green);
            box-shadow: 10px 10px 7px 1px #0000007d;
        }
        section.success .mod-head {
            background-color: var(--success-green);
        }
        /* Error state variation */
        section.error {
            border-top: 4px solid var(--error-red);
        }
        section.error .mod-head {
            background-color: var(--error-red);
        }
        /* Warning state variation */
        section.warning {
            border-top: 4px solid var(--warning-yellow);
        }
        section.warning .mod-head {
            background-color: var(--warning-yellow);
        }
        .wrong .mod-head {
            border : 3px solid  #ff6000 ;
        }
        #delete-resp {
            width: 100%;
            background: radial-gradient(circle at 20% 50%, #ffa630cc 0%, #ff6b35 30%, #cc5500e8 70%, #ffd335e8 100%);
            height: 100vh;
            position: fixed;
            z-index: 1000;
            top: 0; 
            left: 0;
            text-align :center;
        }
        .actBtn {
            margin: 5px;
            border-radius: 7px;
            width: 90px;
            transition: all 0.6s ease;
        }
        #backtbn {
            margin: 10px;
            width: 120px;
            height: 44px;
            margin-bottom: 0px;
            border-radius: 12px;
            border: none;
            background: black;
            color: orange;
            font-size: 23px;
            font-weight: 700;
            font-style: italic;
            transition: all 0.6s ease;
        }
        #backtbn:hover {
            background: #ff6b00;
            color: white;
            letter-spacing: 1.1px;
            border: 2px solid black;
        }
        .form-label {
            color: var(--secondary-color);
            font-weight: 500;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #E55A00;
            border-color: #E55A00;
        }

        .btn-secondary {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(255, 107, 0, 0.25);
        }

        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .stretch{width:100%!important;margin:8px auto;}
        body {
            background-color: var(--light-orange);
            padding: 20px;
        }
        
        .form-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-top: 5px solid var(--primary-orange);
        }
        
        .form-header {
            color: var(--complementary-blue);
            border-bottom: 2px solid var(--light-orange);
            padding-bottom: 15px;
        }
        
        .form-label {
            font-weight: 500;
            color: var(--complementary-blue);
        }
        
        .btn-primary {
            background-color: var(--primary-orange);
            border-color: var(--primary-orange);
        }
        #backtbn {
            margin: 10px;
            width: 120px;
            height: 44px;
            margin-bottom: 0px;
            border-radius: 12px;
            border: none;
            background: black;
            color: orange;
            font-size: 23px;
            font-weight: 700;
            font-style: italic;
            transition: all 0.6s ease;
        }
        #backtbn:hover {
            background: #ff6b00;
            color: white;
            letter-spacing: 1.1px;
        }
        .btn-secondary {
            background-color: var(--complementary-blue);
            border-color: var(--complementary-blue);
        }
        main {
            display :flex;
            justify-content : space-around;
            align-items : center;
            flex-direction : column;
        }
         .mod-head {
            background : black !important;
         }
    </style>
</head>
<body>
<main class="container-fluid">

<a href="../"><button class="actBtn" id="backtbn">Back</button></a>
 <?=$response?>
 <?=$del_resp?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="form-card p-4 my-4">
                <h2 class="form-header mb-4">Contract Details</h2>
                <?=$content ?>
            </div>
        </div>
    </div>
</div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('contractForm').addEventListener('onchange', function(e) {
    e.preventDefault();
    
    // Form validation
    const contactNo1 = document.getElementById('contact_no1').value;
    const contactNo2 = document.getElementById('contact_no2').value;
    
    if (!contactNo1 && !contactNo2) {
        alert('Please provide at least one contact number');
        return;
    }
    
    // Collect all form data
    const formData = {
        contractNo: document.getElementById('contractNo').value,
        stoneName: document.getElementById('stoneName').value,
        deceasedName: document.getElementById('deceasedName').value,
        extras: document.getElementById('extras').value,
        status: document.getElementById('status').value,
        contactName: document.getElementById('contactName').value,
        contactNo1: contactNo1,
        contactNo2: contactNo2,
        funeral: document.getElementById('funeral').checked,
        unveiling: document.getElementById('unveiling').checked,
        shop: document.getElementById('shop').value,
        location: document.getElementById('location').value
    };
    
    console.log('Form data:', formData);
    alert('Form submitted successfully!');
});
//closing Delete mod
function closeMod(){
    const url = window.location.search;
    const queryString = url.split('?')[1];
    const params = new URLSearchParams(queryString);
    let id = params.get('id')

    // document.querySelector("#delete-resp").style.display = "none";
    window.location.href = `index.php?id=${id}`;
}

document.querySelector(".back").addEventListener("click", ()=> window.location.href = "../")
</script>
</body>
</html>
