<?php
session_start();
require_once '../../office_v2/admin/includes/auth.php';
destroy_session();
header('Location: ../loggin-in/');
exit;
