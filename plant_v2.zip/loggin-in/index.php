<?php
session_start();

// Re-use the office auth system — adjust path to wherever auth.php lives on your server.
// Both apps share ONE employees table, ONE login system.
require_once '../../office_v2/admin/includes/db.php';
require_once '../../office_v2/admin/includes/auth.php';

// ── Already logged in → redirect to correct area ──────────────────────────────
if (!empty($_SESSION['app_session']) && $_SESSION['app_session'] === 'active') {
    $clearance = (int)($_SESSION['security_clearance'] ?? 0);
    switch ($clearance) {
        case 1: header('Location: ../plant/home/');             exit;
        case 2: header('Location: ../plant/home/');             exit;
        case 3: header('Location: ../plant/scheduled-stones/'); exit;
        default: header('Location: ../404/');                   exit;
    }
}

$error       = false;
$no_access   = false;
$user_error  = '';
$pass_error  = '';
$email_error = '';

if (isset($_POST['log-in'])) {
    $username = trim($_POST['name']     ?? '');
    $password =       $_POST['password'] ?? '';
    $email    = trim($_POST['email']    ?? '');

    if ($email    === '') $email_error = 'Email cannot be empty...';
    if ($username === '') $user_error  = 'Please provide your name...';
    if ($password === '') $pass_error  = 'Password cannot be empty...';

    if ($email !== '' && $password !== '' && $username !== '') {
        $user = attempt_login($email, $password, $username);

        if ($user) {
            create_session($user);
            $clearance = (int)$user['security_clearance'];

            switch ($clearance) {
                case 1: header('Location: ../plant/home/');             exit;
                case 2: header('Location: ../plant/home/');             exit;
                case 3: header('Location: ../plant/scheduled-stones/'); exit;
                default:
                    // clearance 0 — attempt_login returns null for 0, so this is a fallback
                    destroy_session();
                    header('Location: ../404/');
                    exit;
            }
        } else {
            // null returned — wrong password OR clearance = 0 (no access)
            $error = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login — WIM Corporation</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #fff8f3; }
        h3 {
            text-align: center;
            font-size: 32px;
            font-weight: 700;
            color: #FF7F00;
            text-shadow: 1px 2px 1px black;
        }
        #log-inform {
            width: 100%;
            max-width: 400px;
            margin: 10px auto 50px auto;
            padding: 30px;
            background-color: #f9f9f9;
            border: 2px solid #FF7F00;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .form-group label {
            font-size: 16px;
            font-weight: bold;
            color: #FF7F00;
        }
        .form-group input {
            border: 2px solid #ddd;
            border-radius: 5px;
            transition: border-color 0.3s ease;
        }
        .form-group input:focus {
            border-color: #FF5500;
            box-shadow: 0 0 5px rgba(255,127,0,0.5);
        }
        .error { color: red; font-size: 14px; margin-top: 4px; }
        .btn-submit {
            width: 100%;
            padding: 10px;
            background-color: #FF7F00;
            color: #fff;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-submit:hover { background-color: #FF5500; }
        figure {
            width: 100%;
            display: flex;
            justify-content: center;
            margin: 0 auto;
        }
        figure p {
            text-transform: uppercase;
            text-decoration: underline;
            text-decoration-color: #FF7F00;
            text-decoration-thickness: 3px;
            font-size: 18px;
            cursor: pointer;
            color: #ff7f00;
            transition: all 0.3s ease-in-out;
        }
        figure p:hover { color: #f34c00; font-weight: 700; }
        /* ── Access denied overlay ── */
        #failed {
            width: 100%;
            height: 100vh;
            background: #ff7f00e8;
            position: fixed;
            top: 0; left: 0;
            display: flex;
            z-index: 1000;
        }
        .access {
            width: 350px;
            margin: auto;
            border-radius: 12px;
            background-color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            padding: 20px;
            align-items: center;
            box-shadow: 7px 9px 9px 2px #00000094;
            position: relative;
        }
        .access h4 {
            position: absolute;
            top: 15px; left: 20px;
            color: black;
            border: 3px solid red;
            background: red;
            width: 60px; height: 40px;
            border-radius: 12px 0 0 0;
            text-align: center;
            line-height: 40px;
            cursor: pointer;
            transition: all 0.6s ease-in-out;
            margin: 0;
        }
        .access h4:hover { background-color: wheat; color: red; border-radius: 8px; }
        .access h3 { color: red; font-weight: 800; font-size: 32px; margin-bottom: 10px; text-decoration: underline; font-style: italic; }
        .access p  { color: #333; text-align: center; }
        .access a button {
            margin-top: 12px;
            background-color: #FF7F00;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 8px 20px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .access a button:hover { background-color: #FF5500; }
        .col-btn { display: flex; justify-content: flex-start; width: 100%; }
        .col-btn p { opacity: 0; margin-left: 10px; transition: opacity 0.3s; }
        .col-btn:hover p { opacity: 1; }
    </style>
</head>
<body>

<?php if ($error): ?>
<section id="failed">
    <div class="access">
        <div class="col-btn">
            <h4 id="closeMod">X</h4>
            <p>Close</p>
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;margin-top:30px">
            <h3>ACCESS DENIED!</h3>
            <p>Incorrect credentials or your account has no access.<br>Contact your administrator.</p>
            <a href="../readonly/"><button>Go Back</button></a>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="container-fluid" style="padding-top:30px">
    <h3>WIM PLANT — LOG IN</h3>
    <div class="container">
        <form id="log-inform" method="POST" action="#">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" class="form-control" name="name"
                       placeholder="Enter name..." required
                       value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                <?php if ($user_error): ?><p class="error"><?= htmlspecialchars($user_error) ?></p><?php endif; ?>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email"
                       placeholder="Your email" required
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                <?php if ($email_error): ?><p class="error"><?= htmlspecialchars($email_error) ?></p><?php endif; ?>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="password"
                       placeholder="Password" required>
                <?php if ($pass_error): ?><p class="error"><?= htmlspecialchars($pass_error) ?></p><?php endif; ?>
            </div>
            <button type="submit" class="btn-submit" name="log-in">Submit</button>
        </form>
        <figure>
            <p onclick="alert('Password recovery not yet set')">password recovery</p>
        </figure>
    </div>
</section>

<script>
    const closeModBtn = document.querySelector('#closeMod');
    const failedMod   = document.querySelector('#failed');
    if (closeModBtn && failedMod) {
        closeModBtn.addEventListener('click', () => failedMod.style.display = 'none');
    }
</script>
</body>
</html>
