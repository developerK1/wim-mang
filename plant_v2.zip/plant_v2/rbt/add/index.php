<?php
include_once "../includes/functions.php";
$response = "";

if(isset($_POST['add-list'])){
    $id = trim($_POST['contract_id']);
    $stone_code = trim($_POST['stone_code']);
    $extras = trim($_POST['extras']);
    $status = trim($_POST['status']);
    $contact_name = trim($_POST['contact_name']);
    $contact_no2 = trim($_POST['contact_no2']);
    $contact_no1 = trim($_POST['contact_no1']);
    $shop = "RBT";
    $funeral = trim($_POST['funeral']);
    $unveiling = trim($_POST['unveiling']);
     $gy = trim($_POST['gy']);
    $deseased_name = trim($_POST['deseased_name']);
    $number =  trim($_POST['number']);
   
    $created_at = date('d-m-y');
    $response = update_tusk($id , $stone_code,$extras, $status, $contact_name,$contact_no2 ,$contact_no1 , $shop , $funeral , $unveiling , $created_at, $gy,  $deseased_name, $number);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stone Code Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6B00;  /* Orange */
            --secondary-color: #005A9C; /* Complementary blue */
        }
        #backtbn {
            margin: 10px;
            width: 120px;
            height: 44px;
            margin-bottom: 0px;
            border-radius: 12px;
            border: none;
            background: black;
            color: orange;
            font-size: 23px;
            font-weight: 700;
            font-style: italic;
            transition: all 0.6s ease;
        }
        #backtbn:hover {
            background : #ff6b00;
            color : white;
            letter-spacing : 1.1px;
            border : 2px solid black;
        }
        .custom-header {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
            border-radius: 0.5rem;
            margin-bottom: 2rem;
        }
        body {
            background-color: #FFF4E6;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        .card {
            border: 2px solid var(--primary-color);
            border-radius: 15px;
        }

        .form-label {
            color: var(--secondary-color);
            font-weight: 500;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #E55A00;
            border-color: #E55A00;
        }

        .btn-secondary {
            background-color: var(--secondary-color);
            border-color: var(--secondary-color);
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(255, 107, 0, 0.25);
        }

        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .stretch{width:100%!important;margin:8px auto;}
    </style>
</head>
<body>
<main class="container-fluid">
    <button id="backtbn">Back</button>
    <div class="container py-5">
        <div class="custom-header">
            <?php 
                if($response == ""){
                    echo '<h1>Installation List</h1>
                        <p class="mb-0">Please fill in all required details</p>' ;
                }else{
                    echo $response ;
                }
            ?>
            
        </div>
    <figure></figure>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <form id="mainForm" class="card p-4" method="POST" action="">
                    <h2 class="mb-4 text-center" style="color: var(--primary-color);">Stone Code Information</h2>
                    
                    <div class="row g-4">
                        <!-- Left Column -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Contract No.</label>
                                <input type="text" class="form-control" name="contract_id" required>
                            </div>

                            <div class="form-group mt-3">
                                <label class="form-label">Stone Code</label>
                                <input type="text" class="form-control" name="stone_code" required>
                            </div>
                            <div class="form-group mt-3">
                                <label class="form-label">Deceased Name</label>
                               <input type="text" class="form-control" id="deceasedName" 
                                name="deseased_name">
                            </div>
                            <div class="form-group mt-3">
                                <label class="form-label">Extras</label>
                                <textarea class="form-control" name="extras" rows="3"></textarea>
                            </div>
                            <div class="form-group mt-3">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="manufacturing">Manufacturing</option>
                                    <option value="pending">Pending</option>
                                    <option value="paused">Complete</option>
                                </select>
                            </div>
                        </div>

                        <!-- Right Column -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Contact Name</label>
                                <input type="text" class="form-control" name="contact_name" required>
                            </div>

                            <div class="form-group mt-3">
                                <label class="form-label">Contact Numbers</label>
                                <input type="tel" class="form-control mb-2" name="contact_no1" 
                                       placeholder="Primary number" pattern="[0-9]{10}">
                                <input type="tel" class="form-control" name="contact_no2" 
                                       placeholder="Secondary number" pattern="[0-9]{10}">
                            </div>

                            <div class="form-group mt-3">
                                <div class="form-group mt-3">
                                    <label class="form-label">Funeral</label>
                                    <select name="funeral" id="funeral" class="stretch">
                                        <option>No</option>
                                        <option>Yes</option>
                                    </select>
                                    
                                </div>
                                <div class="form-group mt-3">
                                    <label class="form-label">Approved Date</label>
                                    <input class="stretch" type="date" name="unveiling" id="unveiling">
                                </div>

                                <div class="form-group mt-3">
                                    <label class="form-check-label" for="unveiling">Grave Location</label>
                                    <input class="stretch" type="text" name="gy" >
                                </div>
                            </div>

                            <div class="form-group mt-3">
                                <label class="form-label">Number Of Stones</label>
                                <input class="stretch" type="number" name="number" >
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-12 d-flex justify-content-end gap-2">
                            <button type="reset" class="btn btn-secondary px-4">Reset</button>
                            <button type="submit" name="add-list" class="btn btn-primary px-4">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.querySelector("#backtbn").addEventListener("click", ()=> window.location.href = "../")

    //    document.getElementById('mainForm').addEventListener('onchange', function(e) {
    //         e.preventDefault();
            
    //         // Form validation
    //         const contactNo1 = document.querySelector('input[name="contact_no1"]').value;
    //         const contactNo2 = document.querySelector('input[name="contact_no2"]').value;
            
    //         if (!contactNo1 && !contactNo2) {
    //             alert('Please provide at least one contact number');
    //             return;
    //         }

    //         // Phone number validation
    //         const phoneRegex = /^[0-9]{10}$/;
    //         if (contactNo1 && !phoneRegex.test(contactNo1)) {
    //             alert('Please enter a valid primary contact number');
    //             return;
    //         }
            
    //         if (contactNo2 && !phoneRegex.test(contactNo2)) {
    //             alert('Please enter a valid secondary contact number');
    //             return;
    //         }

    //         // If validation passes
           
    //         // You can add AJAX submission here
    //         this.reset();
    //     });
    </script>
</body>
</html>