<?php

include_once ("../includes/constr.php");

$sql =  "SELECT * FROM `tombstones_installations`";

$results = mysqli_query($con, $sql);
$contacts = mysqli_fetch_all($results, MYSQLI_ASSOC);

echo json_encode($contacts);
