<?php
session_start();
include_once "../includes/functions.php";

if(!isset($_SESSION['username'], $_SESSION['email'])){
   header("Location:../../loggin-in/");
}

$del_resp = "";

//DElete functionality
if(isset($_POST['delete'])){
    $contractID= trim($_POST['contractid']);
    deleteContract($contractID);
}

//scheduling functionality
if(isset($_POST['schedule'])){
    $contractID = trim($_POST['id']);
    $inst_date  = trim($_POST['installation_date']);
	
	
	if($inst_date == null){
		echo "<script>alert('Failed,INVALID DATE')</script>";
	}else{
echo "<script>alert('perfect')</script>";
		scheduleContract($contractID, $inst_date);
	}
	
    //scheduleContract($contractID, $inst_date);
}


//SCHEDULE After it hit functions.php file
if(isset($_GET['schedule_Status'])){
    $contract = trim($_GET['id']);
    $del_status = trim($_GET['schedule_Status']);
   
    if($del_status == 1){
        $del_resp  = '
            <div class="container-fluid" id="delete-resp">
                <section class="success">
                    <div class="mod-head">
                    <h5 onclick="closeMod()">X</h5>
                    </div>
                    <h2 class="response">Contract: '.$contract.'</h2>
                    <p class="green">Has been successfully scheduled</p>
                </section>
            </div>
        ';
    }else{
        $del_resp  = '
            <div class="container-fluid" id="delete-resp">
                <section class="error">
                    <div class="mod-head">
                    <h5 onclick="closeMod()">X</h5>
                    </div>
                    <h2 class="response">Contract: '.$contract.'</h2>
                    <p class="red">Something Has Gone Wrong</p>
                </section>
            </div>
        ';
    }

    
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stone Code Entry Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6B35;  /* Orange */
            --secondary-color: #004E89; /* Complementary blue */
            --accent-color: #FFD6BA;    /* Light orange accent */
        }

        .custom-header {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
            border-radius: 0.5rem;
            margin-bottom: 2rem;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(255,107,53,.25);
        }
        #data {
                    position: relative;
                }
                #update-status {
                    width : 100%;
                    height : 100%;
                    position: absolute;
                    top : 0px;
                    left : 0px;
                }
                #update-status  {
                    width : 100%;
                    height : 100%;
                    background-color: orange;
                }
                #loading {
                    width: 100%;
                    height: 149px;
                    text-align: center;
                    margin: 20px 27px 0px 6px;
                    display: flex;
                    box-shadow: 5px 8px 5px #0000007a;
                }
                #notice {
                    display: none;
                    height : 100vh;
                    text-align: center;
                }
                #notice aside, #cont {
                    display: flex;
                    align-items: center;
                    flex-direction: column;
                    justify-content: space-evenly;
                    margin: auto;
                    min-height: 140px;
                }
                #cont  {
                    justify-content: space-evenly;
                }
                .name {
                    font-style: italic;
                    color: orange;
                    text-shadow: 2px 1px 3px black;
                    font-weight: 700;
                    text-decoration: underline;
                    text-decoration-thickness: 4px;
                }
                .green {
                    background-color:black;
                }
                .green button {
                    background-color: rgb(30 255 0 / 85%) !important;
                }
                .green button:hover , 
                .greeen:hover {
                    background-color:orange !important;
                    color : black;
                    letter-spacing: 1.1px;
                    font-weight: 700;
                }
                .installed {
                    background-color : #ff450047;
                }
                #listings {
            padding-top: 30px;
        }
        #listings figure {
            margin: auto;
            color: orange;
            text-shadow: 1px 2px 2px black;
            font-size: 45px;
            line-height: 17px;
            font-weight: 900;
        
        }
        #listings figure p {
            cursor: pointer;
            color: rgb(193, 140, 42);
            transition: all 0.6s ease-in-out;
        }
        #listings figure p:hover {
            color: orangered;
            letter-spacing: 2px;
        }
        #heading {
            padding: 0;
            border-bottom: 5px solid rgb(255, 98, 0);
            border-top: 5px solid rgb(255, 98, 0);
            margin-top: 50px;
            margin-bottom: 0;
            border-left: 5px solid orange;
        }
        #tusks-container  article {
            border-bottom: 5px solid orange;
            border-right: 5px solid orange;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
        }
        #tusks-container .row:nth-child(2) article {
            border-top: 5px solid transparent;
            font-weight: 600;
            font-size: 18px;
        }
        .contracts-id {
            border-left: 5px solid orange;
        }
        #listings h1 {
            margin: auto;
            transition: all ease;
            animation: loading 2s infinite;
            font-weight: 900;
        }
        @keyframes loading {
            0% {
                transform: scale(0.8);
                color: orange;  
                text-shadow: 1px 2px 3px black;
            }
            25% {
                transform: scale(1);
            }
            50% {
                transform: scale(1);
            }
            75% {
                transform: scale(1);
                color: rgb(255, 149, 0);
                text-shadow: 1px 3px 4px black;
                letter-spacing: 2px;
            }
            100% {
                transform: scale(0.8);
            }
        }
        .h2-latest {
            font-size: 2.5rem;
            font-weight: 700;
            text-decoration: underline;
            color: #e75018;
            text-shadow: 1px 2px 2px black;
        }
        #heading p {
            font-weight: 700;
        }
        #data article h3 {
            color: orange;
            font-size: 2rem;
            text-shadow: 1px 2px 1px black;
            text-decoration: underline;
            font-weight: 700;
        }
        #data article {
            padding : 8px 5px;
        }
        #listings {
            transition: all ease;
            animation: loadingpar 2s infinite;
        }
        .contr-nom {
            color: orange;
            font-weight: 700;
            text-transform: uppercase;
            text-decoration: underline;
            text-decoration-thickness: 3px;
            font-style: italic;
            text-decoration-color: orangered;
            text-shadow: 1px 2px 2px black;
        }
        .tit {
            font-weight : 700;
            color: #e75018;
        }
        #data article aside p {
            margin : 5px 0px !important;
        }
        .para {
            text-transform: capitalize;
        }
        #action {
            display:flex;
            flex-direction : column;
        }
        .due {
            background-color: #ff9c9c;
        }
        :root {
            --primary-orange: #FF6B00;
            --complementary-blue: #005A9C;
            --light-orange: #FFF4E6;
            --dark-gray: #333333;
            --medium-gray: #666666;
            --light-gray: #EEEEEE;
            --success-green: #28a745;
            --error-red: #dc3545;
            --warning-yellow: #ffc107;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--light-orange);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            flex-direction: column;
        }
        section {
            width: 100%;
            max-width: 500px;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            position: absolute;
            animation: fadeIn 0.3s ease-out;
            z-index: 3500;
            top: 43%;
            left: 50%;
            transform: translate(-50%,-50%);
        }
        .mod-head {
            background-color: var(--primary-orange);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: flex-end;
            align-items: flex-end;
        }
        .mod-head h5 {
            cursor: pointer;
            transition: opacity 0.2s;
            font-size: 39px;
            padding: 0px;
            margin: 0px;
            color: #ff6000;
            font-weight: 700;
        }

        .mod-head h5:hover {
            opacity: 0.8;
        }
        .response {
            color: #ff6000;
            font-size: 1.5rem;
            font-weight: 600;
            padding: 25px 20px 10px;
            border-bottom: 1px solid var(--light-gray);
        }
        section p {
            line-height: 1.5;
            padding: 15px 20px 25px;
            font-size: 26px;
            text-decoration: underline;
            text-decoration-thickness: 4px;
            font-style: italic;
            color: #ff6000;
            font-weight: 700;
        }
        .red {
            color : #ff0000 !important;
        }
        .green {
            color :rgb(88, 214, 15) !important;
        }
        /* Success state variation */
        section.success {
            border-top: 4px solid var(--success-green);
        }

        section.success .mod-head {
            background-color: var(--success-green);
        }

        /* Error state variation */
        section.error {
            border-top: 4px solid var(--error-red);
        }

        section.error .mod-head {
            background-color: var(--error-red);
        }

        /* Warning state variation */
        section.warning {
            border-top: 4px solid var(--warning-yellow);
        }

        section.warning .mod-head {
            background-color: var(--warning-yellow);
        }
        #delete-resp {
            width: 100%;
            background: radial-gradient(circle at 20% 50%, #ffa630cc 0%, #ff6b35 30%, #cc5500e8 70%, #ffd335e8 100%);
            height: 100vh;
            position: fixed;
            z-index: 1000;
            top: 0;
            left: 0;
            text-align :center;
        }
        .actBtn {
            margin: 5px;
            border-radius: 7px;
            width: 90px;
            transition: all 0.6s ease;
        }
        #backtbn {
            margin: 10px;
            width: 120px;
            height: 44px;
            margin-bottom: 0px;
            border-radius: 12px;
            border: none;
            background: black;
            color: orange;
            font-size: 23px;
            font-weight: 700;
            font-style: italic;
            transition: all 0.6s ease;
        }
		#backtbn-view  {
			margin: 10px;
			width: 179px;
			height: 44px;
			margin-bottom: 0px;
			border-radius: 12px;
			border: none;
			background:orange; 
			color: black;
			font-size: 19px;
			font-weight: 700;
			font-style: italic;
			transition: all 0.6s ease;
		}
		 #backtbn-view.log-out  {
					margin: 10px;
					width: 179px;
					height: 44px;
					margin-bottom: 0px;
					border-radius: 12px;
					border: none;
					background:red; 
					color: black;
					font-size: 19px;
					font-weight: 700;
					font-style: italic;
					transition: all 0.6s ease;
				}
		#backtbn-view:hover {
			letter-spacing: 1.1px;
            border: 2px solid black;
			background:black; 
			color: #ff6c00;
		}
        #backtbn:hover {
            background: #ff6b00;
            color: white;
            letter-spacing: 1.1px;
            border: 2px solid black;
        }
		.schedule {
			background-color: #ff8a00;
			padding: 2px;
			margin: 5px;
			border-radius: 3px;
			text-decoration: none;
			color: #000000;
			transition : all 0.6s ease-in-out;
		}
		.schedule:hover {
			background-color: #ff8a007d;
			border-radius: 3px;
			text-decoration: none;
		}
        form button {

            background: red;
        }
        form button:hover {
            letter-spacing : 1.1px;
            font-weight : 700;
            background : #ff000082;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
		#modal-schedule {
			position : fixed;
			z-index : 3000;
			width : 100%;
			height : 100vh;
			background-color : orange;
			top : 0px;
			left : 0px;
			padding : 10px;
			margin : 0px;
			display : none;
		}
		#modal-schedule.open-modal {
			display : flex !important;
		}
		#schedule-form {
			width: 450px;
			margin: auto;
			height: 171px;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			box-shadow: 2px 5px 6px 4px #00000099;
			padding: 8px;
			background: white;
			border-radius: 14px;
		}
		#schedule-form label {
			height: 100%;
			display: flex;
			margin: auto 0px;
			align-items: center;
			font-weight: 700;
			text-transform: none;
		}
		#schedule-form input {
			height : 41px;
		}
		#schedule-form button {
			height : 41px;
		}
		#btn-wrapper {
			display: flex;
			justify-content: space-between;
			flex-wrap: wrap;
			margin: 20px 0px;
		}
       @media(max-width:760px){
         #heading {
            display : none !important;
        }
        #tusks-container .row:nth-child(2) article {
            border: 5px solid orange;
        }
        .status {
            margin-bottom: 45px !important;
            box-shadow: 0px 7px 6px 2px #0000005e;
        }
       }
        /* Responsive adjustments */
        @media (max-width: 600px) {
            .response {
                font-size: 1.3rem;
                padding: 20px 15px 8px;
            }

            section p {
                padding: 12px 15px 20px;
                font-size: 0.95rem;
            }

            .mod-head {
                padding: 12px 15px;
            }
			#btn-wrapper {
				align-items : center;
				justify-content :center;
			}
        }
        @keyframes loadingpar {
            0% {
                box-shadow: 5px 8px 5px #0000007a;
            }
            100% {
                box-shadow: 8px 8px 12px #000000;
            }
        }
       
    </style>
</head>
<body>
<?=$del_resp?>
<main>
<figure id="modal-schedule" class="">

	<form method="POST" action="" id="schedule-form">
		<div style="display:flex;justify-content:space-between;">
			<label>Set the date</label>
			<p onclick="closeMod('modal-schedule')" style="width:50px; text-align:center;padding-right:10px;font-size:26px;cursor:pointer">X</p>
		</div>
		<input type="date" name="installation_date"/>
		<input type="text" name="id" id="form-id" value="" hidden />
		<button name="schedule">Schedule</button>
	</form>
</figure>
<div id="btn-wrapper" >
<a href="../add"><button class="actBtn" id="backtbn">Add New</button></a>
<a href="../log-out/"><button class="actBtn log-out" id="backtbn-view">Log out</button></a>
<a href="../upcoming/"><button class="actBtn" id="backtbn-view">View Scheduled</button></a>
</div>
<div class="container-fluid" id="listings">
        <!-- <h2>Contracts for <span class="year"></span></h2> -->
        <h2 class="h2-latest">The Approved Contracts</h2>
        <div class="container" id="tusks-container">
            <div class="row" id="heading">
                <article class="col-lg-3 col-md-3 contracts-id">
                    <aside>
                        <p>Contract</p>
                    </aside>
                </article>
                <article class="col-lg-3 col-md-3">
                    <aside>
                        <p>Stone Code</p>
                    </aside>
                </article>
                <article class="col-lg-3 col-md-3">
                    <aside>
                        <p>Location GY</p>
                    </aside>
                </article>
                <article class="col-lg-3 col-md-3">
                    <aside>
                        <p>Actions</p>
                    </aside>
                </article>
            </div>
            <div class="row" id="data">
                <figure class="col-lg-12 col-md-12" id="loading">
                    <h1>DATA LOADING...</h1>
                </figure>
            </div>
        </div>
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
let allContacts;

const goAdd = () => window.location.href = "../add/";


 const xhr = new XMLHttpRequest();

    xhr.open("Get", "../../global/data/all_contracts.php", true);

    xhr.onload = async function(){
        const contracts = await JSON.parse(this.responseText);
console.log(contracts)
        if(contracts.length != 0){

		const newContractList = contracts.filter(contract => contract.installation_date == "0000-00-00" );
		
		//asigning to global scope
		allContacts = newContractList ;
        
		getData(newContractList);
        }else if(contracts.length == 0){
			errorMsg = `
            <figure class="centery-col">
                <h2>NO Approved stones at this moment</h2>
                <p onclick="goAdd()">Add Stone</p>
            </figure>`;
			
			document.querySelector("#loading").innerHTML = errorMsg;
		}else{
            errorMsg = `
            <figure class="centery-col">
                <h2>Failed To Retrive Data</h2>
                <p onclick="reFetch()">Try Agin</p>
            </figure>`;

            document.querySelector("#loading").innerHTML = errorMsg;
        }
    }

xhr.send();

  // <a href="update-account/index.php?contract-id=${item.contract_id}">Update</a>
function templating(item){
    let week ;
     getWeeksSince(item.unveiling) ==  0? week =  "New Approved" :week = getWeeksSince(item.unveiling);
    //REASIGN VALUES FOR INSTALLATION AND UNCEILING FOR "0000/00/00" DATES
    let reAsignVals = val =>  val == "0000-00-00" ? "TF" : val ;
    let checkStatus = (stats =>{
           
        if(item.status == "Complete"){
            return `
                <article class="col-lg-3 col-md-3 installed">
                    <aside>
                        <h3><span class="tit">Location</h3>
                        <p class="para">${item.gy}</p>
                        <h3>Week</h3>
                        <p class="para">${week}</p>
                    </aside>
                </article>
            `;
        }else{
            return `
                <article class="col-lg-3 col-md-3">
                    <aside>
                        <h3><span class="tit">Location</h3>
                        <p class="para">${item.gy}</p>
                        <h3>Week</h3>
                        <p class="para">${week}</p>
                    </aside>
                </article>
            `;
        }
    })
 
    if(week >= 3){
//UPDFATE DIRECTULY TO TH ACCOUNT
	return `
            <article class="col-lg-3 col-md-3 contracts-id due" >
                <aside >
                    <p class="contr-nom para">${item.id}</p>

                    <p><span class="tit">Buyer</span> : ${item.contact_name}</p>
                    <p><span class="tit">-----------</span></p> 
                    <a href="../details/index.php?contract-id=${item.id}">View</a>
                </aside>
            </article>
            <article class="col-lg-3 col-md-3 due">
                <aside>
                    <p><span class="tit">Code </span> : ${item.stone_name}</p>
                    <p><span class="tit">-----------</span></p> 
                    <p><span class="tit">Extras </span> : ${item.extras}</p>
                </aside>
            </article>
            ${checkStatus()}
             <article class="col-lg-3 col-md-3 status due">
                <aside id="action">
                    <a href="../update/index.php?id=${item.id}">Update</a>
                    <form method="POST" action="">
                        <input type="tex" value="${item.id}" name="contractid" hidden/>
                       <button name="delete" class="actBtn">Delete</button>
                    </form>
					<p onclick="scheduleContract('${item.id}')"  class="schedule">Schedule</p>
                </aside>
            </article>
	    `;
    }else{
        //UPDFATE DIRECTULY TO TH ACCOUNT
	return `
            <article class="col-lg-3 col-md-3 contracts-id" >
                <aside >
                    <p class="contr-nom para">${item.id}</p>

                    <p><span class="tit">Buyer</span> : ${item.contact_name}</p>
                    <p><span class="tit">-----------</span></p> 
                    <a href="../details/index.php?contract-id=${item.id}">View</a>
                </aside>
            </article>
            <article class="col-lg-3 col-md-3">
                <aside>
                    <p><span class="tit">Code </span> : ${item.stone_name}</p>
                    <p><span class="tit">-----------</span></p> 
                    <p><span class="tit">Extras </span> : ${item.extras}</p>
                </aside>
            </article>
            ${checkStatus()}
             <article class="col-lg-3 col-md-3 status">
                <aside id="action">
                    <a href="../update/index.php?id=${item.id}">Update</a>
                      <form method="POST" action="">
                        <input type="tex" value="${item.id}" name="contractid" hidden/>
                        <button name="delete" class="actBtn">Delete</button>
                    </form>
					<p onclick="scheduleContract('${item.id}')"  class="schedule">Schedule</p>
                </aside>
            </article>
	    `;
    }
    
        
}
//<a href="update-installation/index.php?contract-id=${item.id}">Update</a>
// <a href="update-installation/index.php?contract-id=${item.id}">UpDeletedate</a>
function getData(data){

	const formatedHTML = data.map(templating).join(" ");
	
	//INSERTING DATA TO  THE DOM
    document.querySelector("#data").innerHTML = formatedHTML;
}
function reFetch(){
    window.location.reload()
}
function getWeeksSince(passedDate) {
    // Parse the input date
    const targetDate = new Date(passedDate);
    
    // Get today's date
    const today = new Date();
    
    // Convert both dates to UTC to avoid timezone issues
    const utcToday = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate());
    const utcTarget = Date.UTC(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate());
    
    // Calculate difference in milliseconds
    const differenceMs = utcToday - utcTarget;
    
    // Convert milliseconds to weeks
    const weeks = Math.floor(differenceMs / (1000 * 60 * 60 * 24 * 7));
    
    return weeks;
}

//closing Delete mod
function closeMod(id){
	id == null ? document.querySelector("#delete-resp").style.display = "none" : document.querySelector(`#${id}`).classList.remove("open-modal")
}

const scheduleContract = (contrID) =>{
	document.querySelector("#modal-schedule").classList.add("open-modal");
	document.querySelector("#form-id").value = `${contrID}`;
}
</script>
</body>
</html>