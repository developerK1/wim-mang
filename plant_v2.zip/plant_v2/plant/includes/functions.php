<?php

include_once "../../global/constr.php";

$GLOBALS['con'] = $con;

//UPDATE BALANCE
function updateContract($id , $stone_code,$extras, $status, $contact_name,$contact_no2 ,$contact_no1 , $shop , $funeral , $unveiling , $created_at, $gy, $deseased_name){
    $sql = "INSERT INTO `tombstones_installations`(`id`, `Stone_name`, `extras`, `contact_name`, `contact_no1`, `contact_no2`, `funeral`, `shop`, `status`, `unveiling`, `created_at`, `gy`,`deseased_name`) VALUES ('$id', '$tone_code', '$extras', '$status', '$contact_name' , '$contact_no1 ', '$contact_no2', '$funeral', '$shop ', '$status', '$unveiling', '$created_at','$gy','$deseased_name')";

// echo  $sql;
    if($id  != "" ||  $stone_code != "" || $extras != "" ||  $status != "" ||  $contact_name != "" || $contact_no2  != "" || $contact_no1  != "" ||  $shop  != "" ||  $funeral  != "" ||  $unveiling  != "" ||  $created_at != "" ||  $gy != "" ||  $deseased_name  != ""){
        
        $serverStatus = mysqli_query($GLOBALS['con'],$sql);
        if($serverStatus != 1 ){
            header("Location:index.php?update_Status=0&responde=$serverStatus&id=$id");
        }else{
            header("Location:index.php?update_Status=1&responde=$serverStatus&id=$id");
        }
    }

}


//DELETING TUSKS
function deleteContract($contractID){
    $sql = "DELETE FROM `tombstones_installations` WHERE `id` = '$contractID'";
	
		echo "<script>alert(".$sql.")</script>";
	
    $serverStatus =  mysqli_query($GLOBALS['con'],$sql);
    
    if($serverStatus != 1 ){
        header("Location:index.php?delete_Status=0&responde=$serverStatus&id=$contractID");
    }else{
         header("Location:index.php?delete_Status=1&responde=$serverStatus&id=$contractID");
    }
}

//scheduling	
function scheduleContract($id, $inst_date){
    $sql = "UPDATE `tombstones_installations` SET `installation_date`='$inst_date' WHERE `id`='$id'";


    if($id  != "" ||  $inst_date != "" ){
        
        $serverStatus = mysqli_query($GLOBALS['con'],$sql);

        if($serverStatus != 1 ){
            header("Location:index.php?schedule_Status=0&responde=$serverStatus&id=$id");
        }else{
            header("Location:index.php?schedule_Status=1&responde=$serverStatus&id=$id");
        }
    }

}

//FETCH BY NAME
function searchByName($term){
    $sql = "SELECT * FROM `contracts` WHERE buyer='$term'  OR contract_id='$term' ";
    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
   
    if( $rowCount != 0){

        if( $rowCount == 1){
            //IF ONE USED FOR SEARCHING CONTRACT ID
            $contract = mysqli_fetch_all($results, MYSQLI_ASSOC);
            return  $contract;
        }else{
            //IF MANY , USES NAME SAERCHE RESULTS
            $contracts = mysqli_fetch_all($results, MYSQLI_ASSOC);
            // return  json_encode($contract); WHENE USING JAVASCRIPT
            return $contracts;
        }

    }else{
        return null;
    }
}

//FETCH BY NAME
function searchById($contractID){
    $sql = "SELECT * FROM `tombstones_installations` WHERE id='$contractID'";
    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
   
    if( $rowCount != 0){
        $contract = mysqli_fetch_all($results, MYSQLI_ASSOC);
        return  $contract;
    }else{
        return null;
    }
}

function update_tusk($id , $tone_code,$extras, $status, $contact_name,$contact_no2 ,$contact_no1 , $shop , $funeral , $unveiling , $created_at, $gy ,  $deseased_name){
$sql = "INSERT INTO `tombstones_installations` (
    `id`, 
    `Stone_name`, 
    `extras`, 
    `status`, 
    `contact_name`, 
    `contact_no1`, 
    `contact_no2`, 
    `funeral`, 
    `shop`, 
    `unveiling`, 
    `created_at`, 
    `gy`, 
    `deseased_name`,
    `installation_date`
) VALUES (
    '$id', 
    '$tone_code', 
    '$extras', 
    '$status', 
    '$contact_name', 
    '$contact_no1', 
    '$contact_no2', 
    '$funeral', 
    '$shop', 
    '$unveiling', 
    '$created_at', 
    '$gy', 
    '$deseased_name', 
    '0000-00-00'
)";



    function checkId($id , $status){
        $sqlPer = "SELECT * FROM `tombstones_installations` WHERE `status` = '$status' AND `id`='$id'";
        $results =  mysqli_query($GLOBALS['con'],$sqlPer);
        $rowCount = mysqli_num_rows($results);

        if( $rowCount > 0){ 
            return "true";
        }else{
            return "false";
        }
    }

    if($id != "" || $tone_code != "" || $extras != "" || $contact_name != "" || $contact_no1 != "" || $unveiling != ""){
        $check = checkId($id , $status);
        $msg = "";

        if($check == "true"){
            $msg = "<div class='center-col'>
                <h4>Contract number: <span>$id </span> Already Added</h4>
                <h6><a href='index.php?name=something Went Wrong'>Edit</a></h6>
            </div>";
        }else{

            mysqli_query($GLOBALS['con'],$sql);
            $msg  = "<div class='center-col'>
            <h4>Contract number : <span>$id</span> Added Succesfully</h4>
            <h6><span>$contact_name </span> $tone_code</h6>
        </div>";
        }
    }else{
        $msg = "There is something wrong </br>";
    }

    return $msg ;
}

function getTusks(){
    $sql = "SELECT * FROM `tombstones_installations`";
    
    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
    // if( mysqli_num_rows($results) > 0){
    //     return  $results;
    // }else{
    //     return 0;
    // }
}