<?php

include_once "../includes/functions.php";

session_start();
$res_msg = "";

$url =  $_SERVER['REQUEST_URI'];
$parts = explode('=', rtrim($url, '?'));
$contractID = end($parts);


$contract = searchById($contractID);

?>
<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contract Details</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../../assets/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/tusks.css">
    <style>
        #flexy-col {
            flex-direction: column !important;
            text-align: left;
            align-items: flex-start !important;
        }
        .back-btn {
            width: 109px;
            margin: 20px;
            border: none;
            background: #30b730;
            height: 35px;
            border-radius: 8px;
            color: white;
            font-weight: 700;
            transition: all 0.6s ease-in-out;
        }
        .cont-numb {
            color: rgb(255 120 0);
            text-transform: uppercase;
            font-weight: 700;
            text-decoration: underline;
           
        }
        h3 {
            margin: 27px  0px;
            color: #454242;
            font-weight: 700;
        }
         .back-btn:hover {
            background: orange;
            border-radius: 0px;
            color: black;
        }
         .back-btn:active {
            opacity: 0.6;
            cursor: progress;
        }
        #single-contract-detasils article {
            min-height: 48px;
            border: 1px solid;
            display: flex;
            justify-content: flex-start;
            align-items: center;
        }
        #single-contract-detasils article:nth-child(1) {
            background-color: rgb(27, 236, 204);
        }
        #single-contract-detasils article:nth-child(2) {
        background-color: rgb(0, 246, 70);
        }
    </style>
</head>
<body>
<button class="back-btn">BACK</button>
<section id="error"><?=$res_msg ?></section>
<section id="single-contract-detasils" class="container-fluid">
    <h3>RESULTS FOR : <span class="cont-numb"></span> <span class="update"><a href="../update/index.php?id=<?=$contractID?>">Edit Contract</a></span></h3>
    <div class="container">
        <?php 
            echo '
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                        <h5>Contract Number</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["id"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                        <h5>Contact\'s Name</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["contact_name"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                    <h5>Contacts</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["contact_no1"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                    <h5>Other Contacts</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["contact_no2"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                    <h5>Stone Type</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["stone_name"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                    <h5>Deseaed Name</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["deseased_name"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                    <h5>Approved Date</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["unveiling"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                    <h5>Extras</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["extras"].'</p>
                    </article>
                </div>
                <div class="row">
                    <article class="col-lg-4 col-md-4">
                    <h5>Grave Yard</h5>
                    </article>
                    <article class="col-lg-8 col-md-8">
                        <p>'.$contract[0]["gy"].'</p>
                    </article>
                </div>
                ';
        ?>
    </div>
</section>

<script>

let backCounter = -1;

//Tracking the document clicked number 
document.addEventListener("click", ()=> --backCounter)
//Reroutingto the the initial browser back history
document.querySelector(".back-btn").addEventListener("click", ()=> window.history.go(backCounter))



</script>
</body>
</html>