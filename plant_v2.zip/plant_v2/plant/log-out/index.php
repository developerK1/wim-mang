<?php

session_start();


if(isset($_SESSION['username'], $_SESSION['email'])){
	session_unset();
	header("Location: ../../loggin-in/");
}else{
	header("Location: ../../loggin-in/");
}