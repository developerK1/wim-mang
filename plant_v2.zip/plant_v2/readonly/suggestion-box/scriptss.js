document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('suggestionForm');
    const messageField = document.getElementById('message');
    const charCount = document.getElementById('charCount');
    
    // Character counter for message
    messageField.addEventListener('input', function() {
        const text = this.value;
        // Remove punctuation and extra spaces
        const cleanText = text.replace(/[^\w\s]/g, '').replace(/\s+/g, ' ');
        charCount.textContent = cleanText.length;
        
        // Update color based on limit
        if (cleanText.length > 300) {
            charCount.style.color = 'red';
        } else {
            charCount.style.color = 'inherit';
        }
    });
    
    // Client-side validation
    form.addEventListener('submit', function(e) {
        if (!form.checkValidity()) {
            e.preventDefault();
            alert('Please fill out all fields correctly.');
            return;
        }
        
        // Additional JS validation
        const subject = document.getElementById('subject').value;
        const message = document.getElementById('message').value;
        
        // Validate subject pattern
        if (!/^[a-zA-Z0-9 ]+$/.test(subject)) {
            e.preventDefault();
            alert('Subject can only contain letters, numbers, and spaces.');
            return;
        }
        
        // Validate message length (after cleaning)
        const cleanMessage = message.replace(/[^\w\s]/g, '').replace(/\s+/g, ' ');
        if (cleanMessage.length > 300) {
            e.preventDefault();
            alert('Message exceeds 300 character limit (after removing punctuation and extra spaces).');
            return;
        }
        
        // If using AJAX (uncomment to enable)
        /*
        e.preventDefault();
        submitForm();
        */
    });
    
    // AJAX form submission (optional)
    function submitForm() {
        const formData = new FormData(form);
        
        fetch('submit.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message
                const successDiv = document.createElement('div');
                successDiv.className = 'alert success';
                successDiv.textContent = data.message;
                form.parentNode.insertBefore(successDiv, form);
                form.reset();
                
                // Remove after 5 seconds
                setTimeout(() => {
                    successDiv.remove();
                }, 5000);
            } else {
                // Show errors
                const errorDiv = document.createElement('div');
                errorDiv.className = 'alert error';
                const ul = document.createElement('ul');
                
                data.errors.forEach(error => {
                    const li = document.createElement('li');
                    li.textContent = error;
                    ul.appendChild(li);
                });
                
                errorDiv.appendChild(ul);
                form.parentNode.insertBefore(errorDiv, form);
                
                // Remove after 5 seconds
                setTimeout(() => {
                    errorDiv.remove();
                }, 5000);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    }
});