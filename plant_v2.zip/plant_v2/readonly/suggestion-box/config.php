<?php
// Database Configuration - Replace with your actual values
define('DB_HOST', 'localhost');          // Database host (usually 'localhost')
define('DB_NAME', 'suggestions_db');     // Database name
define('DB_USER', 'root');               // Database username
define('DB_PASS', '');                   // Database password

// Email Configuration
define('EMAIL_TO', 'maobakg@yahoo.com'); // Recipient email address
define('EMAIL_FROM', 'no-reply@yourdomain.com'); // Sender email address
define('EMAIL_FROM_NAME', 'Wim Team');   // Sender name

// Security Settings
define('CSRF_TOKEN_EXPIRY', 3600);       // CSRF token lifetime in seconds (1 hour)
define('HONEYPOT_FIELD', 'website');     // Name of honeypot spam trap field
define('RATE_LIMIT', 5);                 // Max submissions per IP per minute (0 to disable)
define('ALLOWED_ORIGINS', [              // Allowed domains for CORS (for API)
    'https://yourdomain.com',
    'https://www.yourdomain.com'
]);

// Path Settings
define('LOG_FILE', __DIR__ . '/../logs/error.log'); // Error log file path
define('UPLOAD_DIR', __DIR__ . '/../uploads');      // File upload directory

// Application Settings
define('SITE_NAME', 'Suggestion Form');  // Site name for display purposes
define('MAX_SUBJECT_LENGTH', 100);       // Maximum subject length
define('MAX_MESSAGE_LENGTH', 2000);      // Maximum raw message length
define('CLEAN_MESSAGE_MAX', 300);        // Max chars after cleaning (no punctuation/extra spaces)

// Error Reporting - Disable in production!
ini_set('display_errors', '0');          // Don't show errors to users
ini_set('log_errors', '1');              // Log errors to file
ini_set('error_log', LOG_FILE);          // Set error log location
error_reporting(E_ALL);                  // Report all errors

// Security Headers (will be set in the application)
define('SECURITY_HEADERS', [
    'X-Frame-Options' => 'DENY',
    'X-Content-Type-Options' => 'nosniff',
    'X-XSS-Protection' => '1; mode=block',
    'Referrer-Policy' => 'strict-origin-when-cross-origin',
    'Content-Security-Policy' => "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:"
]);

// Timezone Settings
date_default_timezone_set('UTC');

// Ensure session is started securely
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 86400,             // 1 day
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => true,                // Only send over HTTPS
        'httponly' => true,              // Prevent JavaScript access
        'samesite' => 'Strict'          // CSRF protection
    ]);
    session_start();
}

// Prevent directory listing
if (!defined('APP_RUNNING')) {
    define('APP_RUNNING', true);
}