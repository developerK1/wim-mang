<?php
require_once __DIR__ . 'config.php';

class Mailer {
    public static function sendEmail($subject, $message, $ip) {
        $to = EMAIL_TO;
        $from = EMAIL_FROM;
        $fromName = EMAIL_FROM_NAME;
        
        // Clean inputs for email headers
        $subject = self::cleanHeader($subject);
        $from = self::cleanHeader($from);
        $fromName = self::cleanHeader($fromName);
        
        // Email body with additional info
        $emailBody = "You've received a new suggestion:\n\n" .
                     "Subject: $subject\n\n" .
                     "Message:\n$message\n\n" .
                     "IP Address: $ip\n" .
                     "Submitted at: " . date('Y-m-d H:i:s') . "\n";
        
        // Try PHPMailer first (recommended)
        if (self::sendWithPHPMailer($subject, $emailBody, $to, $from, $fromName)) {
            return true;
        }
        
        // Fallback to PHP mail()
        return self::sendWithMailFunction($subject, $emailBody, $to, $from, $fromName);
    }
    
    private static function sendWithPHPMailer($subject, $body, $to, $from, $fromName) {
        // Check if PHPMailer is available
        if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            error_log("PHPMailer not installed - falling back to mail()");
            return false;
        }
        
        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            
            // Uncomment and configure your SMTP settings
            /*
            $mail->isSMTP();
            $mail->Host = 'smtp.your-domain.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'your-username';
            $mail->Password = 'your-password';
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            */
            
            // If not using SMTP, use sendmail
            $mail->isSendmail();
            
            $mail->setFrom($from, $fromName);
            $mail->addAddress($to);
            $mail->addReplyTo($from, $fromName);
            
            $mail->isHTML(false);
            $mail->Subject = $subject;
            $mail->Body = $body;
            
            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("PHPMailer Error: " . $e->getMessage());
            return false;
        }
    }
    
    private static function sendWithMailFunction($subject, $body, $to, $from, $fromName) {
        $headers = [
            'From' => "$fromName <$from>",
            'Reply-To' => $from,
            'X-Mailer' => 'PHP/' . phpversion(),
            'Content-Type' => 'text/plain; charset=UTF-8',
            'MIME-Version' => '1.0'
        ];
        
        $headerString = '';
        foreach ($headers as $key => $value) {
            $headerString .= "$key: $value\r\n";
        }
        
        return mail($to, $subject, $body, $headerString);
    }
    
    private static function cleanHeader($header) {
        // Remove newlines to prevent header injection
        return preg_replace('/[\r\n]/', '', $header);
    }
}