<?php
require_once '../includes/functions.php';
//require_once __DIR__ . 'mailer.php';

$errors = [];
$success = false;

// Process form submission
if (isset($_POST['sub'])){
   

    // Honeypot validation
    if (!empty($_POST['website'])) {
        // Treat as spam - don't process but pretend it succeeded
        header('Location: ?success=1');
        exit;
    }

    // Get and sanitize inputs
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    // Validate subject
    if (empty($subject)) {
        $errors[] = "Subject is required.";
    } elseif (strlen($subject) < 3) {
        $errors[] = "Subject must be at least 3 characters.";
    } elseif (!preg_match('/^[a-zA-Z0-9 ]+$/', $subject)) {
        $errors[] = "Subject can only contain letters, numbers, and spaces.";
    }

    // Validate message
    $cleanMessage = preg_replace('/[^\w\s]/', '', $message);
    $cleanMessage = preg_replace('/\s+/', ' ', $cleanMessage);
    $charCount = strlen($cleanMessage);

    echo "</br>message clean and ready to log</br>";

    if (empty($message)) {
        $errors[] = "Message is required.";
        echo "</br>message errror founds</br>";
    } elseif ($charCount > 300) {
         echo "</br>message error elngth problem</br>";
        $errors[] = "Message exceeds 300 character limit (after removing punctuation and extra spaces).";
    }

     echo "</br>message error passed</br>";
    // If no errors, process the submission
    if (empty($errors)) {
         echo "</br>about to do try block</br>";
        try {
             $ip_address = "1235132";
            insertMessage($emailSubject,$cleanMessage, $ip_address);
             echo "</br>inser function ran</br>";
            // Send email
            $emailSubject = "New Suggestion: " . $subject;
            $emailBody = "Subject: $subject\n\nMessage:\n$message\n\nIP: {$_SERVER['REMOTE_ADDR']}\nTime: " . date('Y-m-d H:i:s');
            

            //Mailer::sendEmail($emailSubject, $emailBody, $_SERVER['REMOTE_ADDR']);

            $success = true;
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            $errors[] = "An error occurred. Please try again later.";
             echo "</br>Error found by catch block</br>";
        }
    }

     echo "</br>errors check complente end of function</br>";
}else{
    echo "not set";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suggestion Form</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Send Us Your Suggestion</h1>
        
        <?php if ($success): ?>
            <div class="alert success">
                Thank you for your suggestion! We'll review it shortly.
            </div>
        <?php elseif (!empty($errors)): ?>
            <div class="alert error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form id="suggestionForm" method="post"  action="">
        
            <!-- Honeypot field -->
            <div class="honeypot">
                <label for="website">Leave this blank</label>
                <input type="text" id="website" name="website" tabindex="-1">
            </div>

            <div class="form-group">
                <label for="subject">Subject*</label>
                <input type="text" id="subject" name="subject" 
                       minlength="3" maxlength="100" 
                       pattern="[a-zA-Z0-9 ]+" 
                       title="Only letters, numbers, and spaces allowed"
                       value="<?= isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : '' ?>"
                       required>
                <div class="hint">Minimum 3 characters, letters and numbers only</div>
            </div>

            <div class="form-group">
                <label for="message">Message*</label>
                <textarea id="message" name="message" maxlength="2000" required><?= 
                    isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '' 
                ?></textarea>
                <div class="hint">Maximum 300 characters (excluding punctuation and extra spaces)</div>
                <div class="char-counter"><span id="charCount">0</span>/300</div>
            </div>

            <button type="submit" name="sub">Submit Suggestion</button>
        </form>
    </div>

    <script src="scripts.js"></script>
</body>
</html>