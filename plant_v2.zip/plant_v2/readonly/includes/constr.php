<?php
//HOSTED MACHINE
$host = 'localhost'; // Change this to your MySQL server host
$username = 'bxxhwhbm_test'; // Change this to your MySQL username
$password = 'test@2024'; // Change this to your MySQL password
$database = 'bxxhwhbm_wimcorp'; // Change this to your MySQL database nam


// Establish a connection to MySQL server
$con = new mysqli($host, $username, $password, $database);

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}