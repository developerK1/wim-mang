<?php

include_once "constr.php";


$GLOBALS['con'] = $con;

$sql = "";


function getContracts(){
    $sql = "SELECT * FROM `contracts`";
    
    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
   
    if( mysqli_num_rows($results) > 0){
        return  $results;
    }
}

//UOPDATE INSTALLATIONS
function updateInstallation($month, $inst , $unva , $phone,$extra, $grave_yard,$other_num, $contractID){
    $responsMsg = "";

    $sqlTsuk = "UPDATE `contracts` SET `unveiling_date`='$unva',`installation_date`='$inst',`month`='$month',`stones_details`='$extra',`grave_yard`='$grave_yard',`contacts`='$phone',`other_number`='$other_num'  WHERE  `contract_id`='$contractID'";

    if($month && $inst && $unva && $phone && $extra && $grave_yard && $other_num && $contractID){
        $tuskResults = mysqli_query($GLOBALS['con'],$sqlTsuk);
        if($tuskResults == 1 ){
            $responsMsg = "
                <div class='success'>
                    <h4>Account Successfully Updated</h4>
                    <p>Contract Number : $contractID </p>
                </div>
            ";
        }else{
            $responsMsg = "
                <div class='error'>
                    <h4>Something Went Wrong</h4>
                    <p>Contract Number : $contractID </p>
                </div>
            ";
        }
    }else{
        $responsMsg = "
            <div class='error'>
                <h4>Please Fill in all Required Fields</h4>
                <p>Contract Number : $contractID </p>
            </div>
        ";
    }

 return $responsMsg;
}

function updateStatus($status, $contractID){
    $responsMsg = "";
    $sqlTusk = "";


    if($status == "Installed"){
        $sqlTusk = "UPDATE `contracts` SET `contract_status`='$status'  WHERE `contract_id`='$contractID'";
    }else{
        $sqlTusk = "UPDATE `contracts` SET `contract_status`='$status'  WHERE `contract_id`='$contractID'";
    }

    if($status && $contractID){
        $tuskResults = mysqli_query($GLOBALS['con'],$sqlTusk);

        if($tuskResults == 1 ){
            $responsMsg = "
                <div class='success'>
                    <h4>Account Successfully Updated</h4>
                    <p>Contract Number : $contractID </p>
                </div>
            ";
        }else{
            $responsMsg = "
                <div class='error'>
                    <h4>Something Went Wrong</h4>
                    <p>Contract Number : $contractID </p>
                </div>
            ";
        }
    }else{
        $responsMsg = "
            <div class='error'>
                <h4>Please Fill in all Required Fields</h4>
                <p>Contract Number : $contractID </p>
            </div>
        ";
    }

    return  $responsMsg;
};

//UPDATE BALANCE
function updateContract($amount, $date, $inst , $unva , $phone, $stone, $id){

    $accountInfo = json_decode(fetchBalance($id));
    $prevbalance = (int)$accountInfo[0]->balance;
    $newAmount = (int)$amount;
    $outstanding = $prevbalance - $newAmount;

    $installation = "";
    $unveiling = "";


    if($unva == "" ){
        $unveiling = "0000:00:00"  ;
     }else{
        $unveiling  = $unva ;
    }

    if($inst  == ""){
        $installation = "0000:00:00";
    }else{ 
        $installation = $inst ;
    }

    $sqlAccount = "UPDATE `invoices` SET `last_payment`='$amount',`date`='$date',`balance`='$outstanding ' WHERE `contract_id`='$id'";
    
    $sqlTsuk = "UPDATE `contracts` SET `outstanding_blance`='$newAmount' ,`contacts`='$phone' , `stones_details`='$stone' ,`unveiling_date`='$installation',`installation_date`='$installation' WHERE `contract_id`='$id'";


    if($amount && $date && $id){
        echo "Update coudn't proceed. no enough enough information provided to complete the update</br>";

        echo "$amount</br>";
        echo "$date</br>";
        echo "$id</br>";
    }else{
        $accountResults = mysqli_query($GLOBALS['con'],$sqlAccount);
        $tuskResults = mysqli_query($GLOBALS['con'],$sqlTsuk);

        if($accountResults == $tuskResults){
            echo "Account succesfully Updated</br>";
            echo "updating contract $id</br> AND query is  $sqlAccount </br>";
        }else{
            echo "Something Went Wrong";
        }
    }
}
//UPDATE BLANCE HELPER FUNCTION
function fetchBalance($id){
    $sql = "SELECT `deposit`, `last_payment`, `date`, `balance`, `total_cost` FROM `invoices` WHERE `contract_id` = '$id'";

    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
   
    if( mysqli_num_rows($results) != 0){
        $contract = mysqli_fetch_all($results, MYSQLI_ASSOC);
        return  json_encode($contract);
    }
}

function getAmount($id){
    $sql = "SELECT `deposit`, `last_payment`, `date`, `balance`, `total_cost` FROM `invoices` WHERE `contract_id` = '$id'";

    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
   
    if( mysqli_num_rows($results) != 0){
        $contract = mysqli_fetch_all($results, MYSQLI_ASSOC);
        $currentBalance = $contract[0]['balance'];

       return $currentBalance ;
    }else{
        return "Account Not Up To date";
    }
}

//DELETING contracts
function deleteContract($contractID){
    $sql = "DELETE FROM `contracts` WHERE contractID = $contractID";
    echo "deleting contract $contractID </br> AND query is $sql</br>";
}

//SEARCH  CONTRACTS
function getContractsById($contractID){
    $sql = "SELECT * FROM `contracts` where `contract_id`='$contractID'";
    
    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
   
    if( mysqli_num_rows($results) != 0){
        $contract = mysqli_fetch_all($results, MYSQLI_ASSOC);
        return  json_encode($contract);
    }else{
        return null;
    }
}

//FETCH INSTALATION DATES
function getInstalldate($month){
    // $sql = "SELECT * FROM `contracts` where `contract_id`='$month";
    echo "You passed in $month as parameter";
}

//GET INSTALLATION MONTHES
function  getCurrentMonth($searchMonth){
    $sql = "SELECT * FROM `contracts` WHERE month='$searchMonth'";

    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);

    if( $rowCount  != 0){
        $contacts = mysqli_fetch_all($results, MYSQLI_ASSOC);
        return $contacts;
    }else{
        return null;
    }
}

//FETCH BY NAME
function searchByName($term){
    $sql = "SELECT * FROM `contracts` WHERE buyer='$term'  OR contract_id='$term' ";
    $results = mysqli_query($GLOBALS['con'],$sql);
	$rowCount = mysqli_num_rows($results);
   
    if( $rowCount != 0){

        if( $rowCount == 1){
            //IF ONE USED FOR SEARCHING CONTRACT ID
            $contract = mysqli_fetch_all($results, MYSQLI_ASSOC);
            return  $contract;
        }else{
            //IF MANY , USES NAME SAERCHE RESULTS
            $contracts = mysqli_fetch_all($results, MYSQLI_ASSOC);
            // return  json_encode($contract); WHENE USING JAVASCRIPT
            return $contracts;
        }

    }else{
        return null;
    }
}