<?php
header('Content-Type: application/json');

// Process the form data
$data = json_decode(file_get_contents('php://input'), true);

// Add your database insertion logic here
// Example:
// $db->insert('table_name', $data);
echo "</br>";
print_r($data);
echo "</br>";
// Return response
$response = [
    'status' => 'success',
    'message' => 'Data submitted successfully'
];

echo json_encode($response);
?>