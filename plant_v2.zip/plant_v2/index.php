<?php 
  header("Location:readonly");
?>  