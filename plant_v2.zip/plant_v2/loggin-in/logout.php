<?php
session_start();

if(isset($_SESSION['privilage'])){
    unset($_SESSION['username']);
    unset($_SESSION['password']);
    unset($_SESSION['email']);
    unset($_SESSION['app_sesion']);
    unset($_SESSION['privilage']);
    
    header("Location:../");
}else{
    header("Location:../");
}