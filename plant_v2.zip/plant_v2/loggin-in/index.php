<?php
include_once "../global/constr.php";
session_start();

if(isset($_SESSION['privilage'])){
    if($_SESSION['privilage'] == 1){
        header("location:../plant/home/");
    } elseif($_SESSION['privilage'] == 2){
        header("location:../rbt/home/");
    } elseif($_SESSION['privilage'] == 3){
        header("location:../plant/scheduled-stones/");
    }
}

$respond_content = "";
$userError = "";
$passError = "";

if(isset($_POST['log-in'])){

    $userPass = "";
    $userID = "";
    $email = "";

    isEmpty($_POST['name']) ? $userError="Please provide username..." : $userID = htmlspecialchars($_POST['name']);
    isEmpty($_POST['password']) ? $passError="Password cannot be empty..." : $userPass = $_POST['password']; // Don't hash, we'll compare later
    isEmpty($_POST['email']) ? $emailError="Email cannot be empty..." : $email = htmlspecialchars($_POST['email']);

    if($userPass && $userID){
 
        // Fixed column name from 'personell_name' to 'personnel_name'
        $check = "SELECT * FROM employees WHERE personnel_name='$userID' AND email_address='$email' LIMIT 1";
        $results = mysqli_query($con, $check);

        if(mysqli_num_rows($results) > 0){
            $userData = mysqli_fetch_assoc($results);
            
            // Verify hashed password
            if(password_verify($userPass, $userData['pass'])){
                
                $_SESSION['username'] = $userData['personnel_name']; 
                $_SESSION['password'] = "accepted";
                $_SESSION['email'] = $userData['email_address'];
                $_SESSION['app_sesion'] = "wimcorpo".$userData['personnel_name'];
                
                // Map security_clearance to privilage
                $securityClearance = $userData['security_clearance'];
                
                if($securityClearance == 1){
                    $_SESSION['privilage'] = 1; // Full admin (office+plant)
                    header("location:../plant/");
                } elseif($securityClearance == 2){
                    $_SESSION['privilage'] = 2; // Plant only (RBT)
                    header("location:../rbt/");
                } elseif($securityClearance == 3){
                    $_SESSION['privilage'] = 3; // Scheduled stones access
                    header("location:../plant/scheduled-stones/");
                } else {
                    // Default or unknown clearance level
                    echo "
                    <section id='failed'>
                        <div class='access'>
                            <div class='col-btn'>
                                <h4 id='closeMod'>X</h4>
                                <p>Close Pop Up</p>
                            </div>
                            <div class='flexy'>
                                <h3>ACCESS DENIED !!!</h3>
                                <p>No role assigned to your account. Contact admin.</p>
                                <a href='../readonly/'><button>GO Back To Listing</button></a>
                            </div>
                        </div>
                    </section>
                    ";
                }
            } else {
                // Password doesn't match
                showAccessDenied();
                clearSession();
            }
        } else {
            showAccessDenied();
            clearSession();
        }
    }
}

function showAccessDenied() {
    echo "
        <section id='failed'>
            <div class='access'>
                <div class='col-btn'>
                    <h4 id='closeMod'>X</h4>
                    <p>Close Pop Up</p>
                </div>
                <div class='flexy'>
                    <h3>ACCESS DENIED !!!</h3>
                    <a href='../readonly/'><button>GO Back To Listing</button></a>
                </div>
            </div>
        </section>
    ";
}

function clearSession() {
    session_unset();
    unset($_SESSION['username']);
    unset($_SESSION['email']);
    unset($_SESSION['privilage']);
    unset($_SESSION['app_sesion']);
}

function isEmpty($value) {
    return empty($value);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login - WIM Corporation</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        section {
            padding-top: 20px;
        }
        h3 {
            text-align: center;
            font-size: 32px;
            font-weight: 700;
            color: #FF7F00;
            text-shadow: 1px 2px 1px black;
        }
        #log-inform {
            width: 100%;
            max-width: 400px;
            margin: 10px auto 50px auto;
            padding: 30px;
            background-color: #f9f9f9;
            border: 2px solid #FF7F00; 
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-size: 16px;
            font-weight: bold;
            color: #FF7F00; 
            margin-bottom: 5px;
            display: block;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 5px;
            transition: border-color 0.3s ease;
            background-color: #fff;
            color: #333;
        }
        .form-group input:hover {
            border-color: #FF7F00;
        }
        .form-group input:focus {
            outline: none;
            border-color: #FF5500; 
            box-shadow: 0 0 5px rgba(255, 127, 0, 0.5);
        }
        .error {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }
        .btn-primary {
            width: 100%;
            padding: 10px;
            background-color: #FF7F00; 
            color: #fff;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .access button, .access a {
            margin: auto;
            transition: background-color 0.3s ease;
            background-color: #FF7F00; 
            color: #fff;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-primary:hover, .access button:hover {
            background-color: #FF5500;
        }
        figure {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0px auto;
        }
        figure p {
            text-transform: uppercase;
            text-decoration: underline;
            text-decoration-color: #FF7F00;
            text-decoration-thickness: 3px;
            font-size: 26px;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
            color: #ff7f00;
        }
        figure p:hover {
            color: #f34c00;
            font-weight: 700;
            letter-spacing: 1.1px;
        }
        .log-in-response {
            text-align: center;
            font-size: 32px;
            margin: 10px;
        }
        #failed {
            width: 100%;
            height: 100vh;
            background: #ff7f00e8;
            position: fixed;
            top: 0px;
            left: 0px;
            display: flex;
            z-index: 1000;
        }
        .access {
            width: 350px;
            margin: auto;
            position: relative;
            border-radius: 12px;
            background-color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            padding: 20px;
            align-items: center;
            box-shadow: 7px 9px 9px 2px #00000094;
        }
        .access h4 {
            position: absolute;
            top: 15px;
            left: 20px;
            color: black;
            border: 3px solid red;
            background: red;
            width: 60px;
            height: 40px;
            border-radius: 12px 0px 0px 0px;
            text-align: center;
            line-height: 40px;
            cursor: pointer;
            transition: all 0.6s ease-in-out;
            margin: 0px;
        }
        .access h4:hover {
            background-color: wheat;
            letter-spacing: 1.3px;
            color: red;
            border-radius: 8px;
        }
        .access h3 {
            color: red;
            font-weight: 800;
            font-size: 36px;
            text-align: center;
            margin-bottom: 20px;
            text-decoration: underline;
            font-style: italic;
            text-shadow: 1px 2px 1px black;
        }
        .col-btn {
            display: flex;
            justify-content: space-around;
            width: 100%;
        }
        .col-btn p {
            opacity: 0;
            margin-left: 10px;
        }
        .flexy {
            display: flex;
            flex-direction: column;
            justify-content: space-evenly;
            text-align: center;
        }
        .force-show {
            opacity: 1 !important;
        }
    </style>
</head>
<body>
<section class="container-fluid">
    <h3>LOG IN</h3>
    <div class="container">
        <form id="log-inform" method="POST" action="#">
            <div class="form-group">
                <label for="username">Full Name</label>
                <input type="text" class="form-control" id="username" placeholder="Enter Name here..." name="name" required>
                <p class="error"><?php echo $userError != "" ? $userError : ""?></p>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" placeholder="Your email here" name="email" required>   
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" placeholder="Password" name="password" required>
                <p class="error"><?php echo $passError != "" ? $passError : ""?></p>
            </div>
            <button type="submit" class="btn btn-primary" name="log-in">Submit</button>
        </form>
        <figure>
            <p onclick="notSet(this)">password recovery</p>
        </figure>
    </div>
</section>
<script>
    const notSet = elm => alert(`"${elm.innerText}" not yet set`);
    
    // Check if modal exists before adding event listeners
    const closeModBtn = document.querySelector("#closeMod");
    const failedMod = document.querySelector("#failed");
    
    if(closeModBtn && failedMod) {
        const closeBtn = document.querySelector(".col-btn");
        const closeBtnP = document.querySelector(".col-btn p");
        
        if(closeBtn) {
            closeBtn.addEventListener("mouseover", function(){
                if(closeBtnP) closeBtnP.classList.add("force-show");
            });
            closeBtn.addEventListener("mouseleave", function(){
                if(closeBtnP) closeBtnP.classList.remove("force-show");
            });
        }
        
        closeModBtn.addEventListener('click', ()=> failedMod.style.display = "none");
    }
</script>
</body>
</html>