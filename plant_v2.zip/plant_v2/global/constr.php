<?php
//HOSTED MACHINE
$host = 'localhost'; // Change this to your MySQL server host
$username = 'bxxhwhbm_beta'; // Change this to your MySQL username
$password = '3k63BArsnW82m3BQgHca'; // Change this to your MySQL password
$database = 'bxxhwhbm_beta'; // Change this to your MySQL database nam


//LOCAL MACHINE
// $host = 'localhost'; // Change this to your MySQL server host
// $username = 'root'; // Change this to your MySQL username
// $password = ''; // Change this to your MySQL password
// $database = 'wimtable'; // Change this to your MySQL database nam


// Establish a connection to MySQL server
$con = new mysqli($host, $username, $password, $database);

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}