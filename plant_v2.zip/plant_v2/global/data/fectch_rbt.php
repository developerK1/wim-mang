<?php
include_once ("../constr.php");

$sql =  "SELECT * FROM `tombstones_installations` where shop='RBT'";

$results = mysqli_query($con, $sql);
$contacts = mysqli_fetch_all($results, MYSQLI_ASSOC);

echo json_encode($contacts);
