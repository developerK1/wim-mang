-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2026 at 12:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wimtable`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_address` varchar(255) NOT NULL,
  `personnel_name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `expertise` varchar(50) NOT NULL,
  `security_clearance` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = full admin (office+plant), 2 = plant only (no scheduling)',
  `pass` varchar(255) NOT NULL,
  `recovery` varchar(255) NOT NULL,
  `session_status` tinyint(1) NOT NULL DEFAULT 0,
  `session_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_address` (`email_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`email_address`, `personnel_name`, `occupation`, `surname`, `security_clearance`, `pass`, `recovery`, `expertise`, `session_status`, `session_id`) VALUES
('admin@wimcorporation.co.za', 'William', 'COO', 'Mmutloane', 1, '123456789', 'null', 'Management', 0, 'null'),
('kgalaleloseleka88888@gmail.com', 'kgalalelo', 'General Worker', 'Seleka', 1, '123456789', 'null', 'Graphic Desinger', 0, 'null'),
('maobakg@yahoo.com', 'Kekaone', 'General Worker', 'Maoba', 1, '25f9e794323b453885f5181f1b624d0b', 'null', 'Graphics designer', 0, 'null'),
('mmutloane60@gmail.com', 'Busisiwe', 'Manager', 'Mmutloane', 1, '123456789', 'null', 'Coo', 0, 'null');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`email_address`(30));
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
