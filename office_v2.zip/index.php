<?php  echo md5('123456789'); 

echo "</br>";

echo "<a href='admin'>Admin</a>";

?>