<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

$id       = get_param('id');
$contract = $id !== '' ? get_contract_by_id($id) : null;

$page_title  = 'Contract Details';
$assets_path = '../';
$nav_back    = '../search/';
include '../includes/header.php';
?>

<?php if (!$contract): ?>
<div class="wim-card" style="text-align:center;padding:40px">
    <h3 style="color:#dc3545">Contract not found</h3>
    <p>No contract found for ID: <strong><?= htmlspecialchars($id) ?></strong></p>
    <a href="../search/" class="btn-primary" style="padding:8px 20px;border-radius:5px">Back to Search</a>
</div>
<?php else: ?>

<div class="wim-card" style="max-width:700px">
    <h2>Contract #<?= htmlspecialchars($contract['contract_id']) ?></h2>

    <table class="detail-table">
        <tr><th>Contract Number</th><td><?= htmlspecialchars($contract['contract_id']) ?></td></tr>
        <tr><th>Status</th>
            <td>
                <span style="font-weight:700;color:<?= strtolower($contract['contract_status']) === 'installed' ? '#28a745' : '#FF7F00' ?>">
                    <?= htmlspecialchars($contract['contract_status']) ?>
                </span>
            </td>
        </tr>
        <tr><th>Contract Type</th><td><?= htmlspecialchars($contract['contract_type']) ?></td></tr>
        <tr><th>Contract Signed</th><td><?= htmlspecialchars($contract['contract_sign_date']) ?></td></tr>

        <tr><th colspan="2" style="background:#f8f8f8;color:#333;padding-top:14px">Client</th></tr>
        <tr><th>Surname</th><td><?= htmlspecialchars($contract['surname']) ?></td></tr>
        <tr><th>Name</th><td><?= htmlspecialchars($contract['buyer']) ?></td></tr>
        <tr><th>Other Name</th><td><?= htmlspecialchars($contract['other_name']) ?></td></tr>
        <tr><th>Contact</th><td><?= htmlspecialchars($contract['contacts']) ?></td></tr>
        <tr><th>Proxy / Other Contact</th><td><?= htmlspecialchars($contract['other_number']) ?></td></tr>
        <tr><th>Proxy Name</th><td><?= htmlspecialchars($contract['proxy']) ?></td></tr>

        <tr><th colspan="2" style="background:#f8f8f8;color:#333;padding-top:14px">Deceased</th></tr>
        <tr><th>Surname</th><td><?= htmlspecialchars($contract['dSurname']) ?></td></tr>
        <tr><th>Name</th><td><?= htmlspecialchars($contract['dec_name']) ?></td></tr>
        <tr><th>Other Name</th><td><?= htmlspecialchars($contract['dotherName']) ?></td></tr>

        <tr><th colspan="2" style="background:#f8f8f8;color:#333;padding-top:14px">Stone</th></tr>
        <tr><th>Stone / Code</th><td><?= htmlspecialchars($contract['stone_name']) ?></td></tr>
        <tr><th>Head Type</th><td><?= htmlspecialchars($contract['head_type']) ?></td></tr>
        <tr><th>Slab Type</th><td><?= htmlspecialchars($contract['slab_type']) ?></td></tr>
        <tr><th>Cost</th><td>R <?= htmlspecialchars($contract['stones_cost']) ?></td></tr>
        <tr><th>Additional Notes</th><td><?= htmlspecialchars($contract['stones_details']) ?></td></tr>

        <tr><th colspan="2" style="background:#f8f8f8;color:#333;padding-top:14px">Scheduling</th></tr>
        <tr><th>Installation Date</th><td><?= display_date($contract['installation_date']) ?></td></tr>
        <tr><th>Unveiling Date</th><td><?= display_date($contract['unveiling_date']) ?></td></tr>
        <tr><th>Month</th><td><?= htmlspecialchars($contract['month']) ?></td></tr>

        <tr><th colspan="2" style="background:#f8f8f8;color:#333;padding-top:14px">Location</th></tr>
        <tr><th>Town</th><td><?= htmlspecialchars($contract['town']) ?></td></tr>
        <tr><th>Grave Yard / Area</th><td><?= htmlspecialchars($contract['grave_yard']) ?></td></tr>

        <tr><th colspan="2" style="background:#f8f8f8;color:#333;padding-top:14px">Admin</th></tr>
        <tr><th>Sales Rep</th><td><?= htmlspecialchars($contract['sales_rep']) ?></td></tr>
        <tr><th>Funeral Display</th><td><?= $contract['funeral'] ? 'Yes' : 'No' ?></td></tr>
        <tr><th>Approved</th><td><?= $contract['approved_status'] ? 'Yes — ' . htmlspecialchars($contract['approved_date']) : 'No' ?></td></tr>
    </table>

    <div class="contract-actions" style="margin-top:20px">
        <a href="../update-status/?id=<?= urlencode($contract['contract_id']) ?>" class="btn-status">Update Status</a>
        <a href="../update-installation/?id=<?= urlencode($contract['contract_id']) ?>" class="btn-edit">Update Installation</a>
        <?php if (is_admin()): ?>
        <a href="../personells/" class="btn-secondary">Personnel</a>
        <?php endif; ?>
    </div>
</div>

<?php endif; ?>

<?php include '../includes/footer.php'; ?>
