<?php
/**
 * Shared utility helpers.
 */

/**
 * Sanitize a single POST/GET string value.
 * Returns $default if the key is missing or empty.
 */
function post(string $key, string $default = ''): string {
    return trim(htmlspecialchars($_POST[$key] ?? $default, ENT_QUOTES, 'UTF-8'));
}

function get_param(string $key, string $default = ''): string {
    return trim(htmlspecialchars($_GET[$key] ?? $default, ENT_QUOTES, 'UTF-8'));
}

/**
 * Return "TF" for a 0000-00-00 / empty date, otherwise return the date as-is.
 */
function display_date(string $date): string {
    return (empty($date) || $date === '0000-00-00') ? 'TF' : $date;
}

/**
 * Return $fallback if the value is empty.
 */
function or_else(string $value, string $fallback = 'N/A'): string {
    return trim($value) !== '' ? trim($value) : $fallback;
}

/**
 * Store a one-time flash message in the session.
 */
function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/**
 * Render and clear the flash message. Returns HTML string or empty string.
 */
function render_flash(): string {
    if (empty($_SESSION['flash'])) return '';
    $f    = $_SESSION['flash'];
    $type = $f['type'] === 'success' ? 'success' : 'error';
    $msg  = htmlspecialchars($f['message']);
    unset($_SESSION['flash']);
    return "<div class='flash flash-{$type}'>{$msg}</div>";
}

/**
 * Build the month name from an installation date string.
 */
function month_from_date(string $date): string {
    if (empty($date) || $date === '0000-00-00' || $date === 'TF') return 'January';
    return date('F', strtotime($date));
}

/**
 * Return "TF" fallback for any field that would otherwise be blank.
 */
function tf_or(string $value): string {
    return trim($value) !== '' ? trim($value) : 'TF';
}

/**
 * Render an HTML success message block.
 */
function success_html(string $message): string {
    return "<div class='msg msg-success'><p>" . htmlspecialchars($message) . "</p></div>";
}

/**
 * Render an HTML error message block.
 */
function error_html(string $message): string {
    return "<div class='msg msg-error'><p>" . htmlspecialchars($message) . "</p></div>";
}
