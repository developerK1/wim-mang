<?php
/**
 * Contract repository functions.
 * All queries use PDO prepared statements — zero SQL injection risk.
 */

require_once __DIR__ . '/db.php';

// ─── Read ─────────────────────────────────────────────────────────────────────

function get_all_contracts(): array {
    return get_db()->query('SELECT * FROM contracts ORDER BY contract_sign_date DESC')
                   ->fetchAll();
}

function get_recent_contracts(int $limit = 30): array {
    $stmt = get_db()->prepare(
        'SELECT * FROM contracts ORDER BY contract_sign_date DESC LIMIT ?'
    );
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

function get_contract_by_id(string $id): ?array {
    $stmt = get_db()->prepare('SELECT * FROM contracts WHERE contract_id = ? LIMIT 1');
    $stmt->execute([trim($id)]);
    return $stmt->fetch() ?: null;
}

function search_contracts(string $term): array {
    $like = '%' . $term . '%';
    $stmt = get_db()->prepare(
        'SELECT * FROM contracts
         WHERE buyer    LIKE ? OR contract_id LIKE ?
            OR surname  LIKE ? OR other_name  LIKE ?
            OR dec_name LIKE ? OR dSurname    LIKE ?
         ORDER BY contract_sign_date DESC'
    );
    $stmt->execute([$like, $like, $like, $like, $like, $like]);
    return $stmt->fetchAll();
}

function get_contracts_by_month(string $month): array {
    $stmt = get_db()->prepare(
        'SELECT * FROM contracts
         WHERE month = ?
           AND installation_date != "0000-00-00"
           AND contract_status != "Installed"
         ORDER BY installation_date ASC'
    );
    $stmt->execute([$month]);
    return $stmt->fetchAll();
}

function contract_exists(string $id): bool {
    $stmt = get_db()->prepare(
        'SELECT COUNT(*) FROM contracts WHERE contract_id = ?'
    );
    $stmt->execute([trim($id)]);
    return (int)$stmt->fetchColumn() > 0;
}

// ─── Create ───────────────────────────────────────────────────────────────────

function create_contract(array $data): bool {
    $sql = 'INSERT INTO contracts (
                contract_id, buyer, surname, other_name,
                slab_type, head_type, unveiling_date, installation_date,
                month, contryear, contract_type, contract_sign_date,
                stones_cost, grave_yard, town, contacts, other_number,
                dec_name, dSurname, dotherName, contract_status,
                stone_name, sales_rep, outstanding_balance,
                stones_details, funeral, proxy,
                approved_date, approved_status
            ) VALUES (
                :contract_id, :buyer, :surname, :other_name,
                :slab_type, :head_type, :unveiling_date, :installation_date,
                :month, :contryear, :contract_type, :contract_sign_date,
                :stones_cost, :grave_yard, :town, :contacts, :other_number,
                :dec_name, :dSurname, :dotherName, :contract_status,
                :stone_name, :sales_rep, :outstanding_balance,
                :stones_details, :funeral, :proxy,
                :approved_date, :approved_status
            )';
    $stmt = get_db()->prepare($sql);
    return $stmt->execute($data);
}

// ─── Update ───────────────────────────────────────────────────────────────────

function update_contract_status(string $contract_id, string $status): bool {
    $stmt = get_db()->prepare(
        'UPDATE contracts SET contract_status = ? WHERE contract_id = ?'
    );
    return $stmt->execute([$status, $contract_id]);
}

function update_installation(
    string $contract_id,
    string $month,
    string $installation_date,
    string $unveiling_date,
    string $contacts,
    string $other_number,
    string $grave_yard,
    string $stones_details
): bool {
    $stmt = get_db()->prepare(
        'UPDATE contracts SET
            month             = ?,
            installation_date = ?,
            unveiling_date    = ?,
            contacts          = ?,
            other_number      = ?,
            grave_yard        = ?,
            stones_details    = ?
         WHERE contract_id = ?'
    );
    return $stmt->execute([
        $month, $installation_date, $unveiling_date,
        $contacts, $other_number, $grave_yard, $stones_details,
        $contract_id,
    ]);
}

// ─── Delete ───────────────────────────────────────────────────────────────────

function delete_contract(string $contract_id): bool {
    $stmt = get_db()->prepare(
        'DELETE FROM contracts WHERE contract_id = ?'
    );
    return $stmt->execute([$contract_id]);
}

// ─── Conflict contracts ───────────────────────────────────────────────────────

/**
 * Save a contract that has a duplicate ID to the conflict_contracts table
 * for manual review instead of silently discarding it.
 */
function save_conflict_contract(array $data, string $flagged_by): bool {
    $sql = 'INSERT INTO conflict_contracts (
                original_contract_id, buyer, surname, other_name,
                slab_type, head_type, unveiling_date, installation_date,
                contract_type, contract_sign_date,
                stones_cost, grave_yard, town, contacts, other_number,
                dec_name, dSurname, dotherName,
                stone_name, sales_rep, stones_details,
                funeral, proxy, flagged_by, flagged_at, resolved
            ) VALUES (
                :original_contract_id, :buyer, :surname, :other_name,
                :slab_type, :head_type, :unveiling_date, :installation_date,
                :contract_type, :contract_sign_date,
                :stones_cost, :grave_yard, :town, :contacts, :other_number,
                :dec_name, :dSurname, :dotherName,
                :stone_name, :sales_rep, :stones_details,
                :funeral, :proxy, :flagged_by, NOW(), 0
            )';
    $stmt = get_db()->prepare($sql);
    return $stmt->execute(array_merge($data, ['flagged_by' => $flagged_by]));
}

function get_all_conflict_contracts(): array {
    return get_db()
        ->query('SELECT * FROM conflict_contracts ORDER BY flagged_at DESC')
        ->fetchAll();
}

function get_conflict_by_id(int $id): ?array {
    $stmt = get_db()->prepare(
        'SELECT * FROM conflict_contracts WHERE id = ? LIMIT 1'
    );
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

function resolve_conflict(int $conflict_id, string $resolution_note): bool {
    $stmt = get_db()->prepare(
        'UPDATE conflict_contracts
         SET resolved = 1, resolution_note = ?, resolved_at = NOW()
         WHERE id = ?'
    );
    return $stmt->execute([$resolution_note, $conflict_id]);
}

function delete_conflict(int $conflict_id): bool {
    $stmt = get_db()->prepare(
        'DELETE FROM conflict_contracts WHERE id = ?'
    );
    return $stmt->execute([$conflict_id]);
}

// ─── Invoices / balance ───────────────────────────────────────────────────────

function get_invoice(string $contract_id): ?array {
    $stmt = get_db()->prepare(
        'SELECT deposit, last_payment, date, balance, total_cost
         FROM invoices WHERE contract_id = ? LIMIT 1'
    );
    $stmt->execute([$contract_id]);
    return $stmt->fetch() ?: null;
}

function update_invoice(
    string $contract_id,
    int    $payment_amount,
    string $payment_date
): bool {
    $invoice = get_invoice($contract_id);
    if (!$invoice) return false;

    $new_balance = (int)$invoice['balance'] - $payment_amount;

    $stmt = get_db()->prepare(
        'UPDATE invoices
         SET last_payment = ?, date = ?, balance = ?
         WHERE contract_id = ?'
    );
    return $stmt->execute([$payment_amount, $payment_date, $new_balance, $contract_id]);
}

// ─── Approved contracts ───────────────────────────────────────────────────────

function get_approved_contracts(): array {
    $stmt = get_db()->query(
        'SELECT * FROM contracts WHERE approved_status = 1 ORDER BY approved_date DESC'
    );
    return $stmt->fetchAll();
}

function approve_contract(string $contract_id): bool {
    $stmt = get_db()->prepare(
        'UPDATE contracts SET approved_status = 1, approved_date = CURDATE()
         WHERE contract_id = ?'
    );
    return $stmt->execute([$contract_id]);
}

// ─── Plant installation confirmations ────────────────────────────────────────

/**
 * Fetch all rows from tombstones_installations where the plant team
 * has flagged confirm_installation = 1, meaning they are done.
 * We exclude rows already processed by the office (office_confirmed = 1).
 */
function get_pending_plant_confirmations(): array {
    $sql = 'SELECT * FROM tombstones_installations
            WHERE confirm_installation = 1
              AND (office_confirmed IS NULL OR office_confirmed = 0)
            ORDER BY logged_at DESC';
    return get_db()->query($sql)->fetchAll();
}

/**
 * Confirm an installation from the office side.
 * Does two things atomically:
 *   1. Updates contracts.contract_status = "Installed"
 *   2. Updates contracts.stones_details with plant extras
 * Then resets tombstones_installations.confirm_installation = 0
 * and sets office_confirmed = 1 so it leaves the review queue.
 */
function confirm_plant_installation(
    string $contract_id,
    string $plant_extras,
    string $confirmed_by
): bool {
    $db = get_db();
    try {
        $db->beginTransaction();

        // 1. Update the contracts table
        $stmt = $db->prepare(
            'UPDATE contracts
             SET contract_status = "Installed",
                 stones_details  = ?
             WHERE contract_id   = ?'
        );
        $stmt->execute([trim($plant_extras), trim($contract_id)]);

        // 2. Reset plant flag and mark office-confirmed
        $stmt2 = $db->prepare(
            'UPDATE tombstones_installations
             SET confirm_installation = 0,
                 office_confirmed     = 1,
                 office_confirmed_by  = ?,
                 office_confirmed_at  = NOW()
             WHERE id = ?'
        );
        $stmt2->execute([$confirmed_by, $contract_id]);

        $db->commit();
        return true;

    } catch (PDOException $e) {
        $db->rollBack();
        error_log('confirm_plant_installation failed: ' . $e->getMessage());
        return false;
    }
}

/**
 * Reject a plant confirmation — resets confirm_installation back to 0
 * and records a rejection note so the plant team can see it was sent back.
 */
function reject_plant_confirmation(
    string $contract_id,
    string $rejection_note,
    string $rejected_by
): bool {
    $stmt = get_db()->prepare(
        'UPDATE tombstones_installations
         SET confirm_installation = 0,
             rejection_note       = ?,
             rejected_by          = ?,
             rejected_at          = NOW()
         WHERE id = ?'
    );
    return $stmt->execute([$rejection_note, $rejected_by, $contract_id]);
}

/**
 * Fetch a single tombstones_installations row by contract ID.
 */
function get_plant_record(string $contract_id): ?array {
    $stmt = get_db()->prepare(
        'SELECT * FROM tombstones_installations WHERE id = ? LIMIT 1'
    );
    $stmt->execute([trim($contract_id)]);
    return $stmt->fetch() ?: null;
}
