
</main><!-- /.wim-main -->

<footer class="wim-footer">
    <p>&copy; <?= date('Y') ?> Wim Corporation &mdash; Admin Panel</p>
</footer>

</body>
</html>
