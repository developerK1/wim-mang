<?php
/**
 * Database connection — PDO, single instance via static variable.
 * Credentials are read from environment variables with fallback constants
 * so you can set them in .htaccess or a .env loader without touching this file.
 *
 * Shared between the OFFICE and PLANT apps — both point here.
 */
ini_set('display_errors', 1);
error_reporting(E_ALL);

function get_db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    // $host = getenv('DB_HOST') ?: 'localhost';
    // $name = getenv('DB_NAME') ?: 'bxxhwhbm_wimcorp';
    // $user = getenv('DB_USER') ?: 'bxxhwhbm_test';
    // $pass = getenv('DB_PASS') ?: 'test@2024';

 	$host = getenv('DB_HOST') ?: 'localhost';
    $name = getenv('DB_NAME') ?: 'bxxhwhbm_beta';
    $user = getenv('DB_USER') ?: 'bxxhwhbm_beta';
    $pass = getenv('DB_PASS') ?: '3k63BArsnW82m3BQgHca';

// Hostname:localhost
// Database:bxxhwhbm_beta
// Username:bxxhwhbm_beta
// Password:3k63BArsnW82m3BQgHca


    //LOCAL MACHINE
    // $host = getenv('DB_HOST') ?: 'localhost'; // Change this to your MySQL server host
    // $name = getenv('DB_NAME') ?: 'wimtable'; // Change this to your MySQL username
    // $pass = getenv('DB_PASS') ?: ''; // Change this to your MySQL password
    // $user = getenv('BB_USER') ?: 'root'; // Change this to your MySQL 

    try {
        $pdo = new PDO(
            "mysql:host=$host;dbname=$name;charset=utf8mb4",
            $user,
            $pass,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    } catch (PDOException $e) {
        // Never expose DB errors to the browser in production
        error_log('DB connection failed: ' . $e->getMessage());
        die('<p style="text-align:center;padding:40px;font-family:Arial;">
              Unable to connect to the database. Please contact your administrator.
             </p>');
    }
    return $pdo;
}
