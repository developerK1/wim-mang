<?php
/**
 * header.php — shared page header partial.
 *
 * Expects:
 *   $page_title  (string) — browser <title> suffix
 *   $assets_path (string) — relative path back to /admin/ from the calling page
 *   $nav_back    (string, optional) — URL for a Back button
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wim Admin — <?= htmlspecialchars($page_title ?? 'Panel') ?></title>
    <link rel="icon" href="<?= $assets_path ?>favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
          crossorigin="anonymous">
    <link rel="stylesheet" href="<?= $assets_path ?>assets/wim.css">
</head>
<body>

<header class="wim-header">
    <div class="wim-header__brand">
        <img src="<?= $assets_path ?>logo.png" alt="Wim Tombstones logo" height="48">
    </div>
    <nav class="wim-header__nav">
        <a href="<?= $assets_path ?>home">Home</a>
        <a href="<?= $assets_path ?>search/">Search</a>
        <a href="https://wimcorporation.co.za/plant/plant/home/">Approved</a>
        <?php if (is_admin()): ?>
        <a href="<?= $assets_path ?>conflicts/">Conflicts</a>
        <a href="<?= $assets_path ?>confirm-installations/">Confirm Installs</a>
        <a href="<?= $assets_path ?>personells/">Personnel</a>
        <?php endif; ?>
    </nav>
    <div class="wim-header__user">
        <span>Logged in: <strong><?= current_user() ?></strong></span>
       <a href="<?= $assets_path ?>logging-in/logout.php">
		    <button class="btn-logout">Log out</button>
		</a>
    </div>
</header>

<?php if (isset($nav_back)): ?>
<div class="wim-back-bar">
    <a href="<?= htmlspecialchars($nav_back) ?>" class="btn-back">← Back</a>
</div>
<?php endif; ?>

<main class="wim-main container-fluid">
<?php require_once __DIR__ . '/helpers.php'; echo render_flash(); ?>
