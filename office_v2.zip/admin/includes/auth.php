<?php
/**
 * Authentication & session helpers — shared by Office AND Plant.
 *
 * Security clearance levels:
 *   1 = Full admin  — Office + Plant (all pages including scheduling)
 *   2 = Plant CRUD  — Plant only: add / update / delete. NO scheduling page, NO "upcoming".
 *                     Can access "scheduled-stones" (read-only view).
 *   3 = Read-only   — Plant login only; can ONLY see "scheduled-stones". No CRUD of any kind.
 *   0 = No access   — Cannot log in anywhere. Login redirects to 404.
 *
 * Session variables set on login:
 *   $_SESSION['user_id']            — employee primary key (int)
 *   $_SESSION['username']           — personnel_name + surname
 *   $_SESSION['email']              — email_address
 *   $_SESSION['security_clearance'] — 1 | 2 | 3  (0 is rejected at login)
 *   $_SESSION['app_session']        — 'active'
 */

require_once __DIR__ . '/db.php';

// ─── Login ────────────────────────────────────────────────────────────────────

/**
 * Attempt login by email + password.
 * Returns employee row on success, null on failure.
 * NOTE: clearance 0 is treated as a failed login (no access).
 */
function attempt_login(string $email, string $password, string $username = ''): ?array {
    $stmt = get_db()->prepare(
        'SELECT * FROM employees WHERE email_address = ? LIMIT 1'
    );
    $stmt->execute([trim($email)]);
    $user = $stmt->fetch();

    if (!$user) return null;

    // Clearance 0 = explicitly no access — reject before even checking password
    if ((int)$user['security_clearance'] === 0) return null;

    // Support both bcrypt and legacy md5 during migration
    if (strpos($user['pass'], '$2y$') === 0) {
        if (!password_verify($password, $user['pass'])) return null;
    } else {
        if (md5($password) !== $user['pass']) return null;
        upgrade_password_hash((int)$user['id'], $password);
    }

    return $user;
}

/**
 * Upgrade a legacy md5 hash to bcrypt in the database.
 */
function upgrade_password_hash(int $user_id, string $plain_password): void {
    $hash = password_hash($plain_password, PASSWORD_BCRYPT);
    $stmt = get_db()->prepare('UPDATE employees SET pass = ? WHERE id = ?');
    $stmt->execute([$hash, $user_id]);
}

/**
 * Write session variables after a successful login.
 */
function create_session(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id']            = (int)$user['id'];
    $_SESSION['username']           = trim($user['personnel_name'] . ' ' . $user['surname']);
    $_SESSION['email']              = $user['email_address'] ?? '';
    $_SESSION['security_clearance'] = (int)$user['security_clearance'];
    $_SESSION['app_session']        = 'active';
}

/**
 * Destroy the session on logout.
 */
function destroy_session(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

// ─── Guards ───────────────────────────────────────────────────────────────────

/**
 * Redirect to login if no active session.
 */
function require_auth(string $login_path = '/office/admin/logging-in/'): void {
    if (empty($_SESSION['app_session']) || $_SESSION['app_session'] !== 'active') {
        header('Location: ' . $login_path);
        exit;
    }
}

/**
 * Require EXACT clearance level (or better).
 * $allowed_levels = array of ints that may pass.
 * All others get redirected.
 *
 * Examples:
 *   require_clearance([1])        → only full admin
 *   require_clearance([1,2])      → admin or plant-crud
 *   require_clearance([1,2,3])    → any logged-in plant user
 */
function require_clearance(array $allowed_levels, string $redirect = '../', string $login_path = '/office/admin/logging-in/'): void {
    require_auth($login_path);
    $clearance = (int)($_SESSION['security_clearance'] ?? 0);
    if (!in_array($clearance, $allowed_levels, true)) {
        header('Location: ' . $redirect);
        exit;
    }
}

/**
 * Returns true if the logged-in user has full admin (clearance 1).
 */
function is_admin(): bool {
    return (int)($_SESSION['security_clearance'] ?? 0) === 1;
}

/**
 * Returns true if the user can do CRUD in plant (clearance 1 or 2).
 */
function can_crud(): bool {
    return in_array((int)($_SESSION['security_clearance'] ?? 0), [1, 2], true);
}

/**
 * Returns true if the user can schedule (clearance 1 only).
 */
function can_schedule(): bool {
    return (int)($_SESSION['security_clearance'] ?? 0) === 1;
}

/**
 * Returns the logged-in user's display name, safely escaped.
 */
function current_user(): string {
    return htmlspecialchars($_SESSION['username'] ?? 'Unknown');
}

/**
 * Get the correct post-login redirect URL based on clearance.
 * Used by BOTH the office login and any shared login page.
 *
 * $base = path prefix to the office admin folder root (with trailing slash).
 */
function get_login_redirect(int $clearance, string $office_base = '/office/admin/'): string {
    switch ($clearance) {
        case 1: return $office_base . 'home/';           // Full admin → office home
        case 2: return '/plant/plant/home/';             // Plant CRUD → plant home
        case 3: return '/plant/plant/scheduled-stones/'; // Read-only → scheduled stones
        default: return '/404';                          // No access → 404
    }
}
