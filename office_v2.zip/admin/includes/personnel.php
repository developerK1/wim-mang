<?php
/**
 * Personnel repository functions (employees & agents).
 * Uses updated employees table columns:
 *   id, email_address, personnel_name, surname, security_clearance,
 *   pass, recovery, occupation, expertise, session_status, session_id
 */

require_once __DIR__ . '/db.php';

// ─── Read ─────────────────────────────────────────────────────────────────────

function get_all_employees(): array {
    return get_db()->query('SELECT * FROM employees ORDER BY surname ASC')->fetchAll();
}

function get_employee_by_name(string $name, string $surname): ?array {
    $stmt = get_db()->prepare(
        'SELECT * FROM employees WHERE personnel_name = ? AND surname = ? LIMIT 1'
    );
    $stmt->execute([trim($name), trim($surname)]);
    return $stmt->fetch() ?: null;
}

function employee_exists(string $name, string $surname): bool {
    $stmt = get_db()->prepare(
        'SELECT COUNT(*) FROM employees WHERE personnel_name = ? AND surname = ?'
    );
    $stmt->execute([trim($name), trim($surname)]);
    return (int)$stmt->fetchColumn() > 0;
}

// ─── Create ───────────────────────────────────────────────────────────────────

/**
 * Add a new employee or agent.
 * $table is either 'employees' or 'wim_agents'.
 */
function add_personnel(
    string $table,
    string $name,
    string $surname,
    string $email,
    string $occupation,
    string $expertise,
    int    $clearance = 1
): array {
    $name    = trim($name);
    $surname = trim($surname);
    $email   = trim($email);
    $table   = in_array($table, ['employees', 'wim_agents'], true) ? $table : 'employees';

    if (employee_exists($name, $surname)) {
        return [
            'success' => false,
            'message' => "$name $surname already exists. <a href='../personells/update/?name=$name&surname=$surname'>Edit</a>",
        ];
    }

    // New users get temporary password 'changeme' hashed with bcrypt
    $pass = password_hash('changeme', PASSWORD_BCRYPT);

    $stmt = get_db()->prepare(
    "INSERT INTO $table
        (email_address, personnel_name, occupation, surname,
         security_clearance, pass, recovery, expertise)
     VALUES (?, ?, ?, ?, ?, ?, 'null', ?)"
	);
	$ok = $stmt->execute([$email, $name, $occupation, $surname, $clearance, $pass, $expertise]);

    return [
        'success' => $ok,
        'message' => $ok
            ? "$name $surname has been created. Temporary password: changeme"
            : 'Something went wrong. Please try again.',
    ];
}

// ─── Update ───────────────────────────────────────────────────────────────────

function update_employee(
    string $name,
    string $surname,
    string $email,
    string $occupation,
    string $expertise,
    int    $clearance,
    string $plain_password = ''
): array {
    $name    = trim($name);
    $surname = trim($surname);

    if (!employee_exists($name, $surname)) {
        return [
            'success' => false,
            'message' => "$name $surname does not exist. <a href='../personells/add-new/'>Add New</a>",
        ];
    }

    if (trim($plain_password) !== '') {
        $pass = password_hash($plain_password, PASSWORD_BCRYPT);
        $stmt = get_db()->prepare(
            'UPDATE employees
             SET email_address = ?, occupation = ?, security_clearance = ?,
                 pass = ?, expertise = ?
             WHERE personnel_name = ? AND surname = ?'
        );
        $ok = $stmt->execute([$email, $occupation, $clearance, $pass, $expertise, $name, $surname]);
    } else {
        $stmt = get_db()->prepare(
            'UPDATE employees
             SET email_address = ?, occupation = ?, security_clearance = ?, expertise = ?
             WHERE personnel_name = ? AND surname = ?'
        );
        $ok = $stmt->execute([$email, $occupation, $clearance, $expertise, $name, $surname]);
    }

    return [
        'success' => $ok,
        'message' => $ok ? 'Personnel updated successfully.' : 'Something went wrong. Please try again.',
    ];
}

// ─── Delete ───────────────────────────────────────────────────────────────────

function delete_employee(string $name, string $surname): bool {
    $stmt = get_db()->prepare(
        'DELETE FROM employees WHERE personnel_name = ? AND surname = ?'
    );
    return $stmt->execute([trim($name), trim($surname)]);
}

function delete_agent(string $name, string $surname): bool {
    $stmt = get_db()->prepare(
        'DELETE FROM wim_agents WHERE personnel_name = ? AND surname = ?'
    );
    return $stmt->execute([trim($name), trim($surname)]);
}
