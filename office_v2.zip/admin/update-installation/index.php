<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

$id       = get_param('id');
$contract = $id !== '' ? get_contract_by_id($id) : null;
$msg      = '';

if ($contract && isset($_POST['update-installation'])) {
    $installation_date = post('installation-date');
    $unveiling_date    = post('unveiling-date');
    $contacts          = post('contacts');
    $other_number      = post('other-number');
    $grave_yard        = post('gray-location');
    $stones_details    = post('stones-details');
    $month             = month_from_date($installation_date);

    if ($installation_date === '' || $contacts === '' || $grave_yard === '') {
        $msg = error_html('Installation date, contacts, and grave yard are required.');
    } else {
        $ok = update_installation(
            $contract['contract_id'],
            $month,
            $installation_date,
            tf_or($unveiling_date),
            $contacts,
            tf_or($other_number),
            $grave_yard,
            or_else($stones_details, 'None')
        );

        if ($ok) {
            flash('success', "Installation details for #{$contract['contract_id']} updated.");
            header('Location: ../details/?id=' . urlencode($contract['contract_id']));
            exit;
        } else {
            $msg = error_html('Update failed. Please try again.');
        }
    }
}

$page_title  = 'Update Installation';
$assets_path = '../';
$nav_back    = '../details/?id=' . urlencode($id);
include '../includes/header.php';
?>

<?php if (!$contract): ?>
<div class="wim-card" style="text-align:center;padding:40px">
    <h3 style="color:#dc3545">Contract not found</h3>
    <a href="../search/" class="btn-primary" style="padding:8px 20px;border-radius:5px">Back to Search</a>
</div>
<?php else: ?>

<div class="wim-card" style="max-width:560px">
    <h2>Update Installation — #<?= htmlspecialchars($contract['contract_id']) ?></h2>
    <p style="color:#666">
        <?= htmlspecialchars(ucfirst($contract['buyer']) . ' ' . ucfirst($contract['surname'])) ?>
    </p>

    <?= $msg ?>

    <form method="POST" action="#" class="wim-form" style="max-width:100%">
        <div class="form-group">
            <label>Installation Date <span class="required-star">*</span></label>
            <input type="date" name="installation-date"
                   value="<?= htmlspecialchars($contract['installation_date'] === '0000-00-00' ? '' : $contract['installation_date']) ?>">
        </div>
        <div class="form-group">
            <label>Unveiling Date</label>
            <input type="date" name="unveiling-date"
                   value="<?= htmlspecialchars($contract['unveiling_date'] === '0000-00-00' ? '' : $contract['unveiling_date']) ?>">
        </div>
        <div class="form-group">
            <label>Contact Number <span class="required-star">*</span></label>
            <input type="text" name="contacts"
                   value="<?= htmlspecialchars($contract['contacts']) ?>"
                   placeholder="Primary contact number">
        </div>
        <div class="form-group">
            <label>Other / Proxy Number</label>
            <input type="text" name="other-number"
                   value="<?= htmlspecialchars($contract['other_number'] === 'TF' ? '' : $contract['other_number']) ?>"
                   placeholder="Secondary number">
        </div>
        <div class="form-group">
            <label>Grave Yard / Area <span class="required-star">*</span></label>
            <input type="text" name="gray-location"
                   value="<?= htmlspecialchars($contract['grave_yard']) ?>"
                   placeholder="Grave yard location">
        </div>
        <div class="form-group">
            <label>Stone Details / Notes</label>
            <textarea name="stones-details" placeholder="Additional stone details"><?= htmlspecialchars($contract['stones_details'] === 'None' ? '' : $contract['stones_details']) ?></textarea>
        </div>
        <button type="submit" name="update-installation" class="btn-primary">Save Changes</button>
    </form>
</div>

<?php endif; ?>
<?php include '../includes/footer.php'; ?>
