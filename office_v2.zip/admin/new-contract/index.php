<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

$result_html = '';
$form_values = []; // Repopulate form on error

if (isset($_POST['record-enter-btn'])) {

    $contract_id = trim($_POST['contract-id'] ?? '');
    $funeral     = isset($_POST['funeral']) ? 1 : 0;

    // Collect and sanitize all fields
    $f = [
        'contract_id'       => $contract_id,
        'buyer'             => post('buyer-name'),
        'surname'           => post('surname'),
        'other_name'        => tf_or(post('other-name')),
        'slab_type'         => post('slab-type'),
        'head_type'         => tf_or(post('head-type')),
        'unveiling_date'    => tf_or(post('unveiling-date')),
        'installation_date' => tf_or(post('installation-date')),
        'contract_type'     => post('purchase-type'),
        'contract_sign_date'=> post('contract_sign_date'),
        'stones_cost'       => post('stones-cost'),
        'grave_yard'        => post('gray-location'),
        'town'              => post('town'),
        'contacts'          => post('contacts'),
        'other_number'      => tf_or(post('other-number')),
        'dec_name'          => post('d-name'),
        'dSurname'          => post('d-surname'),
        'dotherName'        => tf_or(post('d-other-name')),
        'stone_name'        => post('stone_name'),
        'sales_rep'         => post('sales-rep'),
        'stones_details'    => or_else(post('stones-details'), 'None'),
        'proxy'             => or_else(post('proxy'), 'None'),
        'funeral'           => $funeral,
        'contract_status'   => post('status', 'Pending'),
        'outstanding_balance' => 'Pending',
        'approved_date'     => '0000-00-00',
        'approved_status'   => 0,
    ];

    // Derive month and year from dates
    $f['month']     = month_from_date($f['installation_date']);
    $f['contryear'] = date('Y', strtotime($f['contract_sign_date']));

    $form_values = $f; // keep for repopulation

    if ($contract_id === '') {
        $result_html = error_html('Contract number is required.');
    } elseif ($f['buyer'] === '') {
        $result_html = error_html("Buyer's name cannot be blank.");
    } else {
        if (contract_exists($contract_id)) {
            // ── Duplicate ID → save to conflict_contracts ──────────────────
            $conflict_data = [
                'original_contract_id' => $contract_id,
                'buyer'             => $f['buyer'],
                'surname'           => $f['surname'],
                'other_name'        => $f['other_name'],
                'slab_type'         => $f['slab_type'],
                'head_type'         => $f['head_type'],
                'unveiling_date'    => $f['unveiling_date'],
                'installation_date' => $f['installation_date'],
                'contract_type'     => $f['contract_type'],
                'contract_sign_date'=> $f['contract_sign_date'],
                'stones_cost'       => $f['stones_cost'],
                'grave_yard'        => $f['grave_yard'],
                'town'              => $f['town'],
                'contacts'          => $f['contacts'],
                'other_number'      => $f['other_number'],
                'dec_name'          => $f['dec_name'],
                'dSurname'          => $f['dSurname'],
                'dotherName'        => $f['dotherName'],
                'stone_name'        => $f['stone_name'],
                'sales_rep'         => $f['sales_rep'],
                'stones_details'    => $f['stones_details'],
                'funeral'           => $f['funeral'],
                'proxy'             => $f['proxy'],
            ];

            $saved = save_conflict_contract($conflict_data, current_user());

            if ($saved) {
                $result_html = "<div class='flash flash-warning'>
                    <strong>Contract #{$contract_id} already exists.</strong><br>
                    This entry has been saved to the
                    <a href='../conflicts/'>Conflict Contracts</a> register for manual review.
                    Both entries will be visible there for comparison.
                </div>";
            } else {
                $result_html = error_html("Contract #{$contract_id} already exists and the conflict could not be saved. Please contact your administrator.");
            }
        } else {
            // ── Fresh contract — save normally ─────────────────────────────
            $ok = create_contract($f);
            if ($ok) {
                $result_html = success_html("Contract #{$contract_id} saved successfully.");
                $form_values = []; // Clear form on success
            } else {
                $result_html = error_html('An error occurred. Please try again.');
            }
        }
    }
}

$page_title  = 'New Contract';
$assets_path = '../';
$nav_back    = '../';
include '../includes/header.php';

// Helper: repopulate a text field
function fv(array $vals, string $key): string {
    return htmlspecialchars($vals[$key] ?? '');
}
function fsel(array $vals, string $key, string $option): string {
    return ($vals[$key] ?? '') === $option ? 'selected' : '';
}
?>

<div class="wim-card" style="max-width:680px;margin:0 auto">
    <h2>New Contract</h2>

    <?= $result_html ?>

    <form method="POST" action="#" class="wim-form" style="max-width:100%">

        <!-- ── Contract Info ── -->
        <div class="form-group">
            <label>Contract No <span class="required-star">*</span></label>
            <input type="text" name="contract-id" placeholder="Enter contract number"
                   value="<?= fv($form_values, 'contract_id') ?>" required>
        </div>
        <div class="form-group">
            <label>Contract Signed Date <span class="required-star">*</span></label>
            <input type="date" name="contract_sign_date"
                   value="<?= fv($form_values, 'contract_sign_date') ?>" required>
        </div>
        <div class="form-group">
            <label>Contract Status</label>
            <select name="status">
                <option value="Pending" <?= fsel($form_values,'contract_status','Pending') ?>>Pending</option>
                <option value="Installed" <?= fsel($form_values,'contract_status','Installed') ?>>Installed</option>
            </select>
        </div>
        <div class="form-group">
            <label>Purchase Type <span class="required-star">*</span></label>
            <select name="purchase-type" required>
                <option value="Lay Buy" <?= fsel($form_values,'contract_type','Lay Buy') ?>>Lay Buy</option>
                <option value="Cash" <?= fsel($form_values,'contract_type','Cash') ?>>Cash</option>
            </select>
        </div>
        <div class="checkbox-row">
            <label for="funeral" style="margin-bottom:0">Funeral Display</label>
            <input type="checkbox" id="funeral" name="funeral" value="1"
                   <?= !empty($form_values['funeral']) ? 'checked' : '' ?>>
        </div>

        <div class="form-divider"></div>
        <div class="form-section-title">Stone Details</div>

        <div class="form-group">
            <label>Stone / Stone Code <span class="required-star">*</span></label>
            <input type="text" name="stone_name" placeholder="Enter name / code"
                   value="<?= fv($form_values, 'stone_name') ?>">
        </div>
        <div class="form-group">
            <label>Total Cost <span class="required-star">*</span></label>
            <input type="text" name="stones-cost" placeholder="Enter total cost"
                   value="<?= fv($form_values, 'stones_cost') ?>" required>
        </div>
        <div class="form-group">
            <label>Slab Type <span class="required-star">*</span></label>
            <select name="slab-type" required>
                <option value="None" <?= fsel($form_values,'slab_type','None') ?>>None</option>
                <option value="Crusher Slab" <?= fsel($form_values,'slab_type','Crusher Slab') ?>>Crusher Slab</option>
                <option value="Semi Crusher" <?= fsel($form_values,'slab_type','Semi Crusher') ?>>Semi Crusher</option>
                <option value="Full Slab" <?= fsel($form_values,'slab_type','Full Slab') ?>>Full Slab</option>
                <option value="Enclosed body" <?= fsel($form_values,'slab_type','Enclosed body') ?>>Enclosed body</option>
            </select>
        </div>
        <div class="form-group">
            <label>Head Type</label>
            <input type="text" name="head-type" placeholder="Enter head type"
                   value="<?= fv($form_values, 'head_type') ?>">
        </div>
        <div class="form-group">
            <label>Additional Notes</label>
            <textarea name="stones-details" placeholder="Enter stone details & extras"><?= fv($form_values, 'stones_details') ?></textarea>
        </div>

        <div class="form-divider"></div>
        <div class="form-section-title">Client Details</div>

        <div class="form-group">
            <label>Buyer's Surname <span class="required-star">*</span></label>
            <input type="text" name="surname" placeholder="Enter surname"
                   value="<?= fv($form_values, 'surname') ?>" required>
        </div>
        <div class="form-group">
            <label>Buyer's Name <span class="required-star">*</span></label>
            <input type="text" name="buyer-name" placeholder="Enter name"
                   value="<?= fv($form_values, 'buyer') ?>" required>
        </div>
        <div class="form-group">
            <label>Other Name</label>
            <input type="text" name="other-name" placeholder="Other name"
                   value="<?= fv($form_values, 'other_name') ?>">
        </div>
        <div class="form-group">
            <label>Contact Number <span class="required-star">*</span></label>
            <input type="text" name="contacts" placeholder="Enter contact number"
                   value="<?= fv($form_values, 'contacts') ?>" required>
        </div>
        <div class="form-group">
            <label>Proxy for Family</label>
            <input type="text" name="proxy" placeholder="Proxy name"
                   value="<?= fv($form_values, 'proxy') ?>">
        </div>
        <div class="form-group">
            <label>Proxy's Number</label>
            <input type="text" name="other-number" placeholder="Proxy contact"
                   value="<?= fv($form_values, 'other_number') ?>">
        </div>

        <div class="form-divider"></div>

        <div class="form-group">
            <label>Installation Date</label>
            <input type="date" name="installation-date"
                   value="<?= fv($form_values, 'installation_date') ?>">
        </div>
        <div class="form-group">
            <label>Unveiling Date</label>
            <input type="date" name="unveiling-date"
                   value="<?= fv($form_values, 'unveiling_date') ?>">
        </div>

        <div class="form-divider"></div>
        <div class="form-section-title">Deceased Details</div>

        <div class="form-group">
            <label>Surname <span class="required-star">*</span></label>
            <input type="text" name="d-surname" placeholder="Deceased surname"
                   value="<?= fv($form_values, 'dSurname') ?>" required>
        </div>
        <div class="form-group">
            <label>Name <span class="required-star">*</span></label>
            <input type="text" name="d-name" placeholder="Deceased name"
                   value="<?= fv($form_values, 'dec_name') ?>" required>
        </div>
        <div class="form-group">
            <label>Other Name</label>
            <input type="text" name="d-other-name" placeholder="Deceased other name"
                   value="<?= fv($form_values, 'dotherName') ?>">
        </div>

        <div class="form-divider"></div>
        <div class="form-section-title">Grave Yard Details</div>

        <div class="form-group">
            <label>Town <span class="required-star">*</span></label>
            <select name="town" required>
                <?php foreach (['Lichtenburg','Mahikeng','Rustenburg','Brits','Zeerust','Other'] as $t): ?>
                <option value="<?= $t ?>" <?= fsel($form_values,'town',$t) ?>><?= $t ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Suburb / Area <span class="required-star">*</span></label>
            <input type="text" name="gray-location" placeholder="Area where grave yard is located"
                   value="<?= fv($form_values, 'grave_yard') ?>" required>
        </div>
        <div class="form-group">
            <label>Sales Rep <span class="required-star">*</span></label>
            <select name="sales-rep" required>
                <?php foreach (['Choose One','W Mmutloane','B Mmutloane','T Sebati','K Maoba','Other'] as $rep): ?>
                <option value="<?= $rep ?>" <?= fsel($form_values,'sales_rep',$rep) ?>><?= $rep ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="margin-top:24px">
            <button type="submit" name="record-enter-btn" class="btn-primary">Enter Record</button>
        </div>

    </form>
</div>

<?php include '../includes/footer.php'; ?>
