<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

$msg = '';

// Approve a contract from this page
if (isset($_POST['approve']) && isset($_POST['contract_id'])) {
    $cid = post('contract_id');
    $ok  = approve_contract($cid);
    $ok ? flash('success', "Contract #$cid approved.")
        : flash('error', "Could not approve Contract #$cid.");
    header('Location: index.php');
    exit;
}

$approved = get_approved_contracts();

$page_title  = 'Approved Contracts';
$assets_path = '../';
$nav_back    = '../';
include '../includes/header.php';
?>

<h2 class="wim-section-title">Approved Contracts</h2>

<?php if (empty($approved)): ?>
<div class="wim-card" style="text-align:center;padding:40px;color:#888">
    <p style="font-size:16px">No approved contracts yet.</p>
</div>
<?php else: ?>

<p style="color:#666;margin-bottom:16px"><?= count($approved) ?> approved contract<?= count($approved) !== 1 ? 's' : '' ?></p>

<?php foreach ($approved as $c): ?>
<div class="approved-card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px">
        <div>
            <span class="contract-id">#<?= htmlspecialchars($c['contract_id']) ?></span>
            <span style="font-weight:600;margin-left:12px">
                <?= htmlspecialchars(ucfirst($c['buyer']) . ' ' . ucfirst($c['surname'])) ?>
            </span>
            <span style="font-size:13px;color:#555;margin-left:12px">
                <?= htmlspecialchars($c['contacts']) ?>
            </span>
        </div>
        <div style="font-size:13px;color:#28a745;font-weight:700">
            Approved: <?= htmlspecialchars($c['approved_date']) ?>
        </div>
    </div>
    <div style="margin-top:8px;font-size:13px;color:#555;display:flex;gap:18px;flex-wrap:wrap">
        <span><strong>Stone:</strong> <?= htmlspecialchars($c['stone_name']) ?></span>
        <span><strong>Slab:</strong> <?= htmlspecialchars($c['slab_type']) ?></span>
        <span><strong>Install:</strong> <?= display_date($c['installation_date']) ?></span>
        <span><strong>Rep:</strong> <?= htmlspecialchars($c['sales_rep']) ?></span>
        <span><strong>Status:</strong> <?= htmlspecialchars($c['contract_status']) ?></span>
    </div>
    <div class="contract-actions" style="margin-top:10px">
        <a href="../details/?id=<?= urlencode($c['contract_id']) ?>" class="btn-view">View</a>
        <a href="../update-installation/?id=<?= urlencode($c['contract_id']) ?>" class="btn-edit">Update</a>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
