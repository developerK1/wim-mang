<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

$results    = [];
$term       = get_param('q');
$searched   = false;

if ($term !== '') {
    $results  = search_contracts($term);
    $searched = true;
}

$page_title  = 'Search';
$assets_path = '../';
$nav_back    = '../';
include '../includes/header.php';
?>

<h2 class="wim-section-title">Search Contracts</h2>

<form method="GET" action="index.php" class="search-bar">
    <input type="text" name="q" placeholder="Search by name, surname, contract ID, deceased..."
           value="<?= htmlspecialchars($term) ?>" autofocus>
    <button type="submit" class="btn-primary">Search</button>
    <?php if ($searched): ?>
        <a href="index.php" class="btn-secondary" style="padding:8px 16px;border-radius:5px;font-weight:700">Clear</a>
    <?php endif; ?>
</form>

<?php if ($searched && empty($results)): ?>
<div class="wim-card">
    <p style="text-align:center;padding:30px;color:#888">
        No contracts found for <strong>"<?= htmlspecialchars($term) ?>"</strong>
    </p>
</div>
<?php endif; ?>

<?php if ($searched && !empty($results)): ?>
<p style="color:#666;margin-bottom:16px">
    <?= count($results) ?> result<?= count($results) !== 1 ? 's' : '' ?> for
    <strong>"<?= htmlspecialchars($term) ?>"</strong>
</p>
<?php foreach ($results as $c): ?>
<div class="contract-row <?= strtolower($c['contract_status']) === 'installed' ? 'installed' : 'pending' ?>">
    <div class="contract-id">#<?= htmlspecialchars($c['contract_id']) ?></div>
    <div class="contract-buyer">
        <?= htmlspecialchars(ucfirst($c['buyer']) . ' ' . ucfirst($c['surname'])) ?>
    </div>
    <div class="contract-meta">
        <span><?= htmlspecialchars($c['contacts']) ?></span> &nbsp;|&nbsp;
        <span><?= htmlspecialchars($c['contract_type']) ?></span> &nbsp;|&nbsp;
        <span>Status: <strong><?= htmlspecialchars($c['contract_status']) ?></strong></span>
    </div>
    <div class="contract-meta">
        Install: <?= display_date($c['installation_date']) ?> &nbsp;|&nbsp;
        Unveil: <?= display_date($c['unveiling_date']) ?>
    </div>
    <div class="contract-actions">
        <a href="../details/?id=<?= urlencode($c['contract_id']) ?>" class="btn-view">View</a>
        <a href="../update-status/?id=<?= urlencode($c['contract_id']) ?>" class="btn-status">Status</a>
        <a href="../update-installation/?id=<?= urlencode($c['contract_id']) ?>" class="btn-edit">Update</a>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php if (!$searched): ?>
<div class="wim-card" style="text-align:center;padding:40px;color:#888">
    <p style="font-size:16px">Enter a name, surname, contract ID or deceased name above to search.</p>
</div>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
