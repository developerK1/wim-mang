<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_clearance(1, '../'); // Admin only — clearance 1

$msg = '';

// Resolve a conflict
if (isset($_POST['resolve']) && isset($_POST['conflict_id'])) {
    $cid  = (int)$_POST['conflict_id'];
    $note = post('resolution_note');
    resolve_conflict($cid, $note)
        ? flash('success', "Conflict #$cid marked as resolved.")
        : flash('error', "Could not resolve conflict #$cid.");
    header('Location: index.php');
    exit;
}

// Promote a conflict to a real contract (admin resolves it by saving)
if (isset($_POST['promote']) && isset($_POST['conflict_id'])) {
    $cid      = (int)$_POST['conflict_id'];
    $conflict = get_conflict_by_id($cid);

    if ($conflict) {
        $new_id = trim($_POST['new_contract_id'] ?? $conflict['original_contract_id']);

        if (contract_exists($new_id)) {
            flash('error', "Contract #$new_id still exists. Choose a different contract number.");
        } else {
            $data = [
                'contract_id'       => $new_id,
                'buyer'             => $conflict['buyer'],
                'surname'           => $conflict['surname'],
                'other_name'        => $conflict['other_name'],
                'slab_type'         => $conflict['slab_type'],
                'head_type'         => $conflict['head_type'],
                'unveiling_date'    => $conflict['unveiling_date'],
                'installation_date' => $conflict['installation_date'],
                'month'             => month_from_date($conflict['installation_date']),
                'contryear'         => date('Y', strtotime($conflict['contract_sign_date'])),
                'contract_type'     => $conflict['contract_type'],
                'contract_sign_date'=> $conflict['contract_sign_date'],
                'stones_cost'       => $conflict['stones_cost'],
                'grave_yard'        => $conflict['grave_yard'],
                'town'              => $conflict['town'],
                'contacts'          => $conflict['contacts'],
                'other_number'      => $conflict['other_number'],
                'dec_name'          => $conflict['dec_name'],
                'dSurname'          => $conflict['dSurname'],
                'dotherName'        => $conflict['dotherName'],
                'stone_name'        => $conflict['stone_name'],
                'sales_rep'         => $conflict['sales_rep'],
                'stones_details'    => $conflict['stones_details'],
                'funeral'           => $conflict['funeral'],
                'proxy'             => $conflict['proxy'],
                'contract_status'   => 'Pending',
                'outstanding_balance' => 'Pending',
                'approved_date'     => '0000-00-00',
                'approved_status'   => 0,
            ];

            if (create_contract($data)) {
                resolve_conflict($cid, "Promoted to contract #$new_id by " . current_user());
                flash('success', "Conflict saved as Contract #$new_id and marked resolved.");
            } else {
                flash('error', "Could not save the contract. Please try again.");
            }
        }
    }
    header('Location: index.php');
    exit;
}

// Delete / discard a conflict entry
if (isset($_POST['discard']) && isset($_POST['conflict_id'])) {
    $cid = (int)$_POST['conflict_id'];
    delete_conflict($cid)
        ? flash('success', "Conflict #$cid discarded.")
        : flash('error', "Could not discard conflict #$cid.");
    header('Location: index.php');
    exit;
}

$conflicts   = get_all_conflict_contracts();
$unresolved  = array_filter($conflicts, fn($c) => $c['resolved'] == 0);
$resolved    = array_filter($conflicts, fn($c) => $c['resolved'] == 1);

$page_title  = 'Conflict Contracts';
$assets_path = '../';
$nav_back    = '../';
include '../includes/header.php';
?>

<h2 class="wim-section-title">
    Conflict Contracts
    <?php if (count($unresolved)): ?>
    <span class="conflict-badge" style="font-size:16px;vertical-align:middle">
        <?= count($unresolved) ?> unresolved
    </span>
    <?php endif; ?>
</h2>

<div class="wim-card">
    <p style="color:#666">
        Contracts listed here have a <strong>duplicate Contract ID</strong> that was detected when entry was attempted.
        Review each entry against the original contract, then either
        <strong>promote</strong> it (save with a corrected ID),
        <strong>resolve</strong> it (mark as handled with a note), or
        <strong>discard</strong> it.
    </p>
</div>

<?php if (empty($conflicts)): ?>
<div class="wim-card">
    <p style="text-align:center;color:#888;padding:30px">No conflict contracts on record.</p>
</div>
<?php endif; ?>

<?php foreach ($unresolved as $c): ?>
<?php $orig = get_contract_by_id($c['original_contract_id']); ?>

<div class="wim-card" style="border-left:4px solid #ffc107">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <div>
            <span class="conflict-badge">Unresolved</span>
            <strong style="font-size:18px;margin-left:10px">Conflict #<?= $c['id'] ?></strong>
            <span style="color:#888;font-size:13px;margin-left:10px">
                Flagged by <?= htmlspecialchars($c['flagged_by']) ?>
                on <?= date('d M Y, H:i', strtotime($c['flagged_at'])) ?>
            </span>
        </div>
        <span style="font-size:14px;color:#555">
            Duplicate of Contract ID: <strong style="color:#FF7F00"><?= htmlspecialchars($c['original_contract_id']) ?></strong>
        </span>
    </div>

    <!-- Side-by-side comparison -->
    <div class="compare-grid">
        <!-- Original -->
        <div class="wim-card" style="border-top:3px solid #28a745;margin-bottom:0">
            <h3 style="color:#28a745;font-size:16px;margin-top:0">
                ✓ Original — Contract #<?= htmlspecialchars($c['original_contract_id']) ?>
            </h3>
            <?php if ($orig): ?>
            <table class="detail-table" style="font-size:13px">
                <tr><th>Buyer</th><td><?= htmlspecialchars($orig['buyer'] . ' ' . $orig['surname']) ?></td></tr>
                <tr><th>Contacts</th><td><?= htmlspecialchars($orig['contacts']) ?></td></tr>
                <tr><th>Stone</th><td><?= htmlspecialchars($orig['stone_name']) ?></td></tr>
                <tr><th>Cost</th><td>R <?= htmlspecialchars($orig['stones_cost']) ?></td></tr>
                <tr><th>Signed</th><td><?= htmlspecialchars($orig['contract_sign_date']) ?></td></tr>
                <tr><th>Status</th><td><?= htmlspecialchars($orig['contract_status']) ?></td></tr>
                <tr><th>Sales Rep</th><td><?= htmlspecialchars($orig['sales_rep']) ?></td></tr>
                <tr><th>Grave Yard</th><td><?= htmlspecialchars($orig['grave_yard']) ?>, <?= htmlspecialchars($orig['town']) ?></td></tr>
                <tr><th>Deceased</th><td><?= htmlspecialchars($orig['dec_name'] . ' ' . $orig['dSurname']) ?></td></tr>
            </table>
            <a href="../details/?id=<?= urlencode($orig['contract_id']) ?>" class="btn-view" style="display:inline-block;margin-top:10px;padding:6px 14px;border-radius:5px;font-size:13px">
                View full contract →
            </a>
            <?php else: ?>
            <p style="color:#dc3545">Original contract not found — it may have been deleted.</p>
            <?php endif; ?>
        </div>

        <!-- Conflicting entry -->
        <div class="wim-card" style="border-top:3px solid #ffc107;margin-bottom:0">
            <h3 style="color:#856404;font-size:16px;margin-top:0">
                ⚠ Conflict entry — attempted ID: #<?= htmlspecialchars($c['original_contract_id']) ?>
            </h3>
            <table class="detail-table" style="font-size:13px">
                <tr><th>Buyer</th><td><?= htmlspecialchars($c['buyer'] . ' ' . $c['surname']) ?></td></tr>
                <tr><th>Contacts</th><td><?= htmlspecialchars($c['contacts']) ?></td></tr>
                <tr><th>Stone</th><td><?= htmlspecialchars($c['stone_name']) ?></td></tr>
                <tr><th>Cost</th><td>R <?= htmlspecialchars($c['stones_cost']) ?></td></tr>
                <tr><th>Signed</th><td><?= htmlspecialchars($c['contract_sign_date']) ?></td></tr>
                <tr><th>Sales Rep</th><td><?= htmlspecialchars($c['sales_rep']) ?></td></tr>
                <tr><th>Grave Yard</th><td><?= htmlspecialchars($c['grave_yard']) ?>, <?= htmlspecialchars($c['town']) ?></td></tr>
                <tr><th>Deceased</th><td><?= htmlspecialchars($c['dec_name'] . ' ' . $c['dSurname']) ?></td></tr>
                <tr><th>Notes</th><td><?= htmlspecialchars($c['stones_details']) ?></td></tr>
            </table>
        </div>
    </div>

    <!-- Action forms -->
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:20px;padding-top:16px;border-top:1px solid #eee">

        <!-- Promote with new ID -->
        <form method="POST" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <input type="hidden" name="conflict_id" value="<?= $c['id'] ?>">
            <input type="text" name="new_contract_id"
                   placeholder="New contract ID"
                   value="<?= htmlspecialchars($c['original_contract_id']) ?>-B"
                   style="width:160px;padding:7px 10px;border:1px solid #ccc;border-radius:5px;font-size:13px">
            <button type="submit" name="promote" class="btn-primary" style="font-size:13px;padding:7px 14px">
                Save as New Contract
            </button>
        </form>

        <!-- Resolve with note -->
        <form method="POST" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <input type="hidden" name="conflict_id" value="<?= $c['id'] ?>">
            <input type="text" name="resolution_note"
                   placeholder="Resolution note..."
                   style="width:200px;padding:7px 10px;border:1px solid #ccc;border-radius:5px;font-size:13px">
            <button type="submit" name="resolve" class="btn-secondary" style="font-size:13px;padding:7px 14px">
                Mark Resolved
            </button>
        </form>

        <!-- Discard -->
        <form method="POST" onsubmit="return confirm('Discard this conflict entry permanently?')">
            <input type="hidden" name="conflict_id" value="<?= $c['id'] ?>">
            <button type="submit" name="discard" class="btn-danger" style="font-size:13px;padding:7px 14px">
                Discard
            </button>
        </form>
    </div>
</div>
<?php endforeach; ?>

<!-- Resolved conflicts (collapsed) -->
<?php if (!empty($resolved)): ?>
<details style="margin-top:30px">
    <summary style="cursor:pointer;font-weight:700;color:#888;padding:10px 0">
        Resolved Conflicts (<?= count($resolved) ?>)
    </summary>
    <?php foreach ($resolved as $c): ?>
    <div class="wim-card" style="opacity:0.7;border-left:4px solid #28a745;margin-top:12px">
        <span class="conflict-badge resolved">Resolved</span>
        <strong style="margin-left:10px">Conflict #<?= $c['id'] ?></strong>
        — Original ID: <?= htmlspecialchars($c['original_contract_id']) ?>
        — <?= htmlspecialchars($c['buyer'] . ' ' . $c['surname']) ?>
        <br>
        <small style="color:#666">
            Resolved: <?= date('d M Y', strtotime($c['resolved_at'])) ?>
            <?= $c['resolution_note'] ? ' — ' . htmlspecialchars($c['resolution_note']) : '' ?>
        </small>
    </div>
    <?php endforeach; ?>
</details>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
