<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

// Clearance 2 users CANNOT access the scheduling page
require_clearance(1, '../');

$months = [
    'January','February','March','April','May','June',
    'July','August','September','October','November','December'
];

$current_month = date('F');
$selected_month = $current_month;

if (isset($_POST['getMonth']) && in_array($_POST['month'], $months, true)) {
    $selected_month = $_POST['month'];
}

$contracts = get_contracts_by_month($selected_month);

$page_title  = 'Installations';
$assets_path = '../';
$nav_back    = '../';
include '../includes/header.php';
?>

<h2 class="wim-section-title">Installations — <?= htmlspecialchars($selected_month) ?></h2>

<!-- Month selector -->
<div class="wim-card" style="padding:16px 24px">
    <form method="POST" action="#" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
        <label style="font-weight:700;color:#FF7F00">Select Month:</label>
        <select name="month" style="padding:8px 12px;border:2px solid #FF7F00;border-radius:7px;font-weight:700;font-size:15px;outline:none">
            <?php foreach ($months as $m): ?>
            <option value="<?= $m ?>" <?= $m === $selected_month ? 'selected' : '' ?>><?= $m ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" name="getMonth" class="btn-primary" style="padding:8px 20px">View</button>
        <!-- Quick jumps -->
        <?php
        $idx        = array_search($current_month, $months);
        $next       = $months[($idx + 1) % 12];
        $third      = $months[($idx + 2) % 12];
        foreach ([$current_month => 'This Month', $next => 'Next Month', $third => '+2 Months'] as $m => $label):
        ?>
        <form method="POST" action="#" style="display:inline">
            <input type="hidden" name="month" value="<?= $m ?>">
            <button type="submit" name="getMonth"
                    class="btn-secondary"
                    style="padding:7px 14px;font-size:13px;border-radius:5px;border:none;cursor:pointer">
                <?= $label ?> (<?= $m ?>)
            </button>
        </form>
        <?php endforeach; ?>
    </form>
</div>

<!-- Results -->
<?php if (empty($contracts)): ?>
<div class="wim-card" style="text-align:center;padding:40px;color:#888">
    <p style="font-size:16px">No installations scheduled for <strong><?= htmlspecialchars($selected_month) ?></strong>.</p>
</div>
<?php else: ?>
<p style="color:#666;margin-bottom:14px">
    <?= count($contracts) ?> installation<?= count($contracts) !== 1 ? 's' : '' ?> scheduled for
    <strong><?= htmlspecialchars($selected_month) ?></strong>
</p>

<?php foreach ($contracts as $c): ?>
<div class="install-card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px">
        <div>
            <h5 style="margin:0 0 4px">#<?= htmlspecialchars($c['contract_id']) ?></h5>
            <p style="margin:0;font-weight:600">
                <?= htmlspecialchars(ucfirst($c['buyer']) . ' ' . ucfirst($c['surname'])) ?>
            </p>
            <p style="margin:4px 0;font-size:13px;color:#555">
                <?= htmlspecialchars($c['contacts']) ?>
                <?= $c['other_number'] && $c['other_number'] !== 'TF' ? ' / ' . htmlspecialchars($c['other_number']) : '' ?>
            </p>
        </div>
        <div style="text-align:right">
            <p style="margin:0;font-weight:700;color:#FF7F00">
                Install: <?= display_date($c['installation_date']) ?>
            </p>
            <p style="margin:4px 0;font-size:13px;color:#555">
                Unveiling: <?= display_date($c['unveiling_date']) ?>
            </p>
        </div>
    </div>
    <div style="margin-top:10px;font-size:13px;color:#555;display:flex;gap:20px;flex-wrap:wrap">
        <span><strong>Stone:</strong> <?= htmlspecialchars($c['stone_name']) ?></span>
        <span><strong>Slab:</strong> <?= htmlspecialchars($c['slab_type']) ?></span>
        <span><strong>Grave Yard:</strong> <?= htmlspecialchars($c['grave_yard']) ?>, <?= htmlspecialchars($c['town']) ?></span>
        <span><strong>Rep:</strong> <?= htmlspecialchars($c['sales_rep']) ?></span>
    </div>
    <?php if ($c['stones_details'] && $c['stones_details'] !== 'None'): ?>
    <p style="margin-top:8px;font-size:13px;color:#666;border-top:1px solid #eee;padding-top:8px">
        <strong>Notes:</strong> <?= htmlspecialchars($c['stones_details']) ?>
    </p>
    <?php endif; ?>
    <div class="contract-actions" style="margin-top:10px">
        <a href="../details/?id=<?= urlencode($c['contract_id']) ?>" class="btn-view">View</a>
        <a href="../update-installation/?id=<?= urlencode($c['contract_id']) ?>" class="btn-edit">Update</a>
        <a href="../update-status/?id=<?= urlencode($c['contract_id']) ?>" class="btn-status">Status</a>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
