<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

$id       = get_param('id');
$contract = $id !== '' ? get_contract_by_id($id) : null;
$msg      = '';

if ($contract && isset($_POST['update-status'])) {
    $new_status = post('status');
    $allowed    = ['Pending', 'Installed', 'In Progress', 'Cancelled'];

    if (in_array($new_status, $allowed, true)) {
        $ok = update_contract_status($contract['contract_id'], $new_status);
        if ($ok) {
            flash('success', "Contract #{$contract['contract_id']} status updated to '{$new_status}'.");
            header('Location: ../details/?id=' . urlencode($contract['contract_id']));
            exit;
        } else {
            $msg = error_html('Update failed. Please try again.');
        }
    } else {
        $msg = error_html('Invalid status value.');
    }
}

$page_title  = 'Update Status';
$assets_path = '../';
$nav_back    = '../details/?id=' . urlencode($id);
include '../includes/header.php';
?>

<?php if (!$contract): ?>
<div class="wim-card" style="text-align:center;padding:40px">
    <h3 style="color:#dc3545">Contract not found</h3>
    <a href="../search/" class="btn-primary" style="padding:8px 20px;border-radius:5px">Back to Search</a>
</div>
<?php else: ?>

<div class="wim-card" style="max-width:480px">
    <h2>Update Status — #<?= htmlspecialchars($contract['contract_id']) ?></h2>
    <p style="color:#666">
        <?= htmlspecialchars(ucfirst($contract['buyer']) . ' ' . ucfirst($contract['surname'])) ?>
        &mdash; current status:
        <strong style="color:#FF7F00"><?= htmlspecialchars($contract['contract_status']) ?></strong>
    </p>

    <?= $msg ?>

    <form method="POST" action="#" class="wim-form">
        <div class="form-group">
            <label>New Status</label>
            <select name="status">
                <?php foreach (['Pending','In Progress','Installed','Cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $contract['contract_status'] === $s ? 'selected' : '' ?>>
                    <?= $s ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" name="update-status" class="btn-primary">Save Status</button>
    </form>
</div>

<?php endif; ?>
<?php include '../includes/footer.php'; ?>
