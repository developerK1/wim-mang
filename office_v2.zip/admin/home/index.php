<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

require_auth('../logging-in/');

// Logout handler
if (isset($_POST['log-out'])) {
    destroy_session();
    header('Location: ../logging-in/');
    exit;
}

// Stats
$db          = get_db();
$contracts = get_recent_contracts(30);
$total       = (int)$db->query('SELECT COUNT(*) FROM contracts')->fetchColumn();
$pending     = (int)$db->query("SELECT COUNT(*) FROM contracts WHERE contract_status = 'Pending'")->fetchColumn();
$installed   = (int)$db->query("SELECT COUNT(*) FROM contracts WHERE contract_status = 'Installed'")->fetchColumn();
$conflicts   = (int)$db->query('SELECT COUNT(*) FROM conflict_contracts WHERE resolved = 0')->fetchColumn();
$current_month = date('F');
$this_month  = (int)$db->query("SELECT COUNT(*) FROM contracts WHERE month = '$current_month' AND installation_date != '0000-00-00'")->fetchColumn();
$plant_pending = 0;
try {
    $plant_pending = (int)$db->query(
        'SELECT COUNT(*) FROM tombstones_installations WHERE confirm_installation = 1 AND (office_confirmed IS NULL OR office_confirmed = 0)'
    )->fetchColumn();
} catch (Exception $e) {
    // tombstones_installations may not exist in dev — fail silently
}

$page_title  = 'Dashboard';
$assets_path = '../';
include '../includes/header.php';
?>

<h2 class="wim-section-title">Welcome, <?= current_user() ?></h2>

<!-- Stats row -->
<div class="dashboard-grid">
    <div class="dash-card">
        <div class="dash-number"><?= $total ?></div>
        <div class="dash-label">Total Contracts</div>
    </div>
    <div class="dash-card">
        <div class="dash-number"><?= $pending ?></div>
        <div class="dash-label">Pending</div>
    </div>
    <div class="dash-card">
        <div class="dash-number" style="color:#28a745"><?= $installed ?></div>
        <div class="dash-label">Installed</div>
    </div>
 
    <?php if ($conflicts > 0): ?>
    <div class="dash-card" style="border-top-color:#ffc107">
        <div class="dash-number" style="color:#ffc107"><?= $conflicts ?></div>
        <div class="dash-label">Unresolved Conflicts</div>
    </div>
    <?php endif; ?>
    <?php if ($plant_pending > 0): ?>
    <div class="dash-card" style="border-top-color:#28a745">
        <div class="dash-number" style="color:#28a745"><?= $plant_pending ?></div>
        <div class="dash-label">Plant — Awaiting Confirmation</div>
    </div>
	
    <?php endif; ?>
	<div class="dash-card">
		<a href="../new-contract/"><button id="add-btn-con"class="dash-number" style="font-size:26px !important;margin:auto;padding:8px;border-radius:8px;background-color:orange;color :white">ADD NEW</button></a>
    </div>
</div>

<!-- All contracts list -->
<div class="wim-card">
    <h2>Recent 30 Contracts</h2>
    <?php if (empty($contracts)): ?>
        <p style="color:#888;text-align:center;padding:30px">No contracts on record yet.</p>
    <?php else: ?>
        <?php foreach ($contracts as $c): ?>
        <div class="contract-row <?= strtolower($c['contract_status']) === 'installed' ? 'installed' : 'pending' ?>">
            <div class="contract-id">#<?= htmlspecialchars($c['contract_id']) ?></div>
            <div class="contract-buyer">
                <?= htmlspecialchars(ucfirst($c['buyer']) . ' ' . ucfirst($c['surname'])) ?>
            </div>
            <div class="contract-meta">
                <?= htmlspecialchars($c['contract_type']) ?> &nbsp;|&nbsp;
                Status: <strong><?= htmlspecialchars($c['contract_status']) ?></strong>
            </div>
            <div class="contract-meta">
                Install: <?= display_date($c['installation_date']) ?>
            </div>
            <div class="contract-actions">
                <a href="../details/?id=<?= urlencode($c['contract_id']) ?>" class="btn-view">View</a>
                <a href="../update-status/?id=<?= urlencode($c['contract_id']) ?>" class="btn-status">Status</a>
                <a href="../update-installation/?id=<?= urlencode($c['contract_id']) ?>" class="btn-edit">Update</a>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Quick links -->
<div class="wim-card">
    <h2>Quick Links</h2>
    <div style="display:flex;gap:12px;flex-wrap:wrap">
        <a href="../new-contract/" class="btn-primary" style="padding:10px 20px;border-radius:5px;font-weight:700">+ New Contract</a>
        <a href="../search/" class="btn-secondary" style="padding:10px 20px;border-radius:5px;font-weight:700">Search Contracts</a>
        <a href="https://wimcorporation.co.za/plant/plant/home/" class="btn-secondary" style="padding:10px 20px;border-radius:5px;font-weight:700">Approved</a>
        <?php if (is_admin()): ?>
        <a href="../personells/" class="btn-secondary" style="padding:10px 20px;border-radius:5px;font-weight:700">Personnel</a>
        <a href="../conflicts/" class="btn-secondary" style="padding:10px 20px;border-radius:5px;font-weight:700">
            Conflict Contracts <?= $conflicts > 0 ? "<span class='conflict-badge'>$conflicts</span>" : '' ?>
        </a>
        <a href="../confirm-installations/" class="btn-secondary" style="padding:10px 20px;border-radius:5px;font-weight:700">
            Confirm Installations <?= $plant_pending > 0 ? "<span class='conflict-badge' style='background:#28a745'>$plant_pending</span>" : '' ?>
        </a>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
