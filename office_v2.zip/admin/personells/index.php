<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/personnel.php';
require_once '../includes/helpers.php';

require_clearance(1, '../'); // Admin only

$employees = get_all_employees();

$page_title  = 'Personnel';
$assets_path = '../';
$nav_back    = '../';
include '../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:20px">
    <h2 class="wim-section-title" style="margin-bottom:0">Personnel</h2>
    <a href="add-new/" class="btn-primary" style="padding:9px 20px;border-radius:5px;font-weight:700">+ Add New</a>
</div>

<div class="wim-card">
    <?php if (empty($employees)): ?>
    <p style="text-align:center;padding:30px;color:#888">No personnel on record.</p>
    <?php else: ?>
    <?php foreach ($employees as $emp): ?>
    <div class="personnel-row">
        <div style="min-width:160px">
            <strong><?= htmlspecialchars($emp['personnel_name'] . ' ' . $emp['surname']) ?></strong>
        </div>
        <div style="font-size:13px;color:#555;flex:1">
            <?= htmlspecialchars($emp['occupation'] ?? 'N/A') ?> &mdash;
            <?= htmlspecialchars($emp['email_address'] ?? '') ?>
        </div>
        <div>
            <span class="clearance-badge <?= (int)$emp['security_clearance'] === 2 ? 'level-2' : '' ?>">
                Clearance <?= (int)$emp['security_clearance'] ?>
            </span>
        </div>
        <div class="contract-actions">
            <a href="update/?name=<?= urlencode($emp['personnel_name']) ?>&surname=<?= urlencode($emp['surname']) ?>"
               class="btn-edit">Edit</a>
            <a href="delete/?name=<?= urlencode($emp['personnel_name']) ?>&surname=<?= urlencode($emp['surname']) ?>"
               class="btn-danger"
               onclick="return confirm('Delete <?= htmlspecialchars($emp['personnel_name'] . ' ' . $emp['surname']) ?>?')">
               Delete
            </a>
        </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
