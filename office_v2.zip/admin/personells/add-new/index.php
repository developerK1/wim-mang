<?php
session_start();
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/personnel.php';
require_once '../../includes/helpers.php';

// Only clearance 1 (full admin) can add personnel
require_clearance([1], '../../', '../../logging-in/');

$msg = '';

if (isset($_POST['add-new'])) {
    $name       = post('name');
    $surname    = post('surname');
    $email      = post('email');
    $occupation = post('occupation');
    $expertise  = post('expertise');
    $clearance  = (int)($_POST['clearance'] ?? 1);
    $table      = ($_POST['table'] ?? 'employees') === 'wim_agents' ? 'wim_agents' : 'employees';

    // Validate clearance is one of the allowed levels
    if (!in_array($clearance, [0, 1, 2, 3], true)) {
        $clearance = 1;
    }

    if ($name === '' || $surname === '' || $email === '') {
        $msg = error_html('Name, surname and email are required.');
    } else {
        $result = add_personnel($table, $name, $surname, $email, $occupation, $expertise, $clearance);
        if ($result['success']) {
            flash('success', $result['message']);
            header('Location: ../');
            exit;
        } else {
            $msg = error_html($result['message']);
        }
    }
}

$page_title  = 'Add Personnel';
$assets_path = '../../';
$nav_back    = '../';
include '../../includes/header.php';
?>

<div class="wim-card" style="max-width:480px;margin:0 auto">
    <h2>Add New Personnel</h2>
    <?= $msg ?>
    <form method="POST" action="#" class="wim-form" style="max-width:100%">
        <div class="form-group">
            <label>First Name <span class="required-star">*</span></label>
            <input type="text" name="name" placeholder="First name"
                   value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
        </div>
        <div class="form-group">
            <label>Surname <span class="required-star">*</span></label>
            <input type="text" name="surname" placeholder="Surname"
                   value="<?= htmlspecialchars($_POST['surname'] ?? '') ?>" required>
        </div>
        <div class="form-group">
            <label>Email <span class="required-star">*</span></label>
            <input type="email" name="email" placeholder="Email address"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </div>
        <div class="form-group">
            <label>Occupation</label>
            <input type="text" name="occupation" placeholder="Job title"
                   value="<?= htmlspecialchars($_POST['occupation'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Expertise</label>
            <input type="text" name="expertise" placeholder="Area of expertise"
                   value="<?= htmlspecialchars($_POST['expertise'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Security Clearance</label>
            <select name="clearance">
                <option value="1" <?= (int)($_POST['clearance'] ?? 1) === 1 ? 'selected' : '' ?>>
                    1 — Full Admin (Office + Plant, scheduling)
                </option>
                <option value="2" <?= (int)($_POST['clearance'] ?? 0) === 2 ? 'selected' : '' ?>>
                    2 — Plant CRUD (add / update / delete, no scheduling)
                </option>
                <option value="3" <?= (int)($_POST['clearance'] ?? 0) === 3 ? 'selected' : '' ?>>
                    3 — Scheduled Stones Read-Only
                </option>
                <option value="0" <?= (int)($_POST['clearance'] ?? 1) === 0 ? 'selected' : '' ?>>
                    0 — No Access (blocked)
                </option>
            </select>
        </div>
        <div class="form-group">
            <label>Personnel Type</label>
            <select name="table">
                <option value="employees">Employee</option>
                <option value="wim_agents">Agent</option>
            </select>
        </div>
        <p style="font-size:13px;color:#888;margin-top:-8px">
            New user's temporary password will be <strong>changeme</strong> — they should update it after first login.
        </p>
        <button type="submit" name="add-new" class="btn-primary">Add Personnel</button>
    </form>
</div>

<?php include '../../includes/footer.php'; ?>
