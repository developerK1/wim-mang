<?php
session_start();
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/personnel.php';
require_once '../../includes/helpers.php';

require_clearance(1, '../../');

$name    = get_param('name');
$surname = get_param('surname');

if ($name === '' || $surname === '') {
    flash('error', 'Invalid request — no personnel specified.');
    header('Location: ../');
    exit;
}

// Confirm before delete
if (isset($_POST['confirm-delete'])) {
    $ok = delete_employee($name, $surname);
    if ($ok) {
        flash('success', "$name $surname has been removed.");
    } else {
        flash('error', "Could not delete $name $surname. Please try again.");
    }
    header('Location: ../');
    exit;
}

if (isset($_POST['cancel'])) {
    header('Location: ../');
    exit;
}

$person = get_employee_by_name($name, $surname);

$page_title  = 'Delete Personnel';
$assets_path = '../../';
$nav_back    = '../';
include '../../includes/header.php';
?>

<div class="wim-card" style="max-width:420px;margin:0 auto;text-align:center">
    <?php if (!$person): ?>
        <h3 style="color:#dc3545">Personnel not found</h3>
        <a href="../" class="btn-primary" style="padding:8px 20px;border-radius:5px">Back</a>
    <?php else: ?>
        <h2 style="color:#dc3545">Confirm Delete</h2>
        <p style="font-size:16px">
            Are you sure you want to permanently delete<br>
            <strong><?= htmlspecialchars($person['personnel_name'] . ' ' . $person['surname']) ?></strong>?
        </p>
        <p style="font-size:13px;color:#888">This action cannot be undone.</p>
        <div style="display:flex;gap:12px;justify-content:center;margin-top:20px">
            <form method="POST">
                <button type="submit" name="confirm-delete" class="btn-danger"
                        style="padding:10px 24px;font-size:15px">
                    Yes, Delete
                </button>
            </form>
            <form method="POST">
                <button type="submit" name="cancel" class="btn-secondary"
                        style="padding:10px 24px;font-size:15px">
                    Cancel
                </button>
            </form>
        </div>
    <?php endif; ?>
</div>

<?php include '../../includes/footer.php'; ?>
