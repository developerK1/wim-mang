<?php
session_start();
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/personnel.php';
require_once '../../includes/helpers.php';

// Only clearance 1 can edit personnel
require_clearance([1], '../../', '../../logging-in/');

$name    = get_param('name');
$surname = get_param('surname');
$person  = ($name && $surname) ? get_employee_by_name($name, $surname) : null;
$msg     = '';

if ($person && isset($_POST['update-personel'])) {
    $new_name       = post('name');
    $new_surname    = post('surname');
    $email          = post('email');
    $occupation     = post('occupation');
    $expertise      = post('expertise');
    $clearance      = (int)post('clearance');
    $plain_password = $_POST['password'] ?? '';

    // Validate clearance range
    if (!in_array($clearance, [0, 1, 2, 3], true)) {
        $clearance = 1;
    }

    $result = update_employee(
        $new_name, $new_surname, $email,
        $occupation, $expertise, $clearance, $plain_password
    );

    if ($result['success']) {
        flash('success', $result['message']);
        header('Location: ../');
        exit;
    } else {
        $msg = error_html($result['message']);
    }
}

$page_title  = 'Edit Personnel';
$assets_path = '../../';
$nav_back    = '../';
include '../../includes/header.php';
?>

<?php if (!$person): ?>
<div class="wim-card" style="text-align:center;padding:40px">
    <h3 style="color:#dc3545">Personnel not found</h3>
    <a href="../" class="btn-primary" style="padding:8px 20px;border-radius:5px">Back to Personnel</a>
</div>
<?php else: ?>

<div class="wim-card" style="max-width:500px;margin:0 auto">
    <h2>Edit — <?= htmlspecialchars($person['personnel_name'] . ' ' . $person['surname']) ?></h2>
    <?= $msg ?>

    <form method="POST" action="#" class="wim-form" style="max-width:100%">
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="name"
                   value="<?= htmlspecialchars($person['personnel_name']) ?>" required>
        </div>
        <div class="form-group">
            <label>Surname</label>
            <input type="text" name="surname"
                   value="<?= htmlspecialchars($person['surname']) ?>" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email"
                   value="<?= htmlspecialchars($person['email_address'] ?? '') ?>" required>
        </div>
        <div class="form-group">
            <label>Occupation</label>
            <input type="text" name="occupation"
                   value="<?= htmlspecialchars($person['occupation'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Expertise</label>
            <input type="text" name="expertise"
                   value="<?= htmlspecialchars($person['expertise'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Security Clearance</label>
            <select name="clearance">
                <?php
                $current = (int)($person['security_clearance'] ?? 1);
                $levels = [
                    1 => '1 — Full Admin (Office + Plant, scheduling)',
                    2 => '2 — Plant CRUD (add / update / delete, no scheduling)',
                    3 => '3 — Scheduled Stones Read-Only',
                    0 => '0 — No Access (blocked)',
                ];
                foreach ($levels as $val => $label):
                ?>
                <option value="<?= $val ?>" <?= $current === $val ? 'selected' : '' ?>>
                    <?= $label ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>New Password <span style="font-weight:400;font-size:13px;color:#888">(leave blank to keep current)</span></label>
            <input type="password" name="password" placeholder="New password (optional)">
        </div>
        <button type="submit" name="update-personel" class="btn-primary">Save Changes</button>
    </form>
</div>

<?php endif; ?>
<?php include '../../includes/footer.php'; ?>
