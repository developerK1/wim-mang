# Wim Admin Panel — Rewrite

## Folder structure

```
admin/
├── index.php                   ← Dashboard (home)
├── logging-in/
│   └── index.php               ← Login page
├── new-contract/
│   └── index.php               ← New contract form (with conflict detection)
├── conflicts/
│   └── index.php               ← Conflict contracts review (admin only)
├── search/
│   └── index.php               ← Search contracts
├── details/
│   └── index.php               ← Contract detail view  (?id=CONTRACT_ID)
├── update-status/
│   └── index.php               ← Update contract status
├── update-installation/
│   └── index.php               ← Update installation/unveiling dates
├── installations/
│   └── index.php               ← Scheduling page — month view (clearance 1 only)
├── approved/
│   └── index.php               ← Approved contracts list
├── personells/
│   ├── index.php               ← Personnel list (clearance 1 only)
│   ├── add-new/index.php       ← Add employee or agent
│   ├── update/index.php        ← Edit personnel details
│   └── delete/index.php        ← Delete confirmation
├── assets/
│   └── wim.css                 ← Single shared stylesheet (all pages)
└── includes/
    ├── db.php                  ← PDO connection — one instance, shared everywhere
    ├── auth.php                ← Login, session, clearance guards
    ├── contracts.php           ← All contract SQL (prepared statements)
    ├── personnel.php           ← Employee / agent SQL
    ├── helpers.php             ← Sanitization, flash messages, date utilities
    ├── header.php              ← Shared page header / nav partial
    └── footer.php              ← Shared page footer partial
```

---

## Security clearance levels

| Level | Access |
|-------|--------|
| **1** | Full admin — all pages in both Office and Plant |
| **2** | Plant app only — read, write, delete; **no** scheduling page |

Both levels share the **same login page and session variables**. Access is enforced
per-page using `require_clearance(1)` for admin-only pages.

---

## Deployment steps

### 1. Run the SQL migration

```bash
mysql -u bxxhwhbm_test -p bxxhwhbm_wimcorp < database_changes.sql
```

This creates the `conflict_contracts` table and ensures the
`security_clearance` column is correctly typed.

### 2. Set credentials via environment variables

Add to your `.htaccess` (preferred over editing db.php):

```apache
SetEnv DB_HOST localhost
SetEnv DB_NAME bxxhwhbm_wimcorp
SetEnv DB_USER bxxhwhbm_test
SetEnv DB_PASS your_real_password_here
```

Or set them in cPanel → PHP Environment Variables.

### 3. Drop the old `office/admin/` folder, upload this one

Keep the `assets/` folder — copy over `logo.png` and `favicon.ico`.

### 4. First login after deployment

Each user's password will be automatically upgraded from MD5 to bcrypt
the first time they log in. No manual intervention needed.

New users created via the Personnel page get the temporary password **`changeme`**.

---

## Plant app shared auth

The Plant app points to the same `db.php` and `auth.php` — just `require_once`
the path to `admin/includes/auth.php` at the top of each Plant page, then call:

```php
require_auth('/office/admin/logging-in/');
require_clearance(2, '/');   // allow both clearance 1 and 2
```

For the Plant scheduling page (clearance 1 only):
```php
require_clearance(1, '/plant/home/');
```

Session variable reference:
```php
$_SESSION['user_id']            // int
$_SESSION['username']           // "Firstname Surname"
$_SESSION['email']              // email address
$_SESSION['security_clearance'] // 1 or 2
$_SESSION['app_session']        // 'active'
```

---

## Conflict contracts flow

1. Sales rep enters a contract on `new-contract/`
2. If the contract ID already exists → entry is saved to `conflict_contracts`
   with a yellow warning and a link to the conflicts page
3. Admin visits `conflicts/` to see a **side-by-side comparison** of the
   original and the duplicate
4. Admin can:
   - **Promote** — save the conflict as a new contract with a corrected ID
   - **Resolve** — add a note and mark as handled (no new contract created)
   - **Discard** — permanently delete the conflict entry

---

## Bugs fixed from original codebase

| File | Bug | Fix |
|------|-----|-----|
| `main_functions.php` | `updateContract()` if/else inverted — never executed SQL | Fixed logic |
| `functions.php` | `deleteContract()` missing `mysqli_query()` call | Added PDO execute |
| `functions.php` | `deleteAgent()` checked `$results == 0` but mysqli_query returns bool | Fixed check |
| `functions.php` | `fetchAll()` had unreachable `return $results` | Removed dead code |
| `functions.php` | `getInstalldate()` was a debug echo stub | Removed |
| `plant/functions.php` | `updateContract()` used `$tone_code` (missing 's') | Fixed typo |
| `new-contract/index.php` | Conflict contract showed message but never saved anywhere | Now saves to `conflict_contracts` |
| All pages | SQL injection via string interpolation | All queries use PDO prepared statements |
| `logging-in/` | Passwords stored/compared as plain MD5 | bcrypt with transparent migration |
| `validate.php` | Admin check via hardcoded email addresses | Replaced with `security_clearance` column |
| `constr.php` | Credentials hardcoded in source | Moved to environment variables |
| All pages | `session_start()` called after output in some files | Moved to top of every controller |
| All pages | `header()` without `exit` — code kept running | Added `exit` after every redirect |
