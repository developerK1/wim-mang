-- ============================================================
-- WIM Corporation — Database changes
-- Run these against bxxhwhbm_wimcorp
-- ============================================================


-- ── 1. conflict_contracts table ──────────────────────────────
-- Stores duplicate contract entries for manual review.
-- Created when a new-contract submission uses an ID that
-- already exists in the contracts table.

CREATE TABLE IF NOT EXISTS `conflict_contracts` (
    `id`                   INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `original_contract_id` VARCHAR(50)     NOT NULL COMMENT 'The duplicate ID that was attempted',

    -- Client
    `buyer`                VARCHAR(100)    NOT NULL DEFAULT '',
    `surname`              VARCHAR(100)    NOT NULL DEFAULT '',
    `other_name`           VARCHAR(100)             DEFAULT 'TF',
    `contacts`             VARCHAR(50)              DEFAULT '',
    `other_number`         VARCHAR(50)              DEFAULT 'TF',
    `proxy`                VARCHAR(100)             DEFAULT 'None',

    -- Stone
    `stone_name`           VARCHAR(100)             DEFAULT '',
    `slab_type`            VARCHAR(50)              DEFAULT '',
    `head_type`            VARCHAR(100)             DEFAULT 'TF',
    `stones_cost`          VARCHAR(20)              DEFAULT '',
    `stones_details`       TEXT                     DEFAULT NULL,

    -- Contract info
    `contract_type`        VARCHAR(30)              DEFAULT '',
    `contract_sign_date`   DATE                     DEFAULT NULL,
    `installation_date`    VARCHAR(20)              DEFAULT 'TF',
    `unveiling_date`       VARCHAR(20)              DEFAULT 'TF',

    -- Location
    `grave_yard`           VARCHAR(150)             DEFAULT '',
    `town`                 VARCHAR(80)              DEFAULT '',

    -- Deceased
    `dec_name`             VARCHAR(100)             DEFAULT '',
    `dSurname`             VARCHAR(100)             DEFAULT '',
    `dotherName`           VARCHAR(100)             DEFAULT 'TF',

    -- Misc
    `sales_rep`            VARCHAR(80)              DEFAULT '',
    `funeral`              TINYINT(1)               DEFAULT 0,

    -- Conflict tracking
    `flagged_by`           VARCHAR(150)    NOT NULL DEFAULT '' COMMENT 'Username who submitted the duplicate',
    `flagged_at`           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `resolved`             TINYINT(1)      NOT NULL DEFAULT 0,
    `resolution_note`      TEXT                     DEFAULT NULL,
    `resolved_at`          DATETIME                 DEFAULT NULL,

    PRIMARY KEY (`id`),
    KEY `idx_original_id` (`original_contract_id`),
    KEY `idx_resolved`    (`resolved`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Duplicate contract submissions awaiting manual review';


-- ── 2. Ensure security_clearance column exists on employees ──
-- If the column already exists this is a safe no-op (MySQL 8+).
-- For older MySQL, check manually: SHOW COLUMNS FROM employees;

ALTER TABLE `employees`
    MODIFY COLUMN `security_clearance` TINYINT(1) NOT NULL DEFAULT 1
    COMMENT '1 = full admin (office+plant), 2 = plant only (no scheduling)';


-- ── 3. Update any legacy clearance values ────────────────────
-- Old code stored 0 for "no access". Map those to clearance 2
-- (plant-only limited) or remove those users.
-- Uncomment and adjust as needed:
-- UPDATE employees SET security_clearance = 2 WHERE security_clearance = 0;


-- ── 4. Upgrade passwords from MD5 to bcrypt ──────────────────
-- PHP's attempt_login() in auth.php will auto-upgrade each user's
-- hash to bcrypt the first time they log in with a correct password.
-- No manual SQL is needed — migration is transparent and gradual.
-- After 30 days, any remaining md5 hashes are accounts that haven't
-- logged in; you can force-reset them via the personnel update page.


-- ── 5. Verify structure ──────────────────────────────────────
-- Run these to confirm after applying:
-- DESCRIBE conflict_contracts;
-- SELECT id, personell_name, surname, security_clearance FROM employees;


-- ── 6. New columns on tombstones_installations (plant table) ──────────────────
-- These columns allow the office to track confirmation without the plant app
-- losing its own confirm_installation flag.

ALTER TABLE `tombstones_installations`
    ADD COLUMN IF NOT EXISTS `office_confirmed`    TINYINT(1)   DEFAULT 0
        COMMENT '1 = office admin has permanently confirmed this installation',
    ADD COLUMN IF NOT EXISTS `office_confirmed_by` VARCHAR(150) DEFAULT NULL
        COMMENT 'Username of office admin who confirmed',
    ADD COLUMN IF NOT EXISTS `office_confirmed_at` DATETIME     DEFAULT NULL
        COMMENT 'When office confirmed',
    ADD COLUMN IF NOT EXISTS `rejection_note`      TEXT         DEFAULT NULL
        COMMENT 'Reason sent back to plant team when rejected',
    ADD COLUMN IF NOT EXISTS `rejected_by`         VARCHAR(150) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `rejected_at`         DATETIME     DEFAULT NULL;

-- Index to make the review page query fast
ALTER TABLE `tombstones_installations`
    ADD INDEX IF NOT EXISTS `idx_confirm_office` (`confirm_installation`, `office_confirmed`);

-- ── 7. Verify ─────────────────────────────────────────────────────────────────
-- DESCRIBE tombstones_installations;