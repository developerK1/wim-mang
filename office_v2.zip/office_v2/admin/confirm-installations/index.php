<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/contracts.php';
require_once '../includes/helpers.php';

// Clearance 1 only — only full admin can permanently confirm installations
require_clearance(1, '../');

// ── Handle: Confirm installation ──────────────────────────────────────────────
if (isset($_POST['confirm-install'])) {
    $contract_id  = post('contract_id');
    $plant_extras = post('plant_extras');

    if ($contract_id === '') {
        flash('error', 'Missing contract ID.');
    } else {
        $ok = confirm_plant_installation($contract_id, $plant_extras, current_user());
        $ok
            ? flash('success', "Contract #{$contract_id} confirmed as Installed. Extras updated.")
            : flash('error', "Could not confirm Contract #{$contract_id}. Please try again.");
    }
    header('Location: index.php');
    exit;
}

// ── Handle: Reject / send back ────────────────────────────────────────────────
if (isset($_POST['reject-install'])) {
    $contract_id    = post('contract_id');
    $rejection_note = post('rejection_note');

    if ($contract_id === '') {
        flash('error', 'Missing contract ID.');
    } else {
        $ok = reject_plant_confirmation($contract_id, $rejection_note, current_user());
        $ok
            ? flash('success', "Contract #{$contract_id} sent back to plant team.")
            : flash('error', "Could not reject Contract #{$contract_id}. Please try again.");
    }
    header('Location: index.php');
    exit;
}

// ── Fetch all pending plant confirmations ─────────────────────────────────────
$pending = get_pending_plant_confirmations();

// For each plant record, try to find the matching office contract
// Split into: found (Scenario A) and not found (Scenario B)
$found     = [];
$not_found = [];

foreach ($pending as $plant) {
    $contract = get_contract_by_id($plant['id']);
    if ($contract) {
        $found[]     = ['plant' => $plant, 'contract' => $contract];
    } else {
        $not_found[] = ['plant' => $plant];
    }
}

$page_title  = 'Confirm Installations';
$assets_path = '../';
$nav_back    = '../';
include '../includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:20px">
    <h2 class="wim-section-title" style="margin-bottom:0">
        Confirm Installations
        <?php $total = count($pending); if ($total > 0): ?>
        <span class="conflict-badge" style="font-size:16px;vertical-align:middle">
            <?= $total ?> pending
        </span>
        <?php endif; ?>
    </h2>
</div>

<!-- Explainer -->
<div class="wim-card" style="padding:14px 22px;margin-bottom:24px">
    <p style="margin:0;color:#555;font-size:14px">
        These contracts have been marked <strong>done</strong> by the plant team and are
        awaiting permanent confirmation. Only <strong>Clearance 1</strong> can confirm.
        Confirming will set <code>contract_status = Installed</code> and update the extras
        on the office contract. Rejecting sends it back to the plant team.
    </p>
</div>

<?php if (empty($pending)): ?>
<!-- Nothing pending -->
<div class="wim-card" style="text-align:center;padding:50px;color:#888">
    <p style="font-size:18px">✓ No installations awaiting confirmation.</p>
    <p style="font-size:14px">The plant team hasn't flagged any completed stones yet.</p>
</div>

<?php else: ?>

<!-- ══════════════════════════════════════════════════════════════════
     SCENARIO B — Contract NOT in office DB  (shown first — urgent)
     ══════════════════════════════════════════════════════════════════ -->
<?php if (!empty($not_found)): ?>
<h3 style="color:#dc3545;font-size:18px;margin-bottom:12px">
    ⚠ Contract Not Found in Office Database (<?= count($not_found) ?>)
</h3>
<p style="color:#666;font-size:14px;margin-bottom:16px">
    These stones were marked done by the plant team but have <strong>no matching contract</strong>
    in the office database. The contract must be added before the installation can be confirmed.
</p>

<?php foreach ($not_found as $row): ?>
<?php $p = $row['plant']; ?>
<div class="wim-card" style="border-left:5px solid #dc3545;margin-bottom:18px">

    <!-- Header row -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:16px">
        <div>
            <span style="background:#dc3545;color:#fff;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:700">
                NOT IN OFFICE DB
            </span>
            <strong style="font-size:18px;margin-left:10px;color:#dc3545">
                Contract #<?= htmlspecialchars($p['id']) ?>
            </strong>
        </div>
        <div style="font-size:13px;color:#888">
            Flagged by plant: <strong><?= htmlspecialchars($p['logged_by'] ?? 'Unknown') ?></strong>
            on <?= htmlspecialchars($p['logged_at'] ?? 'N/A') ?>
        </div>
    </div>

    <!-- Plant data summary -->
    <div style="background:#fff8f8;border:1px solid #f5c6cb;border-radius:7px;padding:14px;margin-bottom:16px">
        <h4 style="color:#dc3545;font-size:15px;margin-top:0">Data from Plant App</h4>
        <table class="detail-table" style="font-size:13px">
            <tr><th>Contract ID</th><td><strong><?= htmlspecialchars($p['id']) ?></strong></td></tr>
            <tr><th>Stone Name</th><td><?= htmlspecialchars($p['stone_name'] ?? 'N/A') ?></td></tr>
            <tr><th>Deceased</th><td><?= htmlspecialchars($p['deseased_name'] ?? 'N/A') ?></td></tr>
            <tr><th>Contact Name</th><td><?= htmlspecialchars($p['contact_name'] ?? 'N/A') ?></td></tr>
            <tr><th>Contact No 1</th><td><?= htmlspecialchars($p['contact_no1'] ?? 'N/A') ?></td></tr>
            <tr><th>Contact No 2</th><td><?= htmlspecialchars($p['contact_no2'] ?? 'TF') ?></td></tr>
            <tr><th>Shop</th><td><?= htmlspecialchars($p['shop'] ?? 'N/A') ?></td></tr>
            <tr><th>Grave Yard</th><td><?= htmlspecialchars($p['gy'] ?? 'N/A') ?></td></tr>
            <tr><th>Funeral</th><td><?= htmlspecialchars($p['funeral'] ?? 'No') ?></td></tr>
            <tr><th>Unveiling</th><td><?= htmlspecialchars($p['unveiling'] ?? 'N/A') ?></td></tr>
            <tr><th>Extras / Notes</th><td><?= htmlspecialchars($p['extras'] ?? 'None') ?></td></tr>
            <tr><th>Plant Status</th><td><?= htmlspecialchars($p['status'] ?? 'N/A') ?></td></tr>
        </table>
    </div>

    <!-- Action: go to new-contract pre-filled -->
    <?php
    // Build query string to pre-fill the new-contract form with plant data
    $prefill = http_build_query([
        'prefill'        => 1,
        'contract_id'    => $p['id'],
        'stone_name'     => $p['stone_name']    ?? '',
        'dec_name'       => $p['deseased_name'] ?? '',
        'contacts'       => $p['contact_no1']   ?? '',
        'other_number'   => $p['contact_no2']   ?? '',
        'grave_yard'     => $p['gy']            ?? '',
        'stones_details' => $p['extras']        ?? '',
        'funeral'        => $p['funeral']       ?? '',
    ]);
    ?>
    <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <a href="../new-contract/?<?= $prefill ?>"
           class="btn-primary"
           style="padding:9px 20px;border-radius:6px;font-weight:700;font-size:14px">
            + Add Contract Now
        </a>
        <span style="font-size:13px;color:#888">
            Fill in the contract details, then return here to confirm the installation.
        </span>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>


<!-- ══════════════════════════════════════════════════════════════════
     SCENARIO A — Contract found in office DB  (ready to confirm)
     ══════════════════════════════════════════════════════════════════ -->
<?php if (!empty($found)): ?>
<h3 style="color:#FF7F00;font-size:18px;margin:28px 0 12px">
    Ready to Confirm (<?= count($found) ?>)
</h3>

<?php foreach ($found as $row): ?>
<?php $p = $row['plant']; $c = $row['contract']; ?>
<div class="wim-card" style="border-left:5px solid #FF7F00;margin-bottom:22px">

    <!-- Header -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:18px">
        <div>
            <span style="background:#FF7F00;color:#fff;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:700">
                PENDING CONFIRMATION
            </span>
            <strong style="font-size:18px;margin-left:10px">
                Contract #<?= htmlspecialchars($c['contract_id']) ?>
            </strong>
        </div>
        <div style="font-size:13px;color:#888">
            Flagged by plant: <strong><?= htmlspecialchars($p['logged_by'] ?? 'Unknown') ?></strong>
            on <?= htmlspecialchars($p['logged_at'] ?? 'N/A') ?>
        </div>
    </div>

    <!-- Side-by-side: Office contract vs Plant data -->
    <div class="compare-grid" style="margin-bottom:18px">

        <!-- Office side -->
        <div class="wim-card" style="border-top:3px solid #343a40;margin-bottom:0">
            <h4 style="color:#343a40;font-size:15px;margin-top:0">Office Contract</h4>
            <table class="detail-table" style="font-size:13px">
                <tr><th>Buyer</th><td><?= htmlspecialchars(ucfirst($c['buyer']) . ' ' . ucfirst($c['surname'])) ?></td></tr>
                <tr><th>Contact</th><td><?= htmlspecialchars($c['contacts']) ?></td></tr>
                <tr><th>Stone</th><td><?= htmlspecialchars($c['stone_name']) ?></td></tr>
                <tr><th>Slab</th><td><?= htmlspecialchars($c['slab_type']) ?></td></tr>
                <tr><th>Current Status</th>
                    <td><strong style="color:#FF7F00"><?= htmlspecialchars($c['contract_status']) ?></strong></td>
                </tr>
                <tr><th>Scheduled Install</th><td><?= display_date($c['installation_date']) ?></td></tr>
                <tr><th>Grave Yard</th><td><?= htmlspecialchars($c['grave_yard']) ?>, <?= htmlspecialchars($c['town']) ?></td></tr>
                <tr><th>Sales Rep</th><td><?= htmlspecialchars($c['sales_rep']) ?></td></tr>
                <tr>
                    <th>Current Extras</th>
                    <td style="color:#888"><?= htmlspecialchars(or_else($c['stones_details'], 'None')) ?></td>
                </tr>
            </table>
            <a href="../details/?id=<?= urlencode($c['contract_id']) ?>"
               class="btn-view"
               style="display:inline-block;margin-top:10px;padding:5px 14px;border-radius:5px;font-size:13px">
                View Full Contract →
            </a>
        </div>

        <!-- Plant side -->
        <div class="wim-card" style="border-top:3px solid #28a745;margin-bottom:0">
            <h4 style="color:#28a745;font-size:15px;margin-top:0">Plant App — Done</h4>
            <table class="detail-table" style="font-size:13px">
                <tr><th>Stone Name</th><td><?= htmlspecialchars($p['stone_name'] ?? 'N/A') ?></td></tr>
                <tr><th>Deceased</th><td><?= htmlspecialchars($p['deseased_name'] ?? 'N/A') ?></td></tr>
                <tr><th>Contact</th><td><?= htmlspecialchars($p['contact_no1'] ?? 'N/A') ?></td></tr>
                <tr><th>Shop</th><td><?= htmlspecialchars($p['shop'] ?? 'N/A') ?></td></tr>
                <tr><th>Grave Yard</th><td><?= htmlspecialchars($p['gy'] ?? 'N/A') ?></td></tr>
                <tr><th>Plant Status</th>
                    <td><strong style="color:#28a745"><?= htmlspecialchars($p['status'] ?? 'N/A') ?></strong></td>
                </tr>
                <tr>
                    <th>New Extras</th>
                    <td>
                        <strong style="color:#28a745">
                            <?= htmlspecialchars(or_else($p['extras'] ?? '', 'None')) ?>
                        </strong>
                        <?php if (!empty($p['extras']) && $p['extras'] !== ($c['stones_details'] ?? '')): ?>
                        <br><small style="color:#856404">⚠ Differs from office record — will be updated on confirm</small>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Action forms -->
    <div style="display:flex;gap:14px;flex-wrap:wrap;padding-top:16px;border-top:1px solid #eee;align-items:flex-end">

        <!-- CONFIRM -->
        <form method="POST" action="index.php"
              onsubmit="return confirm('Permanently mark Contract #<?= htmlspecialchars($c['contract_id']) ?> as Installed?')">
            <input type="hidden" name="contract_id"  value="<?= htmlspecialchars($c['contract_id']) ?>">
            <input type="hidden" name="plant_extras"  value="<?= htmlspecialchars($p['extras'] ?? '') ?>">
            <div style="margin-bottom:8px">
                <label style="font-size:13px;font-weight:700;color:#333;display:block;margin-bottom:4px">
                    Extras to save on contract:
                </label>
                <textarea name="plant_extras"
                          style="width:280px;padding:7px 10px;border:1px solid #ccc;border-radius:5px;font-size:13px;min-height:60px"
                          ><?= htmlspecialchars($p['extras'] ?? '') ?></textarea>
            </div>
            <button type="submit" name="confirm-install"
                    class="btn-primary"
                    style="padding:9px 20px;font-size:14px;border-radius:6px">
                ✓ Confirm Installation
            </button>
        </form>

        <!-- REJECT -->
        <form method="POST" action="index.php">
            <input type="hidden" name="contract_id" value="<?= htmlspecialchars($c['contract_id']) ?>">
            <div style="margin-bottom:8px">
                <label style="font-size:13px;font-weight:700;color:#333;display:block;margin-bottom:4px">
                    Rejection reason (sent to plant team):
                </label>
                <input type="text" name="rejection_note"
                       placeholder="e.g. Stone not fully installed yet..."
                       style="width:280px;padding:7px 10px;border:1px solid #ccc;border-radius:5px;font-size:13px">
            </div>
            <button type="submit" name="reject-install"
                    class="btn-danger"
                    style="padding:9px 20px;font-size:14px;border-radius:6px">
                ✗ Send Back to Plant
            </button>
        </form>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php endif; // end if pending not empty ?>

<?php include '../includes/footer.php'; ?>
