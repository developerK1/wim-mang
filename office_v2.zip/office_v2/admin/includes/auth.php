<?php
/**
 * Authentication & session helpers.
 *
 * Security clearance levels:
 *   1 = Full admin — access to OFFICE + PLANT (all pages including scheduling)
 *   2 = Plant worker — access to PLANT only (read/write/delete, NO scheduling page)
 *
 * employees table columns (updated schema):
 *   id, email_address, personnel_name, surname, security_clearance, pass, recovery,
 *   occupation, expertise, session_status, session_id
 *
 * Session variables set on login:
 *   $_SESSION['user_id']            — employee primary key (id)
 *   $_SESSION['username']           — personnel_name + surname display name
 *   $_SESSION['email']              — email_address
 *   $_SESSION['security_clearance'] — 1 or 2
 *   $_SESSION['app_session']        — 'active'
 */

require_once __DIR__ . '/db.php';

// ─── Login ────────────────────────────────────────────────────────────────────

/**
 * Attempt login by email + password.
 * Returns employee row on success, null on failure.
 */
function attempt_login(string $email, string $password, string $username = ''): ?array {
    $stmt = get_db()->prepare(
        'SELECT * FROM employees WHERE email_address = ? LIMIT 1'
    );
    $stmt->execute([trim($email)]);
    $user = $stmt->fetch();

    if (!$user) return null;

    // Support both new bcrypt hashes and old md5 hashes during migration
    if (strpos($user['pass'], '$2y$') === 0) {
        // Modern bcrypt
        if (!password_verify($password, $user['pass'])) return null;
    } else {
        // Legacy md5 — verify then upgrade to bcrypt on the spot
        if (md5($password) !== $user['pass']) return null;
        upgrade_password_hash((int)$user['id'], $password);
    }

    return $user;
}

/**
 * Upgrade a legacy md5 hash to bcrypt in the database.
 */
function upgrade_password_hash(int $user_id, string $plain_password): void {
    $hash = password_hash($plain_password, PASSWORD_BCRYPT);
    $stmt = get_db()->prepare('UPDATE employees SET pass = ? WHERE id = ?');
    $stmt->execute([$hash, $user_id]);
}

/**
 * Write session variables after a successful login.
 * Uses updated column names: personnel_name, email_address.
 */
function create_session(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id']            = (int)$user['id'];
    $_SESSION['username']           = trim($user['personnel_name'] . ' ' . $user['surname']);
    $_SESSION['email']              = $user['email_address'] ?? '';
    $_SESSION['security_clearance'] = (int)$user['security_clearance'];
    $_SESSION['app_session']        = 'active';
}

/**
 * Destroy the session on logout.
 */
function destroy_session(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

// ─── Guards ───────────────────────────────────────────────────────────────────

/**
 * Redirect to login if no active session.
 */
function require_auth(string $login_path = '../logging-in/'): void {
    if (empty($_SESSION['app_session']) || $_SESSION['app_session'] !== 'active') {
        header('Location: ' . $login_path);
        exit;
    }
}

/**
 * Require a minimum clearance level.
 * clearance 1 = full admin; clearance 2 = plant-only limited access.
 */
function require_clearance(int $min_clearance, string $redirect = '../'): void {
    require_auth();
    if ((int)($_SESSION['security_clearance'] ?? 0) > $min_clearance) {
        header('Location: ' . $redirect);
        exit;
    }
}

/**
 * Returns true if the logged-in user has full admin (clearance 1).
 */
function is_admin(): bool {
    return (int)($_SESSION['security_clearance'] ?? 0) === 1;
}

/**
 * Returns the logged-in user's display name, safely escaped.
 */
function current_user(): string {
    return htmlspecialchars($_SESSION['username'] ?? 'Unknown');
}
