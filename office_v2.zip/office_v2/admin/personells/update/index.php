<?php
session_start();
require_once '../../includes/db.php';
require_once '../../includes/auth.php';
require_once '../../includes/personnel.php';
require_once '../../includes/helpers.php';

require_clearance(1, '../../');

$name    = get_param('name');
$surname = get_param('surname');
$person  = ($name && $surname) ? get_employee_by_name($name, $surname) : null;
$msg     = '';

if ($person && isset($_POST['update-personel'])) {
    $new_name       = post('name');
    $new_surname    = post('surname');
    $email          = post('email');
    $occupation     = post('occupation');
    $expertise      = post('expertise');
    $clearance_raw  = post('security');
    $plain_password = $_POST['password'] ?? '';

    // Map dropdown label to integer
    $clearance = $clearance_raw === 'No Access' ? 0
               : ($clearance_raw === '2' || $clearance_raw === 'Plant Access' ? 2 : 1);

    $result = update_employee(
        $new_name, $new_surname, $email,
        $occupation, $expertise, $clearance, $plain_password
    );

    if ($result['success']) {
        flash('success', $result['message']);
        header('Location: ../');
        exit;
    } else {
        $msg = error_html($result['message']);
    }
}

$page_title  = 'Edit Personnel';
$assets_path = '../../';
$nav_back    = '../';
include '../../includes/header.php';
?>

<?php if (!$person): ?>
<div class="wim-card" style="text-align:center;padding:40px">
    <h3 style="color:#dc3545">Personnel not found</h3>
    <a href="../" class="btn-primary" style="padding:8px 20px;border-radius:5px">Back to Personnel</a>
</div>
<?php else: ?>

<div class="wim-card" style="max-width:500px;margin:0 auto">
    <h2>Edit — <?= htmlspecialchars($person['personnel_name'] . ' ' . $person['surname']) ?></h2>
    <?= $msg ?>

    <form method="POST" action="#" class="wim-form" style="max-width:100%">
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="name"
                   value="<?= htmlspecialchars($person['personnel_name']) ?>" required>
        </div>
        <div class="form-group">
            <label>Surname</label>
            <input type="text" name="surname"
                   value="<?= htmlspecialchars($person['surname']) ?>" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email"
                   value="<?= htmlspecialchars($person['email_address'] ?? '') ?>" required>
        </div>
        <div class="form-group">
            <label>Occupation</label>
            <input type="text" name="occupation"
                   value="<?= htmlspecialchars($person['occupation'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Expertise</label>
            <input type="text" name="expertise"
                   value="<?= htmlspecialchars($person['expertise'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Security Clearance</label>
            <select name="security">
                <option value="1" <?= (int)($person['security_clearance'] ?? 1) === 1 ? 'selected' : '' ?>>
                    1 — Full Admin (Office + Plant)
                </option>
                <option value="2" <?= (int)($person['security_clearance'] ?? 0) === 2 ? 'selected' : '' ?>>
                    2 — Plant Only (no scheduling)
                </option>
                <option value="No Access" <?= (int)($person['security_clearance'] ?? 1) === 0 ? 'selected' : '' ?>>
                    No Access
                </option>
            </select>
        </div>
        <div class="form-group">
            <label>New Password <span style="font-weight:400;font-size:13px;color:#888">(leave blank to keep current)</span></label>
            <input type="password" name="password" placeholder="New password (optional)">
        </div>
        <button type="submit" name="update-personel" class="btn-primary">Save Changes</button>
    </form>
</div>

<?php endif; ?>
<?php include '../../includes/footer.php'; ?>
