<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Already logged in — go to home
if (!empty($_SESSION['app_session']) && $_SESSION['app_session'] === 'active') {
    header('Location: ../home');
    exit;
}

$error      = false;
$user_error = '';
$pass_error = '';
$email_error = '';

if (isset($_POST['log-in'])) {
    $username = trim($_POST['name']     ?? '');
    $password =       $_POST['password'] ?? '';
    $email    = trim($_POST['email']    ?? '');

    if ($email    === '') $email_error = 'Please provide your email.';
    if ($username === '') $user_error  = 'Please provide your name.';
    if ($password === '') $pass_error  = 'Password cannot be empty.';

    if ($email !== '' && $password !== '' && $username !== '') {
        $user = attempt_login($email, $password, $username);

        if ($user) {
            create_session($user);
            header('Location: ../home');
            exit;
        } else {
            $error = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wim Admin — Log In</title>
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="../assets/wim.css">
</head>
<body>

<?php if ($error): ?>
<div class="login-failed-overlay" id="failedOverlay">
    <div class="login-failed-box">
        <button class="close-btn" onclick="document.getElementById('failedOverlay').style.display='none'">X</button>
        <h3>ACCESS FAILED</h3>
        <p>Incorrect email or password.</p>
        <a href="https://wimcorporation.co.za"><button class="btn-primary" style="margin-top:10px">GO HOME</button></a>
    </div>
</div>
<?php endif; ?>

<div class="login-wrap">
    <div class="login-box">
        <h2>LOG IN</h2>

        <label for="nameInput">Full Name</label>
        <input  type="text" id="nameInput" name="name" form="login-form"
               placeholder="Enter your name..." required
               value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
        <?php if ($user_error): ?>
            <p style="color:red;font-size:13px;margin-top:-10px"><?= htmlspecialchars($user_error) ?></p>
        <?php endif; ?>

        <label for="emailInput">Email</label>
        <input type="email" id="emailInput" name="email" form="login-form"
               placeholder="Your email address" required
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        <?php if ($email_error): ?>
            <p style="color:red;font-size:13px;margin-top:-10px"><?= htmlspecialchars($email_error) ?></p>
        <?php endif; ?>

        <label for="passwordInput">Password</label>
        <input type="password" id="passwordInput" name="password" form="login-form"
               placeholder="Password" required>
        <?php if ($pass_error): ?>
            <p style="color:red;font-size:13px;margin-top:-10px"><?= htmlspecialchars($pass_error) ?></p>
        <?php endif; ?>

        <form id="login-form" method="POST" action="#">
            <button type="submit" name="log-in" class="btn-primary">Submit</button>
        </form>

        <p style="text-align:center;margin-top:16px;font-size:14px;color:#999;cursor:pointer"
           onclick="alert('Password recovery not yet set')">
            Password recovery
        </p>
    </div>
</div>

</body>
</html>
