-- ============================================================
-- WIM Corporation — Full Database Migration
-- Run against: bxxhwhbm_wimcorp
-- ============================================================


-- ── 1. conflict_contracts table ──────────────────────────────

CREATE TABLE IF NOT EXISTS `conflict_contracts` (
    `id`                   INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `original_contract_id` VARCHAR(50)     NOT NULL,
    `buyer`                VARCHAR(100)    NOT NULL DEFAULT '',
    `surname`              VARCHAR(100)    NOT NULL DEFAULT '',
    `other_name`           VARCHAR(100)             DEFAULT 'TF',
    `contacts`             VARCHAR(50)              DEFAULT '',
    `other_number`         VARCHAR(50)              DEFAULT 'TF',
    `proxy`                VARCHAR(100)             DEFAULT 'None',
    `stone_name`           VARCHAR(100)             DEFAULT '',
    `slab_type`            VARCHAR(50)              DEFAULT '',
    `head_type`            VARCHAR(100)             DEFAULT 'TF',
    `stones_cost`          VARCHAR(20)              DEFAULT '',
    `stones_details`       TEXT                     DEFAULT NULL,
    `contract_type`        VARCHAR(30)              DEFAULT '',
    `contract_sign_date`   DATE                     DEFAULT NULL,
    `installation_date`    VARCHAR(20)              DEFAULT 'TF',
    `unveiling_date`       VARCHAR(20)              DEFAULT 'TF',
    `grave_yard`           VARCHAR(150)             DEFAULT '',
    `town`                 VARCHAR(80)              DEFAULT '',
    `dec_name`             VARCHAR(100)             DEFAULT '',
    `dSurname`             VARCHAR(100)             DEFAULT '',
    `dotherName`           VARCHAR(100)             DEFAULT 'TF',
    `sales_rep`            VARCHAR(80)              DEFAULT '',
    `funeral`              TINYINT(1)               DEFAULT 0,
    `flagged_by`           VARCHAR(150)    NOT NULL DEFAULT '',
    `flagged_at`           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `resolved`             TINYINT(1)      NOT NULL DEFAULT 0,
    `resolution_note`      TEXT                     DEFAULT NULL,
    `resolved_at`          DATETIME                 DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_original_id` (`original_contract_id`),
    KEY `idx_resolved`    (`resolved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ── 2. Security clearance column on employees ─────────────────
--
--   0 = No access    — login blocked entirely
--   1 = Full admin   — office + plant, including scheduling
--   2 = Plant CRUD   — add / update / delete stones, NO scheduling page
--   3 = Read-only    — plant login only, "scheduled-stones" page only

ALTER TABLE `employees`
    MODIFY COLUMN `security_clearance` TINYINT(1) NOT NULL DEFAULT 1
    COMMENT '0=no access, 1=full admin, 2=plant CRUD, 3=read-only';


-- ── 3. tombstones_installations — office confirmation columns ──
-- Allow office (clearance 1) to confirm/reject plant completions
-- without losing the plant team's own confirm_installation flag.

ALTER TABLE `tombstones_installations`
    ADD COLUMN IF NOT EXISTS `logged_by`           VARCHAR(150) DEFAULT NULL
        COMMENT 'Plant user who last updated this record',
    ADD COLUMN IF NOT EXISTS `logged_at`           DATETIME     DEFAULT NULL
        COMMENT 'When plant user last updated',
    ADD COLUMN IF NOT EXISTS `office_confirmed`    TINYINT(1)   DEFAULT 0
        COMMENT '1 = office admin confirmed installation',
    ADD COLUMN IF NOT EXISTS `office_confirmed_by` VARCHAR(150) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `office_confirmed_at` DATETIME     DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `rejection_note`      TEXT         DEFAULT NULL
        COMMENT 'Reason sent back to plant team when rejected',
    ADD COLUMN IF NOT EXISTS `rejected_by`         VARCHAR(150) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS `rejected_at`         DATETIME     DEFAULT NULL;

-- Fast lookup index for the confirm-installations review page
ALTER TABLE `tombstones_installations`
    ADD INDEX IF NOT EXISTS `idx_confirm_office` (`confirm_installation`, `office_confirmed`);


-- ── 4. Verify ─────────────────────────────────────────────────
-- DESCRIBE conflict_contracts;
-- DESCRIBE tombstones_installations;
-- SELECT id, personnel_name, surname, security_clearance FROM employees;
